/*M!999999\- enable the sandbox mode */ 

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `account_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `type` enum('debit','credit') NOT NULL,
  `sub_type` enum('opening_balance','fund_transfer','deposit') DEFAULT NULL,
  `amount` decimal(22,4) NOT NULL,
  `reff_no` varchar(191) DEFAULT NULL,
  `operation_date` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `transaction_id` int(11) DEFAULT NULL,
  `transaction_payment_id` int(11) DEFAULT NULL,
  `transfer_transaction_id` int(11) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `account_transactions_account_id_index` (`account_id`),
  KEY `account_transactions_transaction_id_index` (`transaction_id`),
  KEY `account_transactions_transaction_payment_id_index` (`transaction_payment_id`),
  KEY `account_transactions_transfer_transaction_id_index` (`transfer_transaction_id`),
  KEY `account_transactions_created_by_index` (`created_by`),
  KEY `account_transactions_type_index` (`type`),
  KEY `account_transactions_sub_type_index` (`sub_type`),
  KEY `account_transactions_operation_date_index` (`operation_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `account_transactions` WRITE;
/*!40000 ALTER TABLE `account_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_transactions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `account_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `parent_account_type_id` int(11) DEFAULT NULL,
  `business_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `account_types_parent_account_type_id_index` (`parent_account_type_id`),
  KEY `account_types_business_id_index` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `account_types` WRITE;
/*!40000 ALTER TABLE `account_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_types` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `account_number` varchar(191) NOT NULL,
  `account_details` text DEFAULT NULL,
  `account_type_id` int(11) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `is_closed` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `accounts_business_id_index` (`business_id`),
  KEY `accounts_account_type_id_index` (`account_type_id`),
  KEY `accounts_created_by_index` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `log_name` varchar(191) DEFAULT NULL,
  `description` text NOT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `subject_type` varchar(191) DEFAULT NULL,
  `event` varchar(191) DEFAULT NULL,
  `business_id` int(11) DEFAULT NULL,
  `causer_id` int(11) DEFAULT NULL,
  `causer_type` varchar(191) DEFAULT NULL,
  `properties` text DEFAULT NULL,
  `batch_uuid` char(36) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activity_log_log_name_index` (`log_name`)
) ENGINE=InnoDB AUTO_INCREMENT=240 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
INSERT INTO `activity_log` VALUES
(1,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2024-08-01 04:19:21','2024-08-01 04:19:21'),
(2,'default','logout',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2024-08-01 04:34:25','2024-08-01 04:34:25'),
(3,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2024-08-01 04:34:28','2024-08-01 04:34:28'),
(4,'default','logout',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2024-08-01 06:49:36','2024-08-01 06:49:36'),
(5,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2024-08-01 06:49:40','2024-08-01 06:49:40'),
(6,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2024-08-01 14:00:27','2024-08-01 14:00:27'),
(7,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-08 05:38:01','2025-01-08 05:38:01'),
(8,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-09 09:33:37','2025-01-09 09:33:37'),
(9,'default','added',2,'App\\Contact',NULL,1,1,'App\\User','[]',NULL,'2025-01-09 11:59:41','2025-01-09 11:59:41'),
(10,'default','added',1,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"purchase\",\"status\":\"received\",\"payment_status\":\"due\",\"final_total\":0}}',NULL,'2025-01-09 12:00:40','2025-01-09 12:00:40'),
(11,'default','added',2,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":0}}',NULL,'2025-01-09 12:02:22','2025-01-09 12:02:22'),
(12,'default','added',3,'App\\Contact',NULL,1,1,'App\\User','[]',NULL,'2025-01-09 12:03:05','2025-01-09 12:03:05'),
(13,'default','added',3,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"draft\",\"sub_status\":\"quotation\",\"final_total\":10000}}',NULL,'2025-01-09 12:03:19','2025-01-09 12:03:19'),
(14,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-09 18:06:29','2025-01-09 18:06:29'),
(15,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-09 18:17:36','2025-01-09 18:17:36'),
(16,'default','logout',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-09 18:20:19','2025-01-09 18:20:19'),
(17,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-09 18:20:32','2025-01-09 18:20:32'),
(18,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-10 06:33:53','2025-01-10 06:33:53'),
(19,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-10 06:35:07','2025-01-10 06:35:07'),
(20,'default','logout',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-10 06:36:51','2025-01-10 06:36:51'),
(21,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-10 09:59:59','2025-01-10 09:59:59'),
(22,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-10 18:06:06','2025-01-10 18:06:06'),
(23,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-10 19:03:02','2025-01-10 19:03:02'),
(24,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-10 19:40:23','2025-01-10 19:40:23'),
(25,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-11 10:12:44','2025-01-11 10:12:44'),
(26,'default','added',4,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"draft\",\"final_total\":700}}',NULL,'2025-01-11 10:43:35','2025-01-11 10:43:35'),
(27,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-15 13:47:25','2025-01-15 13:47:25'),
(28,'default','added',6,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":350}}',NULL,'2025-01-15 13:51:25','2025-01-15 13:51:25'),
(29,'default','added',3,'App\\User',NULL,1,1,'App\\User','{\"name\":\"Mr Jacob Mercado\"}',NULL,'2025-01-15 13:55:04','2025-01-15 13:55:04'),
(30,'default','logout',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-15 13:55:21','2025-01-15 13:55:21'),
(31,'default','login',3,'App\\User',NULL,1,3,'App\\User','[]',NULL,'2025-01-15 13:55:24','2025-01-15 13:55:24'),
(32,'default','logout',3,'App\\User',NULL,1,3,'App\\User','[]',NULL,'2025-01-15 13:57:42','2025-01-15 13:57:42'),
(33,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-15 13:57:49','2025-01-15 13:57:49'),
(34,'default','added',7,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":400}}',NULL,'2025-01-15 14:02:14','2025-01-15 14:02:14'),
(35,'default','logout',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-15 14:03:30','2025-01-15 14:03:30'),
(36,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-16 10:44:01','2025-01-16 10:44:01'),
(37,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-16 15:45:58','2025-01-16 15:45:58'),
(38,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 10:57:36','2025-01-17 10:57:36'),
(39,'default','added',8,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":4450}}',NULL,'2025-01-17 11:11:11','2025-01-17 11:11:11'),
(40,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 11:29:42','2025-01-17 11:29:42'),
(41,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 11:57:19','2025-01-17 11:57:19'),
(42,'default','added',10,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":3900}}',NULL,'2025-01-17 11:57:56','2025-01-17 11:57:56'),
(43,'default','logout',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 12:00:27','2025-01-17 12:00:27'),
(44,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 12:02:16','2025-01-17 12:02:16'),
(45,'default','logout',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 12:02:42','2025-01-17 12:02:42'),
(46,'default','login',4,'App\\User',NULL,2,4,'App\\User','[]',NULL,'2025-01-17 12:03:48','2025-01-17 12:03:48'),
(47,'default','logout',4,'App\\User',NULL,2,4,'App\\User','[]',NULL,'2025-01-17 12:04:44','2025-01-17 12:04:44'),
(48,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 12:04:49','2025-01-17 12:04:49'),
(49,'default','logout',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 12:06:36','2025-01-17 12:06:36'),
(50,'default','login',4,'App\\User',NULL,2,4,'App\\User','[]',NULL,'2025-01-17 12:06:42','2025-01-17 12:06:42'),
(51,'default','logout',4,'App\\User',NULL,2,4,'App\\User','[]',NULL,'2025-01-17 12:07:08','2025-01-17 12:07:08'),
(52,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 12:07:12','2025-01-17 12:07:12'),
(53,'default','logout',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 12:08:14','2025-01-17 12:08:14'),
(54,'default','login',4,'App\\User',NULL,2,4,'App\\User','[]',NULL,'2025-01-17 12:08:19','2025-01-17 12:08:19'),
(55,'default','added',11,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":700}}',NULL,'2025-01-17 12:10:41','2025-01-17 12:10:41'),
(56,'default','logout',4,'App\\User',NULL,2,4,'App\\User','[]',NULL,'2025-01-17 12:13:36','2025-01-17 12:13:36'),
(57,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 12:13:41','2025-01-17 12:13:41'),
(58,'default','added',12,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":1750}}',NULL,'2025-01-17 12:13:55','2025-01-17 12:13:55'),
(59,'default','added',13,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":400}}',NULL,'2025-01-17 12:19:38','2025-01-17 12:19:38'),
(60,'default','added',5,'App\\User',NULL,1,1,'App\\User','{\"name\":\"Miss ARCELI SALVADOR\"}',NULL,'2025-01-17 12:22:10','2025-01-17 12:22:10'),
(61,'default','edited',5,'App\\User',NULL,1,1,'App\\User','{\"name\":\"Miss ARCELI SALVADOR\"}',NULL,'2025-01-17 12:23:30','2025-01-17 12:23:30'),
(62,'default','logout',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 12:23:34','2025-01-17 12:23:34'),
(63,'default','login',5,'App\\User',NULL,1,5,'App\\User','[]',NULL,'2025-01-17 12:23:38','2025-01-17 12:23:38'),
(64,'default','logout',5,'App\\User',NULL,1,5,'App\\User','[]',NULL,'2025-01-17 12:24:04','2025-01-17 12:24:04'),
(65,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 12:24:07','2025-01-17 12:24:07'),
(66,'default','logout',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 12:25:12','2025-01-17 12:25:12'),
(67,'default','login',5,'App\\User',NULL,1,5,'App\\User','[]',NULL,'2025-01-17 12:25:27','2025-01-17 12:25:27'),
(68,'default','logout',5,'App\\User',NULL,1,5,'App\\User','[]',NULL,'2025-01-17 12:26:25','2025-01-17 12:26:25'),
(69,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 12:26:27','2025-01-17 12:26:27'),
(70,'default','logout',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 12:26:50','2025-01-17 12:26:50'),
(71,'default','login',5,'App\\User',NULL,1,5,'App\\User','[]',NULL,'2025-01-17 12:26:55','2025-01-17 12:26:55'),
(72,'default','logout',5,'App\\User',NULL,1,5,'App\\User','[]',NULL,'2025-01-17 12:27:13','2025-01-17 12:27:13'),
(73,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 12:27:18','2025-01-17 12:27:18'),
(74,'default','added',14,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":1000}}',NULL,'2025-01-17 12:28:17','2025-01-17 12:28:17'),
(75,'default','email_notification_sent',2,'App\\Transaction',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 12:30:12','2025-01-17 12:30:12'),
(76,'default','added',5,'App\\Contact',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 12:36:39','2025-01-17 12:36:39'),
(77,'default','email_notification_sent',3,'App\\Transaction',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 12:37:09','2025-01-17 12:37:09'),
(78,'default','email_notification_sent',3,'App\\Transaction',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 12:37:27','2025-01-17 12:37:27'),
(79,'default','email_notification_sent',3,'App\\Transaction',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 12:38:34','2025-01-17 12:38:34'),
(80,'default','email_notification_sent',3,'App\\Transaction',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 12:39:02','2025-01-17 12:39:02'),
(81,'default','added',6,'App\\Contact',NULL,2,4,'App\\User','[]',NULL,'2025-01-17 12:41:11','2025-01-17 12:41:11'),
(82,'default','logout',4,'App\\User',NULL,2,4,'App\\User','[]',NULL,'2025-01-17 12:43:56','2025-01-17 12:43:56'),
(83,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 12:43:58','2025-01-17 12:43:58'),
(84,'default','edited',5,'App\\User',NULL,1,1,'App\\User','{\"name\":\"Miss ARCELI SALVADOR\"}',NULL,'2025-01-17 12:51:47','2025-01-17 12:51:47'),
(85,'default','logout',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 12:54:35','2025-01-17 12:54:35'),
(86,'default','login',5,'App\\User',NULL,1,5,'App\\User','[]',NULL,'2025-01-17 12:54:39','2025-01-17 12:54:39'),
(87,'default','logout',5,'App\\User',NULL,1,5,'App\\User','[]',NULL,'2025-01-17 12:55:38','2025-01-17 12:55:38'),
(88,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 12:55:44','2025-01-17 12:55:44'),
(89,'default','logout',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 12:58:08','2025-01-17 12:58:08'),
(90,'default','login',5,'App\\User',NULL,1,5,'App\\User','[]',NULL,'2025-01-17 12:58:15','2025-01-17 12:58:15'),
(91,'default','logout',5,'App\\User',NULL,1,5,'App\\User','[]',NULL,'2025-01-17 12:58:54','2025-01-17 12:58:54'),
(92,'default','login',4,'App\\User',NULL,2,4,'App\\User','[]',NULL,'2025-01-17 12:59:02','2025-01-17 12:59:02'),
(93,'default','added',6,'App\\User',NULL,2,4,'App\\User','{\"name\":\" ARCELI SALVADOR\"}',NULL,'2025-01-17 13:00:11','2025-01-17 13:00:11'),
(94,'default','logout',4,'App\\User',NULL,2,4,'App\\User','[]',NULL,'2025-01-17 13:00:22','2025-01-17 13:00:22'),
(95,'default','login',6,'App\\User',NULL,2,6,'App\\User','[]',NULL,'2025-01-17 13:00:24','2025-01-17 13:00:24'),
(96,'default','logout',6,'App\\User',NULL,2,6,'App\\User','[]',NULL,'2025-01-17 13:00:30','2025-01-17 13:00:30'),
(97,'default','login',4,'App\\User',NULL,2,4,'App\\User','[]',NULL,'2025-01-17 13:00:34','2025-01-17 13:00:34'),
(98,'default','logout',4,'App\\User',NULL,2,4,'App\\User','[]',NULL,'2025-01-17 13:01:37','2025-01-17 13:01:37'),
(99,'default','login',6,'App\\User',NULL,2,6,'App\\User','[]',NULL,'2025-01-17 13:01:40','2025-01-17 13:01:40'),
(100,'default','logout',6,'App\\User',NULL,2,6,'App\\User','[]',NULL,'2025-01-17 13:01:45','2025-01-17 13:01:45'),
(101,'default','login',4,'App\\User',NULL,2,4,'App\\User','[]',NULL,'2025-01-17 13:01:53','2025-01-17 13:01:53'),
(102,'default','logout',4,'App\\User',NULL,2,4,'App\\User','[]',NULL,'2025-01-17 13:03:03','2025-01-17 13:03:03'),
(103,'default','login',6,'App\\User',NULL,2,6,'App\\User','[]',NULL,'2025-01-17 13:03:06','2025-01-17 13:03:06'),
(104,'default','logout',6,'App\\User',NULL,2,6,'App\\User','[]',NULL,'2025-01-17 13:03:42','2025-01-17 13:03:42'),
(105,'default','login',4,'App\\User',NULL,2,4,'App\\User','[]',NULL,'2025-01-17 13:03:46','2025-01-17 13:03:46'),
(106,'default','logout',4,'App\\User',NULL,2,4,'App\\User','[]',NULL,'2025-01-17 15:41:56','2025-01-17 15:41:56'),
(107,'default','login',6,'App\\User',NULL,2,6,'App\\User','[]',NULL,'2025-01-17 15:42:00','2025-01-17 15:42:00'),
(108,'default','logout',6,'App\\User',NULL,2,6,'App\\User','[]',NULL,'2025-01-17 15:42:22','2025-01-17 15:42:22'),
(109,'default','login',4,'App\\User',NULL,2,4,'App\\User','[]',NULL,'2025-01-17 15:42:25','2025-01-17 15:42:25'),
(110,'default','logout',4,'App\\User',NULL,2,4,'App\\User','[]',NULL,'2025-01-17 15:50:14','2025-01-17 15:50:14'),
(111,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-17 13:20:19','2025-01-17 13:20:19'),
(112,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-20 15:42:57','2025-01-20 15:42:57'),
(113,'default','added',16,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"partial\",\"final_total\":1500}}',NULL,'2025-01-20 15:43:49','2025-01-20 15:43:49'),
(114,'default','added',17,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"partial\",\"final_total\":2200}}',NULL,'2025-01-20 15:44:27','2025-01-20 15:44:27'),
(115,'default','edited',5,'App\\Contact',NULL,1,1,'App\\User','[]',NULL,'2025-01-20 15:46:42','2025-01-20 15:46:42'),
(116,'default','added',18,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"due\",\"final_total\":2000}}',NULL,'2025-01-20 15:48:06','2025-01-20 15:48:06'),
(117,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-20 16:12:24','2025-01-20 16:12:24'),
(118,'default','logout',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-20 16:32:10','2025-01-20 16:32:10'),
(119,'default','login',5,'App\\User',NULL,1,5,'App\\User','[]',NULL,'2025-01-20 16:32:15','2025-01-20 16:32:15'),
(120,'default','logout',5,'App\\User',NULL,1,5,'App\\User','[]',NULL,'2025-01-20 16:32:23','2025-01-20 16:32:23'),
(121,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-20 16:32:27','2025-01-20 16:32:27'),
(122,'default','logout',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-20 16:36:24','2025-01-20 16:36:24'),
(123,'default','login',4,'App\\User',NULL,2,4,'App\\User','[]',NULL,'2025-01-20 19:06:32','2025-01-20 19:06:32'),
(124,'default','logout',4,'App\\User',NULL,2,4,'App\\User','[]',NULL,'2025-01-20 19:07:32','2025-01-20 19:07:32'),
(125,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-20 16:37:41','2025-01-20 16:37:41'),
(126,'default','payment_edited',18,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"partial\",\"final_total\":\"2000.0000\"},\"old\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"due\",\"final_total\":\"2000.0000\"}}',NULL,'2025-01-20 19:13:55','2025-01-20 19:13:55'),
(127,'default','logout',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-20 19:16:41','2025-01-20 19:16:41'),
(128,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-21 18:58:23','2025-01-21 18:58:23'),
(129,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-22 07:21:39','2025-01-22 07:21:39'),
(130,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-22 14:08:58','2025-01-22 14:08:58'),
(131,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-22 22:13:34','2025-01-22 22:13:34'),
(132,'default','added',9,'App\\User',NULL,1,1,'App\\User','{\"name\":\" Jeno Lee\"}',NULL,'2025-01-22 22:17:34','2025-01-22 22:17:34'),
(133,'default','logout',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-22 22:17:46','2025-01-22 22:17:46'),
(134,'default','login',9,'App\\User',NULL,1,9,'App\\User','[]',NULL,'2025-01-22 22:17:51','2025-01-22 22:17:51'),
(135,'default','logout',9,'App\\User',NULL,1,9,'App\\User','[]',NULL,'2025-01-22 22:17:59','2025-01-22 22:17:59'),
(136,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-22 22:18:06','2025-01-22 22:18:06'),
(137,'default','edited',9,'App\\User',NULL,1,1,'App\\User','{\"name\":\" Jeno Lee\"}',NULL,'2025-01-22 22:20:09','2025-01-22 22:20:09'),
(138,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-22 22:23:47','2025-01-22 22:23:47'),
(139,'default','added',19,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":1230}}',NULL,'2025-01-22 22:28:56','2025-01-22 22:28:56'),
(140,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-23 08:20:15','2025-01-23 08:20:15'),
(141,'default','added',20,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":250}}',NULL,'2025-01-23 08:22:09','2025-01-23 08:22:09'),
(142,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-23 08:33:03','2025-01-23 08:33:03'),
(143,'default','added',21,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":700}}',NULL,'2025-01-23 09:06:10','2025-01-23 09:06:10'),
(144,'default','added',22,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"draft\",\"final_total\":700}}',NULL,'2025-01-23 09:06:46','2025-01-23 09:06:46'),
(145,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-23 09:08:08','2025-01-23 09:08:08'),
(146,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-23 09:30:35','2025-01-23 09:30:35'),
(147,'default','added',23,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"draft\",\"sub_status\":\"quotation\",\"final_total\":110}}',NULL,'2025-01-23 09:31:04','2025-01-23 09:31:04'),
(148,'default','added',24,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":3651.2}}',NULL,'2025-01-23 09:38:57','2025-01-23 09:38:57'),
(149,'default','added',25,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":3500}}',NULL,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(150,'default','added',26,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":4312}}',NULL,'2025-01-23 09:42:47','2025-01-23 09:42:47'),
(151,'default','added',27,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"purchase\",\"status\":\"received\",\"payment_status\":\"due\",\"final_total\":250000000}}',NULL,'2025-01-23 09:43:14','2025-01-23 09:43:14'),
(152,'default','added',28,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":4000}}',NULL,'2025-01-23 09:43:28','2025-01-23 09:43:28'),
(153,'default','added',29,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":6180}}',NULL,'2025-01-23 09:45:49','2025-01-23 09:45:49'),
(154,'default','added',30,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":610}}',NULL,'2025-01-23 09:48:38','2025-01-23 09:48:38'),
(155,'default','added',31,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":6000}}',NULL,'2025-01-23 09:50:33','2025-01-23 09:50:33'),
(156,'default','added',33,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":650000}}',NULL,'2025-01-23 09:55:54','2025-01-23 09:55:54'),
(157,'default','added',34,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":519.68}}',NULL,'2025-01-23 10:01:17','2025-01-23 10:01:17'),
(158,'default','added',35,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":51200}}',NULL,'2025-01-23 10:16:03','2025-01-23 10:16:03'),
(159,'default','added',36,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":600}}',NULL,'2025-01-23 10:37:23','2025-01-23 10:37:23'),
(160,'default','added',10,'App\\User',NULL,1,1,'App\\User','{\"name\":\" Test \"}',NULL,'2025-01-23 10:40:13','2025-01-23 10:40:13'),
(161,'default','logout',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-23 10:40:20','2025-01-23 10:40:20'),
(162,'default','login',10,'App\\User',NULL,1,10,'App\\User','[]',NULL,'2025-01-23 10:40:24','2025-01-23 10:40:24'),
(163,'default','login',10,'App\\User',NULL,1,10,'App\\User','[]',NULL,'2025-01-23 10:52:31','2025-01-23 10:52:31'),
(164,'default','logout',10,'App\\User',NULL,1,10,'App\\User','[]',NULL,'2025-01-23 11:50:40','2025-01-23 11:50:40'),
(165,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-23 11:50:42','2025-01-23 11:50:42'),
(166,'default','added',37,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":224}}',NULL,'2025-01-23 11:56:05','2025-01-23 11:56:05'),
(167,'default','added',38,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":280}}',NULL,'2025-01-23 11:58:22','2025-01-23 11:58:22'),
(168,'default','added',39,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":1232}}',NULL,'2025-01-23 11:59:11','2025-01-23 11:59:11'),
(169,'default','added',40,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":672}}',NULL,'2025-01-23 12:00:32','2025-01-23 12:00:32'),
(170,'default','added',41,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":672}}',NULL,'2025-01-23 12:03:39','2025-01-23 12:03:39'),
(171,'default','added',42,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":280}}',NULL,'2025-01-23 12:05:53','2025-01-23 12:05:53'),
(172,'default','added',43,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":280}}',NULL,'2025-01-23 12:06:21','2025-01-23 12:06:21'),
(173,'default','added',44,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":392}}',NULL,'2025-01-23 12:09:48','2025-01-23 12:09:48'),
(174,'default','added',45,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":500}}',NULL,'2025-01-23 12:10:41','2025-01-23 12:10:41'),
(175,'default','added',46,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":350}}',NULL,'2025-01-23 12:12:12','2025-01-23 12:12:12'),
(176,'default','added',47,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":560}}',NULL,'2025-01-23 12:12:21','2025-01-23 12:12:21'),
(177,'default','added',48,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":500}}',NULL,'2025-01-23 12:12:39','2025-01-23 12:12:39'),
(178,'default','added',49,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":446.43}}',NULL,'2025-01-23 12:14:15','2025-01-23 12:14:15'),
(179,'default','added',50,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":446.43}}',NULL,'2025-01-23 12:15:22','2025-01-23 12:15:22'),
(180,'default','added',51,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":500}}',NULL,'2025-01-23 12:16:26','2025-01-23 12:16:26'),
(181,'default','added',52,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":500}}',NULL,'2025-01-23 12:18:11','2025-01-23 12:18:11'),
(182,'default','added',53,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":500}}',NULL,'2025-01-23 12:18:54','2025-01-23 12:18:54'),
(183,'default','added',54,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":500}}',NULL,'2025-01-23 12:19:01','2025-01-23 12:19:01'),
(184,'default','added',55,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":1000}}',NULL,'2025-01-23 12:20:03','2025-01-23 12:20:03'),
(185,'default','added',56,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":50000}}',NULL,'2025-01-23 12:25:35','2025-01-23 12:25:35'),
(186,'default','added',57,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":500}}',NULL,'2025-01-23 12:26:30','2025-01-23 12:26:30'),
(187,'default','added',58,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":50000}}',NULL,'2025-01-23 12:27:06','2025-01-23 12:27:06'),
(188,'default','added',59,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":50000}}',NULL,'2025-01-23 12:27:28','2025-01-23 12:27:28'),
(189,'default','added',60,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":50000}}',NULL,'2025-01-23 12:29:06','2025-01-23 12:29:06'),
(190,'default','added',61,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":50000}}',NULL,'2025-01-23 12:31:19','2025-01-23 12:31:19'),
(191,'default','added',62,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":50500}}',NULL,'2025-01-23 12:32:58','2025-01-23 12:32:58'),
(192,'default','added',63,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":51000}}',NULL,'2025-01-23 12:34:20','2025-01-23 12:34:20'),
(193,'default','login',10,'App\\User',NULL,1,10,'App\\User','[]',NULL,'2025-01-23 12:52:49','2025-01-23 12:52:49'),
(194,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-23 13:03:46','2025-01-23 13:03:46'),
(195,'default','logout',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-23 13:09:25','2025-01-23 13:09:25'),
(196,'default','login',4,'App\\User',NULL,2,4,'App\\User','[]',NULL,'2025-01-23 13:09:30','2025-01-23 13:09:30'),
(197,'default','logout',4,'App\\User',NULL,2,4,'App\\User','[]',NULL,'2025-01-23 13:09:40','2025-01-23 13:09:40'),
(198,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-23 13:09:44','2025-01-23 13:09:44'),
(199,'default','logout',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-23 13:10:51','2025-01-23 13:10:51'),
(200,'default','login',11,'App\\User',NULL,3,11,'App\\User','[]',NULL,'2025-01-23 10:41:40','2025-01-23 10:41:40'),
(201,'default','logout',11,'App\\User',NULL,3,11,'App\\User','[]',NULL,'2025-01-23 10:41:51','2025-01-23 10:41:51'),
(202,'default','login',1,'App\\User',NULL,1,1,'App\\User','[]',NULL,'2025-01-23 13:11:53','2025-01-23 13:11:53'),
(203,'default','added',8,'App\\Contact',NULL,1,1,'App\\User','[]',NULL,'2025-01-23 13:46:47','2025-01-23 13:46:47'),
(204,'default','added',9,'App\\Contact',NULL,1,1,'App\\User','[]',NULL,'2025-01-23 13:50:48','2025-01-23 13:50:48'),
(205,'default','added',10,'App\\Contact',NULL,1,1,'App\\User','[]',NULL,'2025-01-23 13:51:26','2025-01-23 13:51:26'),
(206,'default','added',11,'App\\Contact',NULL,1,1,'App\\User','[]',NULL,'2025-01-23 13:51:57','2025-01-23 13:51:57'),
(207,'default','added',12,'App\\Contact',NULL,1,1,'App\\User','[]',NULL,'2025-01-23 13:52:23','2025-01-23 13:52:23'),
(208,'default','added',13,'App\\Contact',NULL,1,1,'App\\User','[]',NULL,'2025-01-23 13:55:26','2025-01-23 13:55:26'),
(209,'default','added',14,'App\\Contact',NULL,1,1,'App\\User','[]',NULL,'2025-01-23 13:55:46','2025-01-23 13:55:46'),
(210,'default','added',15,'App\\Contact',NULL,1,1,'App\\User','[]',NULL,'2025-01-23 13:56:02','2025-01-23 13:56:02'),
(211,'default','added',16,'App\\Contact',NULL,1,1,'App\\User','[]',NULL,'2025-01-23 13:56:22','2025-01-23 13:56:22'),
(212,'default','added',17,'App\\Contact',NULL,1,1,'App\\User','[]',NULL,'2025-01-23 13:56:41','2025-01-23 13:56:41'),
(213,'default','deleted',9,'App\\User',NULL,1,1,'App\\User','{\"name\":\" Jeno Lee\",\"id\":9}',NULL,'2025-01-23 14:02:27','2025-01-23 14:02:27'),
(214,'default','added',12,'App\\User',NULL,1,1,'App\\User','{\"name\":\" JENOLEE \"}',NULL,'2025-01-23 14:03:13','2025-01-23 14:03:13'),
(215,'default','added',13,'App\\User',NULL,1,1,'App\\User','{\"name\":\" jaeminna \"}',NULL,'2025-01-23 14:03:58','2025-01-23 14:03:58'),
(216,'default','edited',12,'App\\User',NULL,1,1,'App\\User','{\"name\":\" jenolee \"}',NULL,'2025-01-23 14:04:31','2025-01-23 14:04:31'),
(217,'default','added',14,'App\\User',NULL,1,1,'App\\User','{\"name\":\" jisungpark \"}',NULL,'2025-01-23 14:05:11','2025-01-23 14:05:11'),
(218,'default','edited',13,'App\\User',NULL,1,1,'App\\User','{\"name\":\" jaeminna \"}',NULL,'2025-01-23 14:05:42','2025-01-23 14:05:42'),
(219,'default','added',15,'App\\User',NULL,1,1,'App\\User','{\"name\":\" haechanlee \"}',NULL,'2025-01-23 14:06:22','2025-01-23 14:06:22'),
(220,'default','added',16,'App\\User',NULL,1,1,'App\\User','{\"name\":\" marklee \"}',NULL,'2025-01-23 14:07:01','2025-01-23 14:07:01'),
(221,'default','added',67,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":500000}}',NULL,'2025-01-23 14:08:03','2025-01-23 14:08:03'),
(222,'default','added',68,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":250000}}',NULL,'2025-01-23 14:09:39','2025-01-23 14:09:39'),
(223,'default','added',69,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":150000}}',NULL,'2025-01-23 14:10:18','2025-01-23 14:10:18'),
(224,'default','added',70,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":100000}}',NULL,'2025-01-23 14:10:50','2025-01-23 14:10:50'),
(225,'default','added',71,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":140000}}',NULL,'2025-01-23 14:11:28','2025-01-23 14:11:28'),
(226,'default','added',72,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":110000}}',NULL,'2025-01-23 14:11:56','2025-01-23 14:11:56'),
(227,'default','added',73,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":350000}}',NULL,'2025-01-23 14:12:26','2025-01-23 14:12:26'),
(228,'default','added',74,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":150000}}',NULL,'2025-01-23 14:13:13','2025-01-23 14:13:13'),
(229,'default','added',75,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":200000}}',NULL,'2025-01-23 14:16:52','2025-01-23 14:16:52'),
(230,'default','added',76,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":300000}}',NULL,'2025-01-23 14:20:13','2025-01-23 14:20:13'),
(231,'default','login',10,'App\\User',NULL,1,10,'App\\User','[]',NULL,'2025-01-23 14:39:23','2025-01-23 14:39:23'),
(232,'default','added',77,'App\\Transaction',NULL,1,1,'App\\User','[]',NULL,'2025-01-23 14:44:38','2025-01-23 14:44:38'),
(233,'default','added',78,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"purchase\",\"status\":\"received\",\"payment_status\":\"due\",\"final_total\":2800000}}',NULL,'2025-01-23 14:45:53','2025-01-23 14:45:53'),
(234,'default','payment_edited',27,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"purchase\",\"status\":\"received\",\"payment_status\":\"paid\",\"final_total\":\"250000000.0000\"},\"old\":{\"type\":\"purchase\",\"status\":\"received\",\"payment_status\":\"due\",\"final_total\":\"250000000.0000\"}}',NULL,'2025-01-23 14:46:05','2025-01-23 14:46:05'),
(235,'default','added',79,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":560}}',NULL,'2025-01-23 14:47:06','2025-01-23 14:47:06'),
(236,'default','added',80,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":560}}',NULL,'2025-01-23 14:49:26','2025-01-23 14:49:26'),
(237,'default','added',81,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"payment_status\":\"due\"}}',NULL,'2025-01-23 14:50:32','2025-01-23 14:50:32'),
(238,'default','payment_edited',18,'App\\Transaction',NULL,1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"2000.0000\"},\"old\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"partial\",\"final_total\":\"2000.0000\"}}',NULL,'2025-01-23 14:55:11','2025-01-23 14:55:11'),
(239,'default','shipping_edited',77,'App\\Transaction',NULL,1,1,'App\\User','{\"update_note\":null}',NULL,'2025-01-23 14:55:42','2025-01-23 14:55:42');
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `aiassistance_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aiassistance_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `tool_type` varchar(191) NOT NULL,
  `input_data` text DEFAULT NULL,
  `tokens_used` int(11) NOT NULL DEFAULT 0,
  `output_data` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `aiassistance_history` WRITE;
/*!40000 ALTER TABLE `aiassistance_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `aiassistance_history` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `barcodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `barcodes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `width` double(22,4) DEFAULT NULL,
  `height` double(22,4) DEFAULT NULL,
  `paper_width` double(22,4) DEFAULT NULL,
  `paper_height` double(22,4) DEFAULT NULL,
  `top_margin` double(22,4) DEFAULT NULL,
  `left_margin` double(22,4) DEFAULT NULL,
  `row_distance` double(22,4) DEFAULT NULL,
  `col_distance` double(22,4) DEFAULT NULL,
  `stickers_in_one_row` int(11) DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `is_continuous` tinyint(1) NOT NULL DEFAULT 0,
  `stickers_in_one_sheet` int(11) DEFAULT NULL,
  `business_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `barcodes_business_id_foreign` (`business_id`),
  CONSTRAINT `barcodes_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `barcodes` WRITE;
/*!40000 ALTER TABLE `barcodes` DISABLE KEYS */;
INSERT INTO `barcodes` VALUES
(1,'20 Labels per Sheet','Sheet Size: 8.5\" x 11\", Label Size: 4\" x 1\", Labels per sheet: 20',4.0000,1.0000,8.5000,11.0000,0.5000,0.1250,0.0000,0.1875,2,0,0,20,NULL,'2017-12-18 00:13:44','2017-12-18 00:13:44'),
(2,'30 Labels per sheet','Sheet Size: 8.5\" x 11\", Label Size: 2.625\" x 1\", Labels per sheet: 30',2.6250,1.0000,8.5000,11.0000,0.5000,0.1880,0.0000,0.1250,3,0,0,30,NULL,'2017-12-18 00:04:39','2017-12-18 00:10:40'),
(3,'32 Labels per sheet','Sheet Size: 8.5\" x 11\", Label Size: 2\" x 1.25\", Labels per sheet: 32',2.0000,1.2500,8.5000,11.0000,0.5000,0.2500,0.0000,0.0000,4,0,0,32,NULL,'2017-12-17 23:55:40','2017-12-17 23:55:40'),
(4,'40 Labels per sheet','Sheet Size: 8.5\" x 11\", Label Size: 2\" x 1\", Labels per sheet: 40',2.0000,1.0000,8.5000,11.0000,0.5000,0.2500,0.0000,0.0000,4,0,0,40,NULL,'2017-12-17 23:58:40','2017-12-17 23:58:40'),
(5,'50 Labels per Sheet','Sheet Size: 8.5\" x 11\", Label Size: 1.5\" x 1\", Labels per sheet: 50',1.5000,1.0000,8.5000,11.0000,0.5000,0.5000,0.0000,0.0000,5,0,0,50,NULL,'2017-12-17 23:51:10','2017-12-17 23:51:10'),
(6,'Continuous Rolls - 31.75mm x 25.4mm','Label Size: 31.75mm x 25.4mm, Gap: 3.18mm',1.2500,1.0000,1.2500,0.0000,0.1250,0.0000,0.1250,0.0000,1,0,1,NULL,NULL,'2017-12-17 23:51:10','2017-12-17 23:51:10');
/*!40000 ALTER TABLE `barcodes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bookings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contact_id` int(10) unsigned NOT NULL,
  `waiter_id` int(10) unsigned DEFAULT NULL,
  `table_id` int(10) unsigned DEFAULT NULL,
  `correspondent_id` int(11) DEFAULT NULL,
  `business_id` int(10) unsigned NOT NULL,
  `location_id` int(10) unsigned NOT NULL,
  `booking_start` datetime NOT NULL,
  `booking_end` datetime NOT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `booking_status` varchar(191) NOT NULL,
  `booking_note` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bookings_contact_id_foreign` (`contact_id`),
  KEY `bookings_business_id_foreign` (`business_id`),
  KEY `bookings_created_by_foreign` (`created_by`),
  KEY `bookings_table_id_index` (`table_id`),
  KEY `bookings_waiter_id_index` (`waiter_id`),
  KEY `bookings_location_id_index` (`location_id`),
  KEY `bookings_booking_status_index` (`booking_status`),
  KEY `bookings_correspondent_id_index` (`correspondent_id`),
  CONSTRAINT `bookings_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bookings_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bookings_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
INSERT INTO `bookings` VALUES
(1,1,NULL,NULL,3,1,1,'2025-01-17 12:17:00','2025-01-17 12:17:00',1,'completed','gaaa','2025-01-17 12:17:39','2025-01-17 12:29:22'),
(2,3,5,1,5,1,1,'2025-01-29 00:00:00','2025-01-29 00:00:00',1,'cancelled','hhh','2025-01-17 12:29:49','2025-01-17 12:30:33'),
(3,5,5,NULL,1,1,1,'2025-01-18 00:00:00','2025-01-18 00:00:00',1,'booked','Hi!','2025-01-17 12:37:00','2025-01-17 12:37:00'),
(4,6,NULL,NULL,4,2,2,'2025-01-17 12:41:00','2025-01-17 12:41:00',4,'booked',NULL,'2025-01-17 12:42:04','2025-01-17 12:42:04');
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brands` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `name` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `brands_business_id_foreign` (`business_id`),
  KEY `brands_created_by_foreign` (`created_by`),
  CONSTRAINT `brands_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `brands_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` VALUES
(1,1,'SMTOWN','from SMTOWN direct',1,NULL,'2025-01-15 13:48:27','2025-01-15 13:48:27'),
(2,1,'KTOWN4U','Preordered POB from KTOWN4U',1,NULL,'2025-01-17 11:13:50','2025-01-17 11:13:50');
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `business`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `currency_id` int(10) unsigned NOT NULL,
  `start_date` date DEFAULT NULL,
  `tax_number_1` varchar(100) DEFAULT NULL,
  `tax_label_1` varchar(10) DEFAULT NULL,
  `tax_number_2` varchar(100) DEFAULT NULL,
  `tax_label_2` varchar(10) DEFAULT NULL,
  `code_label_1` varchar(191) DEFAULT NULL,
  `code_1` varchar(191) DEFAULT NULL,
  `code_label_2` varchar(191) DEFAULT NULL,
  `code_2` varchar(191) DEFAULT NULL,
  `default_sales_tax` int(10) unsigned DEFAULT NULL,
  `default_profit_percent` double(5,2) NOT NULL DEFAULT 0.00,
  `owner_id` int(10) unsigned NOT NULL,
  `time_zone` varchar(191) NOT NULL DEFAULT 'Asia/Kolkata',
  `fy_start_month` tinyint(4) NOT NULL DEFAULT 1,
  `accounting_method` enum('fifo','lifo','avco') NOT NULL DEFAULT 'fifo',
  `default_sales_discount` decimal(5,2) DEFAULT NULL,
  `sell_price_tax` enum('includes','excludes') NOT NULL DEFAULT 'includes',
  `logo` varchar(191) DEFAULT NULL,
  `sku_prefix` varchar(191) DEFAULT NULL,
  `enable_product_expiry` tinyint(1) NOT NULL DEFAULT 0,
  `expiry_type` enum('add_expiry','add_manufacturing') NOT NULL DEFAULT 'add_expiry',
  `on_product_expiry` enum('keep_selling','stop_selling','auto_delete') NOT NULL DEFAULT 'keep_selling',
  `stop_selling_before` int(11) NOT NULL COMMENT 'Stop selling expied item n days before expiry',
  `enable_tooltip` tinyint(1) NOT NULL DEFAULT 1,
  `purchase_in_diff_currency` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Allow purchase to be in different currency then the business currency',
  `purchase_currency_id` int(10) unsigned DEFAULT NULL,
  `p_exchange_rate` decimal(20,3) NOT NULL DEFAULT 1.000,
  `transaction_edit_days` int(10) unsigned NOT NULL DEFAULT 30,
  `stock_expiry_alert_days` int(10) unsigned NOT NULL DEFAULT 30,
  `keyboard_shortcuts` text DEFAULT NULL,
  `pos_settings` text DEFAULT NULL,
  `essentials_settings` longtext DEFAULT NULL,
  `weighing_scale_setting` text NOT NULL COMMENT 'used to store the configuration of weighing scale',
  `enable_brand` tinyint(1) NOT NULL DEFAULT 1,
  `enable_category` tinyint(1) NOT NULL DEFAULT 1,
  `enable_sub_category` tinyint(1) NOT NULL DEFAULT 1,
  `enable_price_tax` tinyint(1) NOT NULL DEFAULT 1,
  `enable_purchase_status` tinyint(1) DEFAULT 1,
  `enable_lot_number` tinyint(1) NOT NULL DEFAULT 0,
  `default_unit` int(11) DEFAULT NULL,
  `enable_sub_units` tinyint(1) NOT NULL DEFAULT 0,
  `enable_racks` tinyint(1) NOT NULL DEFAULT 0,
  `enable_row` tinyint(1) NOT NULL DEFAULT 0,
  `enable_position` tinyint(1) NOT NULL DEFAULT 0,
  `enable_editing_product_from_purchase` tinyint(1) NOT NULL DEFAULT 1,
  `sales_cmsn_agnt` enum('logged_in_user','user','cmsn_agnt') DEFAULT NULL,
  `item_addition_method` tinyint(1) NOT NULL DEFAULT 1,
  `enable_inline_tax` tinyint(1) NOT NULL DEFAULT 1,
  `currency_symbol_placement` enum('before','after') NOT NULL DEFAULT 'before',
  `enabled_modules` text DEFAULT NULL,
  `date_format` varchar(191) NOT NULL DEFAULT 'm/d/Y',
  `time_format` enum('12','24') NOT NULL DEFAULT '24',
  `currency_precision` tinyint(4) NOT NULL DEFAULT 2,
  `quantity_precision` tinyint(4) NOT NULL DEFAULT 2,
  `ref_no_prefixes` text DEFAULT NULL,
  `theme_color` char(20) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `enable_rp` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'rp is the short form of reward points',
  `rp_name` varchar(191) DEFAULT NULL COMMENT 'rp is the short form of reward points',
  `amount_for_unit_rp` decimal(22,4) NOT NULL DEFAULT 1.0000 COMMENT 'rp is the short form of reward points',
  `min_order_total_for_rp` decimal(22,4) NOT NULL DEFAULT 1.0000 COMMENT 'rp is the short form of reward points',
  `max_rp_per_order` int(11) DEFAULT NULL COMMENT 'rp is the short form of reward points',
  `redeem_amount_per_unit_rp` decimal(22,4) NOT NULL DEFAULT 1.0000 COMMENT 'rp is the short form of reward points',
  `min_order_total_for_redeem` decimal(22,4) NOT NULL DEFAULT 1.0000 COMMENT 'rp is the short form of reward points',
  `min_redeem_point` int(11) DEFAULT NULL COMMENT 'rp is the short form of reward points',
  `max_redeem_point` int(11) DEFAULT NULL COMMENT 'rp is the short form of reward points',
  `rp_expiry_period` int(11) DEFAULT NULL COMMENT 'rp is the short form of reward points',
  `rp_expiry_type` enum('month','year') NOT NULL DEFAULT 'year' COMMENT 'rp is the short form of reward points',
  `email_settings` text DEFAULT NULL,
  `sms_settings` text DEFAULT NULL,
  `custom_labels` text DEFAULT NULL,
  `common_settings` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `business_owner_id_foreign` (`owner_id`),
  KEY `business_currency_id_foreign` (`currency_id`),
  KEY `business_default_sales_tax_foreign` (`default_sales_tax`),
  CONSTRAINT `business_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`),
  CONSTRAINT `business_default_sales_tax_foreign` FOREIGN KEY (`default_sales_tax`) REFERENCES `tax_rates` (`id`),
  CONSTRAINT `business_owner_id_foreign` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `business` WRITE;
/*!40000 ALTER TABLE `business` DISABLE KEYS */;
INSERT INTO `business` VALUES
(1,'DeulDigital POS',95,'2024-08-01','12%','VAT(12%)','3%','NONVAT',NULL,NULL,NULL,NULL,NULL,25.00,1,'Asia/Hong_Kong',1,'fifo',0.00,'includes','1736513188_DEUL.png',NULL,1,'add_expiry','stop_selling',1,0,0,NULL,1.000,30,30,'{\"pos\":{\"express_checkout\":\"shift+e\",\"pay_n_ckeckout\":\"shift+p\",\"draft\":\"shift+d\",\"cancel\":\"shift+c\",\"recent_product_quantity\":\"f2\",\"weighing_scale\":null,\"edit_discount\":\"shift+i\",\"edit_order_tax\":\"shift+t\",\"add_payment_row\":\"shift+r\",\"finalize_payment\":\"shift+f\",\"add_new_product\":\"f4\"}}','{\"amount_rounding_method\":null,\"enable_sales_order\":\"1\",\"is_pay_term_required\":\"1\",\"cmmsn_calculation_type\":\"invoice_value\",\"is_commission_agent_required\":\"1\",\"enable_payment_link\":\"1\",\"razor_pay_key_id\":null,\"razor_pay_key_secret\":null,\"stripe_public_key\":null,\"stripe_secret_key\":null,\"is_pos_subtotal_editable\":\"1\",\"show_invoice_scheme\":\"1\",\"show_invoice_layout\":\"1\",\"cash_denominations\":null,\"enable_cash_denomination_on\":\"pos_screen\",\"disable_pay_checkout\":0,\"disable_draft\":0,\"disable_express_checkout\":0,\"hide_product_suggestion\":0,\"hide_recent_trans\":0,\"disable_discount\":0,\"disable_order_tax\":0}','{\"leave_ref_no_prefix\":null,\"leave_instructions\":null,\"payroll_ref_no_prefix\":null,\"essentials_todos_prefix\":null,\"grace_before_checkin\":\"10\",\"grace_after_checkin\":\"10\",\"grace_before_checkout\":\"10\",\"grace_after_checkout\":\"10\",\"is_location_required\":0,\"calculate_sales_target_commission_without_tax\":1}','{\"label_prefix\":null,\"product_sku_length\":\"4\",\"qty_length\":\"3\",\"qty_length_decimal\":\"2\"}',1,1,1,1,1,1,NULL,1,0,1,1,1,'logged_in_user',1,1,'before','[\"purchases\",\"add_sale\",\"pos_sale\",\"stock_transfers\",\"stock_adjustment\",\"expenses\",\"account\",\"tables\",\"modifiers\",\"service_staff\",\"booking\",\"kitchen\",\"subscription\",\"types_of_service\"]','d-m-Y','12',2,2,'{\"purchase\":\"PO\",\"purchase_return\":null,\"purchase_requisition\":null,\"purchase_order\":null,\"stock_transfer\":\"ST\",\"stock_adjustment\":\"SA\",\"sell_return\":\"CN\",\"expense\":\"EP\",\"contacts\":\"CO\",\"purchase_payment\":\"PP\",\"sell_payment\":\"SP\",\"expense_payment\":null,\"business_location\":\"BL\",\"username\":null,\"subscription\":null,\"draft\":null,\"sales_order\":null}','purple',NULL,0,NULL,1.0000,1.0000,NULL,1.0000,1.0000,NULL,NULL,NULL,'year','{\"mail_driver\":\"smtp\",\"mail_host\":\"smtp.hostinger.com\",\"mail_port\":\"465\",\"mail_username\":\"info@deuldigital.com\",\"mail_password\":\"Deulgicam09!\",\"mail_encryption\":\"SSL\",\"mail_from_address\":\"info@deuldigital.com\",\"mail_from_name\":\"DeulDigital POS\"}','{\"sms_service\":\"twilio\",\"nexmo_key\":null,\"nexmo_secret\":null,\"nexmo_from\":null,\"twilio_sid\":\"AC55fd62a0ca0fa48e53ee4295a9c90402\",\"twilio_token\":\"c0b8afb12a50df30d9d0cd5d9963efa9\",\"twilio_from\":\"DeulDigital\",\"url\":null,\"send_to_param_name\":\"to\",\"msg_param_name\":\"text\",\"request_method\":\"post\",\"header_1\":null,\"header_val_1\":null,\"header_2\":null,\"header_val_2\":null,\"header_3\":null,\"header_val_3\":null,\"param_1\":null,\"param_val_1\":null,\"param_2\":null,\"param_val_2\":null,\"param_3\":null,\"param_val_3\":null,\"param_4\":null,\"param_val_4\":null,\"param_5\":null,\"param_val_5\":null,\"param_6\":null,\"param_val_6\":null,\"param_7\":null,\"param_val_7\":null,\"param_8\":null,\"param_val_8\":null,\"param_9\":null,\"param_val_9\":null,\"param_10\":null,\"param_val_10\":null}','{\"payments\":{\"custom_pay_1\":null,\"custom_pay_2\":null,\"custom_pay_3\":null,\"custom_pay_4\":null,\"custom_pay_5\":null,\"custom_pay_6\":null,\"custom_pay_7\":null},\"contact\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null,\"custom_field_7\":null,\"custom_field_8\":null,\"custom_field_9\":null,\"custom_field_10\":null},\"product\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null,\"custom_field_7\":null,\"custom_field_8\":null,\"custom_field_9\":null,\"custom_field_10\":null,\"custom_field_11\":null,\"custom_field_12\":null,\"custom_field_13\":null,\"custom_field_14\":null,\"custom_field_15\":null,\"custom_field_16\":null,\"custom_field_17\":null,\"custom_field_18\":null,\"custom_field_19\":null,\"custom_field_20\":null},\"product_cf_details\":{\"1\":{\"type\":null,\"dropdown_options\":null},\"2\":{\"type\":null,\"dropdown_options\":null},\"3\":{\"type\":null,\"dropdown_options\":null},\"4\":{\"type\":null,\"dropdown_options\":null},\"5\":{\"type\":null,\"dropdown_options\":null},\"6\":{\"type\":null,\"dropdown_options\":null},\"7\":{\"type\":null,\"dropdown_options\":null},\"8\":{\"type\":null,\"dropdown_options\":null},\"9\":{\"type\":null,\"dropdown_options\":null},\"10\":{\"type\":null,\"dropdown_options\":null},\"11\":{\"type\":null,\"dropdown_options\":null},\"12\":{\"type\":null,\"dropdown_options\":null},\"13\":{\"type\":null,\"dropdown_options\":null},\"14\":{\"type\":null,\"dropdown_options\":null},\"15\":{\"type\":null,\"dropdown_options\":null},\"16\":{\"type\":null,\"dropdown_options\":null},\"17\":{\"type\":null,\"dropdown_options\":null},\"18\":{\"type\":null,\"dropdown_options\":null},\"19\":{\"type\":null,\"dropdown_options\":null},\"20\":{\"type\":null,\"dropdown_options\":null}},\"location\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"user\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase_shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"sell\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"types_of_service\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null}}','{\"enable_product_warranty\":\"1\",\"default_credit_limit\":\"5000\",\"enable_purchase_order\":\"1\",\"enable_purchase_requisition\":\"1\",\"default_datatable_page_entries\":\"25\"}',1,'2024-08-01 04:19:13','2025-01-23 14:45:53'),
(2,'DeulDigital',95,'2025-01-09',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,25.00,4,'Asia/Hong_Kong',1,'fifo',0.00,'includes','1737095624_BRAND LOGO.png',NULL,0,'add_expiry','keep_selling',0,1,0,NULL,1.000,30,30,'{\"pos\":{\"express_checkout\":\"shift+e\",\"pay_n_ckeckout\":\"shift+p\",\"draft\":\"shift+d\",\"cancel\":\"shift+c\",\"recent_product_quantity\":\"f2\",\"weighing_scale\":null,\"edit_discount\":\"shift+i\",\"edit_order_tax\":\"shift+t\",\"add_payment_row\":\"shift+r\",\"finalize_payment\":\"shift+f\",\"add_new_product\":\"f4\"}}','{\"amount_rounding_method\":null,\"cmmsn_calculation_type\":\"invoice_value\",\"razor_pay_key_id\":null,\"razor_pay_key_secret\":null,\"stripe_public_key\":null,\"stripe_secret_key\":null,\"cash_denominations\":null,\"enable_cash_denomination_on\":\"pos_screen\",\"disable_pay_checkout\":0,\"disable_draft\":0,\"disable_express_checkout\":0,\"hide_product_suggestion\":0,\"hide_recent_trans\":0,\"disable_discount\":0,\"disable_order_tax\":0,\"is_pos_subtotal_editable\":0}','{\"leave_ref_no_prefix\":null,\"leave_instructions\":null,\"payroll_ref_no_prefix\":null,\"essentials_todos_prefix\":null,\"grace_before_checkin\":\"10\",\"grace_after_checkin\":\"10\",\"grace_before_checkout\":\"10\",\"grace_after_checkout\":\"10\",\"is_location_required\":0,\"calculate_sales_target_commission_without_tax\":0}','{\"label_prefix\":null,\"product_sku_length\":\"4\",\"qty_length\":\"3\",\"qty_length_decimal\":\"2\"}',1,1,1,1,1,0,NULL,0,0,0,0,1,NULL,1,0,'before','[\"purchases\",\"add_sale\",\"pos_sale\",\"stock_transfers\",\"stock_adjustment\",\"expenses\",\"account\",\"tables\",\"modifiers\",\"service_staff\",\"booking\",\"kitchen\",\"subscription\",\"types_of_service\"]','m/d/Y','12',2,2,'{\"purchase\":\"PO\",\"purchase_return\":null,\"purchase_requisition\":null,\"purchase_order\":null,\"stock_transfer\":\"ST\",\"stock_adjustment\":\"SA\",\"sell_return\":\"CN\",\"expense\":\"EP\",\"contacts\":\"CO\",\"purchase_payment\":\"PP\",\"sell_payment\":\"SP\",\"expense_payment\":null,\"business_location\":\"BL\",\"username\":null,\"subscription\":null,\"draft\":null,\"sales_order\":null}','green',NULL,0,NULL,1.0000,1.0000,NULL,1.0000,1.0000,NULL,NULL,NULL,'year','{\"mail_driver\":\"smtp\",\"mail_host\":null,\"mail_port\":null,\"mail_username\":null,\"mail_password\":null,\"mail_encryption\":null,\"mail_from_address\":null,\"mail_from_name\":null}','{\"sms_service\":\"twilio\",\"nexmo_key\":null,\"nexmo_secret\":null,\"nexmo_from\":null,\"twilio_sid\":\"AC55fd62a0ca0fa48e53ee4295a9c90402\",\"twilio_token\":\"c0b8afb12a50df30d9d0cd5d9963efa9\",\"twilio_from\":null,\"url\":null,\"send_to_param_name\":\"to\",\"msg_param_name\":\"text\",\"request_method\":\"post\",\"header_1\":null,\"header_val_1\":null,\"header_2\":null,\"header_val_2\":null,\"header_3\":null,\"header_val_3\":null,\"param_1\":null,\"param_val_1\":null,\"param_2\":null,\"param_val_2\":null,\"param_3\":null,\"param_val_3\":null,\"param_4\":null,\"param_val_4\":null,\"param_5\":null,\"param_val_5\":null,\"param_6\":null,\"param_val_6\":null,\"param_7\":null,\"param_val_7\":null,\"param_8\":null,\"param_val_8\":null,\"param_9\":null,\"param_val_9\":null,\"param_10\":null,\"param_val_10\":null}','{\"payments\":{\"custom_pay_1\":null,\"custom_pay_2\":null,\"custom_pay_3\":null,\"custom_pay_4\":null,\"custom_pay_5\":null,\"custom_pay_6\":null,\"custom_pay_7\":null},\"contact\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null,\"custom_field_7\":null,\"custom_field_8\":null,\"custom_field_9\":null,\"custom_field_10\":null},\"product\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null,\"custom_field_7\":null,\"custom_field_8\":null,\"custom_field_9\":null,\"custom_field_10\":null,\"custom_field_11\":null,\"custom_field_12\":null,\"custom_field_13\":null,\"custom_field_14\":null,\"custom_field_15\":null,\"custom_field_16\":null,\"custom_field_17\":null,\"custom_field_18\":null,\"custom_field_19\":null,\"custom_field_20\":null},\"product_cf_details\":{\"1\":{\"type\":null,\"dropdown_options\":null},\"2\":{\"type\":null,\"dropdown_options\":null},\"3\":{\"type\":null,\"dropdown_options\":null},\"4\":{\"type\":null,\"dropdown_options\":null},\"5\":{\"type\":null,\"dropdown_options\":null},\"6\":{\"type\":null,\"dropdown_options\":null},\"7\":{\"type\":null,\"dropdown_options\":null},\"8\":{\"type\":null,\"dropdown_options\":null},\"9\":{\"type\":null,\"dropdown_options\":null},\"10\":{\"type\":null,\"dropdown_options\":null},\"11\":{\"type\":null,\"dropdown_options\":null},\"12\":{\"type\":null,\"dropdown_options\":null},\"13\":{\"type\":null,\"dropdown_options\":null},\"14\":{\"type\":null,\"dropdown_options\":null},\"15\":{\"type\":null,\"dropdown_options\":null},\"16\":{\"type\":null,\"dropdown_options\":null},\"17\":{\"type\":null,\"dropdown_options\":null},\"18\":{\"type\":null,\"dropdown_options\":null},\"19\":{\"type\":null,\"dropdown_options\":null},\"20\":{\"type\":null,\"dropdown_options\":null}},\"location\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"user\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase_shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"sell\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"types_of_service\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null}}','{\"default_credit_limit\":null,\"default_datatable_page_entries\":\"25\"}',1,'2025-01-17 12:03:44','2025-01-17 15:44:47'),
(3,'Testing 1',95,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,25.00,11,'Asia/Kolkata',1,'fifo',NULL,'includes',NULL,NULL,0,'add_expiry','keep_selling',0,1,0,NULL,1.000,30,30,'{\"pos\":{\"express_checkout\":\"shift+e\",\"pay_n_ckeckout\":\"shift+p\",\"draft\":\"shift+d\",\"cancel\":\"shift+c\",\"edit_discount\":\"shift+i\",\"edit_order_tax\":\"shift+t\",\"add_payment_row\":\"shift+r\",\"finalize_payment\":\"shift+f\",\"recent_product_quantity\":\"f2\",\"add_new_product\":\"f4\"}}',NULL,NULL,'',1,1,1,1,1,0,NULL,0,0,0,0,1,NULL,1,0,'before','[\"purchases\",\"add_sale\",\"pos_sale\",\"stock_transfers\",\"stock_adjustment\",\"expenses\"]','m/d/Y','24',2,2,'{\"purchase\":\"PO\",\"stock_transfer\":\"ST\",\"stock_adjustment\":\"SA\",\"sell_return\":\"CN\",\"expense\":\"EP\",\"contacts\":\"CO\",\"purchase_payment\":\"PP\",\"sell_payment\":\"SP\",\"business_location\":\"BL\"}',NULL,NULL,0,NULL,1.0000,1.0000,NULL,1.0000,1.0000,NULL,NULL,NULL,'year',NULL,NULL,NULL,NULL,1,'2025-01-23 10:41:35','2025-01-23 10:41:35');
/*!40000 ALTER TABLE `business` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `business_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_locations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `location_id` varchar(191) DEFAULT NULL,
  `name` varchar(256) NOT NULL,
  `landmark` text DEFAULT NULL,
  `country` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `zip_code` char(7) NOT NULL,
  `invoice_scheme_id` int(10) unsigned NOT NULL,
  `sale_invoice_scheme_id` int(11) DEFAULT NULL,
  `invoice_layout_id` int(10) unsigned NOT NULL,
  `sale_invoice_layout_id` int(11) DEFAULT NULL,
  `selling_price_group_id` int(11) DEFAULT NULL,
  `print_receipt_on_invoice` tinyint(1) DEFAULT 1,
  `receipt_printer_type` enum('browser','printer') NOT NULL DEFAULT 'browser',
  `printer_id` int(11) DEFAULT NULL,
  `mobile` varchar(191) DEFAULT NULL,
  `alternate_number` varchar(191) DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `website` varchar(191) DEFAULT NULL,
  `featured_products` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `default_payment_accounts` text DEFAULT NULL,
  `custom_field1` varchar(191) DEFAULT NULL,
  `custom_field2` varchar(191) DEFAULT NULL,
  `custom_field3` varchar(191) DEFAULT NULL,
  `custom_field4` varchar(191) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `business_locations_business_id_index` (`business_id`),
  KEY `business_locations_invoice_scheme_id_foreign` (`invoice_scheme_id`),
  KEY `business_locations_invoice_layout_id_foreign` (`invoice_layout_id`),
  KEY `business_locations_sale_invoice_layout_id_index` (`sale_invoice_layout_id`),
  KEY `business_locations_selling_price_group_id_index` (`selling_price_group_id`),
  KEY `business_locations_receipt_printer_type_index` (`receipt_printer_type`),
  KEY `business_locations_printer_id_index` (`printer_id`),
  CONSTRAINT `business_locations_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `business_locations_invoice_layout_id_foreign` FOREIGN KEY (`invoice_layout_id`) REFERENCES `invoice_layouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `business_locations_invoice_scheme_id_foreign` FOREIGN KEY (`invoice_scheme_id`) REFERENCES `invoice_schemes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `business_locations` WRITE;
/*!40000 ALTER TABLE `business_locations` DISABLE KEYS */;
INSERT INTO `business_locations` VALUES
(1,1,'BL0001','WebWonder','info@deuldigital.com','Philippines','Philippines','Trece Martires','4109',1,1,1,1,NULL,1,'browser',NULL,'0171000000',NULL,NULL,NULL,NULL,1,'{\"cash\":{\"is_enabled\":\"1\",\"account\":null},\"card\":{\"is_enabled\":\"1\",\"account\":null},\"cheque\":{\"is_enabled\":\"1\",\"account\":null},\"bank_transfer\":{\"is_enabled\":\"1\",\"account\":null},\"other\":{\"is_enabled\":\"1\",\"account\":null},\"custom_pay_1\":{\"is_enabled\":\"1\",\"account\":null},\"custom_pay_2\":{\"is_enabled\":\"1\",\"account\":null},\"custom_pay_3\":{\"is_enabled\":\"1\",\"account\":null},\"custom_pay_4\":{\"is_enabled\":\"1\",\"account\":null},\"custom_pay_5\":{\"is_enabled\":\"1\",\"account\":null},\"custom_pay_6\":{\"is_enabled\":\"1\",\"account\":null},\"custom_pay_7\":{\"is_enabled\":\"1\",\"account\":null}}',NULL,NULL,NULL,NULL,NULL,'2024-08-01 04:19:13','2025-01-17 12:47:40'),
(2,2,'BL0001','DeulDigital','webwonder','Philippines','ISABELA','ECHAGUE','3309',2,NULL,2,2,NULL,1,'browser',NULL,'09385050860','','','',NULL,1,'{\"cash\":{\"is_enabled\":1,\"account\":null},\"card\":{\"is_enabled\":1,\"account\":null},\"cheque\":{\"is_enabled\":1,\"account\":null},\"bank_transfer\":{\"is_enabled\":1,\"account\":null},\"other\":{\"is_enabled\":1,\"account\":null},\"custom_pay_1\":{\"is_enabled\":1,\"account\":null},\"custom_pay_2\":{\"is_enabled\":1,\"account\":null},\"custom_pay_3\":{\"is_enabled\":1,\"account\":null},\"custom_pay_4\":{\"is_enabled\":1,\"account\":null},\"custom_pay_5\":{\"is_enabled\":1,\"account\":null},\"custom_pay_6\":{\"is_enabled\":1,\"account\":null},\"custom_pay_7\":{\"is_enabled\":1,\"account\":null}}',NULL,NULL,NULL,NULL,NULL,'2025-01-17 12:03:44','2025-01-17 12:03:44'),
(3,3,'BL0001','Testing 1','webwonder','Philippines','ISABELA','ECHAGUE','3309',3,NULL,3,3,NULL,1,'browser',NULL,'09385050860','','','',NULL,1,'{\"cash\":{\"is_enabled\":1,\"account\":null},\"card\":{\"is_enabled\":1,\"account\":null},\"cheque\":{\"is_enabled\":1,\"account\":null},\"bank_transfer\":{\"is_enabled\":1,\"account\":null},\"other\":{\"is_enabled\":1,\"account\":null},\"custom_pay_1\":{\"is_enabled\":1,\"account\":null},\"custom_pay_2\":{\"is_enabled\":1,\"account\":null},\"custom_pay_3\":{\"is_enabled\":1,\"account\":null},\"custom_pay_4\":{\"is_enabled\":1,\"account\":null},\"custom_pay_5\":{\"is_enabled\":1,\"account\":null},\"custom_pay_6\":{\"is_enabled\":1,\"account\":null},\"custom_pay_7\":{\"is_enabled\":1,\"account\":null}}',NULL,NULL,NULL,NULL,NULL,'2025-01-23 10:41:35','2025-01-23 10:41:35');
/*!40000 ALTER TABLE `business_locations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cash_denominations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cash_denominations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `amount` decimal(22,4) NOT NULL,
  `total_count` int(11) NOT NULL,
  `model_type` varchar(191) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cash_denominations_model_type_model_id_index` (`model_type`,`model_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cash_denominations` WRITE;
/*!40000 ALTER TABLE `cash_denominations` DISABLE KEYS */;
/*!40000 ALTER TABLE `cash_denominations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cash_register_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cash_register_transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cash_register_id` int(10) unsigned NOT NULL,
  `amount` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `pay_method` varchar(191) DEFAULT NULL,
  `type` enum('debit','credit') NOT NULL,
  `transaction_type` varchar(191) DEFAULT NULL,
  `transaction_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cash_register_transactions_cash_register_id_foreign` (`cash_register_id`),
  KEY `cash_register_transactions_transaction_id_index` (`transaction_id`),
  KEY `cash_register_transactions_type_index` (`type`),
  KEY `cash_register_transactions_transaction_type_index` (`transaction_type`),
  CONSTRAINT `cash_register_transactions_cash_register_id_foreign` FOREIGN KEY (`cash_register_id`) REFERENCES `cash_registers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cash_register_transactions` WRITE;
/*!40000 ALTER TABLE `cash_register_transactions` DISABLE KEYS */;
INSERT INTO `cash_register_transactions` VALUES
(1,1,350.0000,'cash','credit','sell',6,'2025-01-15 13:51:25','2025-01-15 13:51:25'),
(2,2,1000.0000,'cash','credit','initial',NULL,'2025-01-15 13:55:40','2025-01-15 13:55:40'),
(3,3,1000.0000,'cash','credit','initial',NULL,'2025-01-15 14:02:11','2025-01-15 14:02:11'),
(4,3,400.0000,'cash','credit','sell',7,'2025-01-15 14:02:14','2025-01-15 14:02:14'),
(5,3,4450.0000,'cash','credit','sell',8,'2025-01-17 11:11:11','2025-01-17 11:11:11'),
(6,3,3900.0000,'cash','credit','sell',10,'2025-01-17 11:57:56','2025-01-17 11:57:56'),
(7,4,10000000.0000,'cash','credit','initial',NULL,'2025-01-17 12:09:36','2025-01-17 12:09:36'),
(8,3,700.0000,'cash','credit','sell',11,'2025-01-17 12:10:41','2025-01-17 12:10:41'),
(9,3,1750.0000,'cash','credit','sell',12,'2025-01-17 12:13:55','2025-01-17 12:13:55'),
(10,3,400.0000,'cash','credit','sell',13,'2025-01-17 12:19:38','2025-01-17 12:19:38'),
(11,5,10000000.0000,'cash','credit','initial',NULL,'2025-01-17 12:26:01','2025-01-17 12:26:01'),
(12,3,1000.0000,'cash','credit','sell',14,'2025-01-17 12:28:17','2025-01-17 12:28:17'),
(13,6,10000000.0000,'cash','credit','initial',NULL,'2025-01-20 15:43:05','2025-01-20 15:43:05'),
(14,6,1000.0000,'cash','credit','sell',16,'2025-01-20 15:43:49','2025-01-20 15:43:49'),
(15,6,100.0000,'cash','credit','sell',17,'2025-01-20 15:44:27','2025-01-20 15:44:27'),
(16,7,10000000.0000,'cash','credit','initial',NULL,'2025-01-20 16:22:26','2025-01-20 16:22:26'),
(17,8,50000.0000,'cash','credit','initial',NULL,'2025-01-22 22:23:05','2025-01-22 22:23:05'),
(18,8,1230.0000,'cash','credit','sell',19,'2025-01-22 22:28:56','2025-01-22 22:28:56'),
(19,8,250.0000,'cash','credit','sell',20,'2025-01-23 08:22:09','2025-01-23 08:22:09'),
(20,8,700.0000,'cash','credit','sell',21,'2025-01-23 09:06:10','2025-01-23 09:06:10'),
(21,8,3651.2000,'cash','credit','sell',24,'2025-01-23 09:38:57','2025-01-23 09:38:57'),
(22,8,3500.0000,'cash','credit','sell',25,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(23,8,4312.0000,'cash','credit','sell',26,'2025-01-23 09:42:47','2025-01-23 09:42:47'),
(24,8,4000.0000,'cash','credit','sell',28,'2025-01-23 09:43:28','2025-01-23 09:43:28'),
(25,8,6180.0000,'cash','credit','sell',29,'2025-01-23 09:45:49','2025-01-23 09:45:49'),
(26,8,610.0000,'cash','credit','sell',30,'2025-01-23 09:48:38','2025-01-23 09:48:38'),
(27,8,6000.0000,'cash','credit','sell',31,'2025-01-23 09:50:33','2025-01-23 09:50:33'),
(28,8,650000.0000,'cash','credit','sell',33,'2025-01-23 09:55:54','2025-01-23 09:55:54'),
(29,8,519.6800,'cash','credit','sell',34,'2025-01-23 10:01:17','2025-01-23 10:01:17'),
(30,8,51200.0000,'cash','credit','sell',35,'2025-01-23 10:16:03','2025-01-23 10:16:03'),
(31,8,600.0000,'cash','credit','sell',36,'2025-01-23 10:37:23','2025-01-23 10:37:23'),
(32,9,100.0000,'cash','credit','initial',NULL,'2025-01-23 11:55:41','2025-01-23 11:55:41'),
(33,9,224.0000,'cash','credit','sell',37,'2025-01-23 11:56:05','2025-01-23 11:56:05'),
(34,9,280.0000,'cash','credit','sell',38,'2025-01-23 11:58:22','2025-01-23 11:58:22'),
(35,9,1232.0000,'cash','credit','sell',39,'2025-01-23 11:59:11','2025-01-23 11:59:11'),
(36,9,672.0000,'cash','credit','sell',40,'2025-01-23 12:00:32','2025-01-23 12:00:32'),
(37,9,672.0000,'cash','credit','sell',41,'2025-01-23 12:03:39','2025-01-23 12:03:39'),
(38,9,280.0000,'cash','credit','sell',42,'2025-01-23 12:05:53','2025-01-23 12:05:53'),
(39,9,280.0000,'cash','credit','sell',43,'2025-01-23 12:06:21','2025-01-23 12:06:21'),
(40,9,392.0000,'cash','credit','sell',44,'2025-01-23 12:09:48','2025-01-23 12:09:48'),
(41,9,500.0000,'cash','credit','sell',45,'2025-01-23 12:10:41','2025-01-23 12:10:41'),
(42,9,350.0000,'cash','credit','sell',46,'2025-01-23 12:12:12','2025-01-23 12:12:12'),
(43,9,560.0000,'cash','credit','sell',47,'2025-01-23 12:12:21','2025-01-23 12:12:21'),
(44,9,500.0000,'cash','credit','sell',48,'2025-01-23 12:12:39','2025-01-23 12:12:39'),
(45,9,446.4300,'cash','credit','sell',49,'2025-01-23 12:14:15','2025-01-23 12:14:15'),
(46,9,446.4300,'cash','credit','sell',50,'2025-01-23 12:15:22','2025-01-23 12:15:22'),
(47,9,500.0000,'cash','credit','sell',51,'2025-01-23 12:16:26','2025-01-23 12:16:26'),
(48,9,500.0000,'cash','credit','sell',52,'2025-01-23 12:18:11','2025-01-23 12:18:11'),
(49,9,500.0000,'cash','credit','sell',53,'2025-01-23 12:18:54','2025-01-23 12:18:54'),
(50,9,500.0000,'cash','credit','sell',54,'2025-01-23 12:19:01','2025-01-23 12:19:01'),
(51,9,1000.0000,'cash','credit','sell',55,'2025-01-23 12:20:03','2025-01-23 12:20:03'),
(52,9,50000.0000,'cash','credit','sell',56,'2025-01-23 12:25:35','2025-01-23 12:25:35'),
(53,9,500.0000,'cash','credit','sell',57,'2025-01-23 12:26:30','2025-01-23 12:26:30'),
(54,9,50000.0000,'cash','credit','sell',58,'2025-01-23 12:27:06','2025-01-23 12:27:06'),
(55,9,50000.0000,'cash','credit','sell',59,'2025-01-23 12:27:28','2025-01-23 12:27:28'),
(56,9,50000.0000,'cash','credit','sell',60,'2025-01-23 12:29:06','2025-01-23 12:29:06'),
(57,9,50000.0000,'cash','credit','sell',61,'2025-01-23 12:31:19','2025-01-23 12:31:19'),
(58,9,50500.0000,'cash','credit','sell',62,'2025-01-23 12:32:58','2025-01-23 12:32:58'),
(59,9,51000.0000,'cash','credit','sell',63,'2025-01-23 12:34:20','2025-01-23 12:34:20'),
(60,10,100.0000,'cash','credit','initial',NULL,'2025-01-23 10:42:20','2025-01-23 10:42:20'),
(61,9,500000.0000,'cash','credit','sell',67,'2025-01-23 14:08:03','2025-01-23 14:08:03'),
(62,9,250000.0000,'cash','credit','sell',68,'2025-01-23 14:09:39','2025-01-23 14:09:39'),
(63,9,150000.0000,'cash','credit','sell',69,'2025-01-23 14:10:18','2025-01-23 14:10:18'),
(64,9,100000.0000,'cash','credit','sell',70,'2025-01-23 14:10:50','2025-01-23 14:10:50'),
(65,9,140000.0000,'cash','credit','sell',71,'2025-01-23 14:11:28','2025-01-23 14:11:28'),
(66,9,110000.0000,'cash','credit','sell',72,'2025-01-23 14:11:56','2025-01-23 14:11:56'),
(67,9,350000.0000,'cash','credit','sell',73,'2025-01-23 14:12:26','2025-01-23 14:12:26'),
(68,9,150000.0000,'cash','credit','sell',74,'2025-01-23 14:13:13','2025-01-23 14:13:13'),
(69,9,200000.0000,'cash','credit','sell',75,'2025-01-23 14:16:52','2025-01-23 14:16:52'),
(70,9,300000.0000,'cash','credit','sell',76,'2025-01-23 14:20:13','2025-01-23 14:20:13'),
(71,9,570.0000,'cash','credit','sell',79,'2025-01-23 14:47:06','2025-01-23 14:47:06'),
(72,9,-10.0000,'cash','credit','sell',79,'2025-01-23 14:47:06','2025-01-23 14:47:06'),
(73,9,600.0000,'cash','credit','sell',80,'2025-01-23 14:49:26','2025-01-23 14:49:26'),
(74,9,-40.0000,'cash','credit','sell',80,'2025-01-23 14:49:26','2025-01-23 14:49:26'),
(75,9,1500.0000,'cash','debit','expense',81,'2025-01-23 14:50:32','2025-01-23 14:50:32');
/*!40000 ALTER TABLE `cash_register_transactions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cash_registers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cash_registers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `status` enum('close','open') NOT NULL DEFAULT 'open',
  `closed_at` datetime DEFAULT NULL,
  `closing_amount` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `total_card_slips` int(11) NOT NULL DEFAULT 0,
  `total_cheques` int(11) NOT NULL DEFAULT 0,
  `denominations` text DEFAULT NULL,
  `closing_note` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cash_registers_business_id_foreign` (`business_id`),
  KEY `cash_registers_user_id_foreign` (`user_id`),
  KEY `cash_registers_location_id_index` (`location_id`),
  CONSTRAINT `cash_registers_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cash_registers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cash_registers` WRITE;
/*!40000 ALTER TABLE `cash_registers` DISABLE KEYS */;
INSERT INTO `cash_registers` VALUES
(1,1,1,1,'close','2025-01-15 13:52:39',350.0000,0,0,NULL,NULL,'2024-08-01 04:27:00','2025-01-15 13:52:39'),
(2,1,1,3,'open',NULL,0.0000,0,0,NULL,NULL,'2025-01-15 13:55:00','2025-01-15 13:55:40'),
(3,1,1,1,'close','2025-01-17 12:46:08',13600.0000,0,0,NULL,NULL,'2025-01-15 14:02:00','2025-01-17 12:46:08'),
(4,2,2,4,'open',NULL,0.0000,0,0,NULL,NULL,'2025-01-17 12:09:00','2025-01-17 12:09:36'),
(5,1,1,5,'open',NULL,0.0000,0,0,NULL,NULL,'2025-01-17 12:26:00','2025-01-17 12:26:01'),
(6,1,1,1,'close','2025-01-20 16:13:02',10001100.0000,0,0,NULL,NULL,'2025-01-20 15:43:00','2025-01-20 16:13:02'),
(7,1,1,1,'close','2025-01-20 16:26:54',10000000.0000,0,0,NULL,NULL,'2025-01-20 16:22:00','2025-01-20 16:26:54'),
(8,1,1,1,'close','2025-01-23 11:54:35',782752.8800,0,0,NULL,NULL,'2025-01-22 22:23:00','2025-01-23 11:54:35'),
(9,1,1,1,'open',NULL,0.0000,0,0,NULL,NULL,'2025-01-23 11:55:00','2025-01-23 11:55:41'),
(10,3,3,11,'open',NULL,0.0000,0,0,NULL,NULL,'2025-01-23 10:42:00','2025-01-23 10:42:20');
/*!40000 ALTER TABLE `cash_registers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `business_id` int(10) unsigned NOT NULL,
  `short_code` varchar(191) DEFAULT NULL,
  `parent_id` int(11) NOT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `category_type` varchar(191) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `slug` varchar(191) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categories_business_id_foreign` (`business_id`),
  KEY `categories_created_by_foreign` (`created_by`),
  KEY `categories_parent_id_index` (`parent_id`),
  CONSTRAINT `categories_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categories_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES
(1,'DeulDigital',1,'1005',0,1,'hrm_department','Hello!',NULL,NULL,'2025-01-17 12:51:10','2025-01-17 12:51:10'),
(2,'DeulDigital 12',1,NULL,0,1,'hrm_designation',NULL,NULL,NULL,'2025-01-17 12:51:20','2025-01-17 12:51:20');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categorizables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorizables` (
  `category_id` int(11) NOT NULL,
  `categorizable_type` varchar(191) NOT NULL,
  `categorizable_id` bigint(20) unsigned NOT NULL,
  KEY `categorizables_categorizable_type_categorizable_id_index` (`categorizable_type`,`categorizable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categorizables` WRITE;
/*!40000 ALTER TABLE `categorizables` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorizables` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `type` varchar(191) NOT NULL,
  `contact_type` varchar(191) DEFAULT NULL,
  `supplier_business_name` varchar(191) DEFAULT NULL,
  `name` varchar(191) DEFAULT NULL,
  `prefix` varchar(191) DEFAULT NULL,
  `first_name` varchar(191) DEFAULT NULL,
  `middle_name` varchar(191) DEFAULT NULL,
  `last_name` varchar(191) DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `contact_id` varchar(191) DEFAULT NULL,
  `contact_status` varchar(191) NOT NULL DEFAULT 'active',
  `tax_number` varchar(191) DEFAULT NULL,
  `city` varchar(191) DEFAULT NULL,
  `state` varchar(191) DEFAULT NULL,
  `country` varchar(191) DEFAULT NULL,
  `address_line_1` text DEFAULT NULL,
  `address_line_2` text DEFAULT NULL,
  `zip_code` varchar(191) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `mobile` varchar(191) NOT NULL,
  `landline` varchar(191) DEFAULT NULL,
  `alternate_number` varchar(191) DEFAULT NULL,
  `pay_term_number` int(11) DEFAULT NULL,
  `pay_term_type` enum('days','months') DEFAULT NULL,
  `credit_limit` decimal(22,4) DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `balance` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `total_rp` int(11) NOT NULL DEFAULT 0 COMMENT 'rp is the short form of reward points',
  `total_rp_used` int(11) NOT NULL DEFAULT 0 COMMENT 'rp is the short form of reward points',
  `total_rp_expired` int(11) NOT NULL DEFAULT 0 COMMENT 'rp is the short form of reward points',
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `shipping_address` text DEFAULT NULL,
  `shipping_custom_field_details` longtext DEFAULT NULL,
  `is_export` tinyint(1) NOT NULL DEFAULT 0,
  `export_custom_field_1` varchar(191) DEFAULT NULL,
  `export_custom_field_2` varchar(191) DEFAULT NULL,
  `export_custom_field_3` varchar(191) DEFAULT NULL,
  `export_custom_field_4` varchar(191) DEFAULT NULL,
  `export_custom_field_5` varchar(191) DEFAULT NULL,
  `export_custom_field_6` varchar(191) DEFAULT NULL,
  `position` varchar(191) DEFAULT NULL,
  `customer_group_id` int(11) DEFAULT NULL,
  `custom_field1` varchar(191) DEFAULT NULL,
  `custom_field2` varchar(191) DEFAULT NULL,
  `custom_field3` varchar(191) DEFAULT NULL,
  `custom_field4` varchar(191) DEFAULT NULL,
  `custom_field5` varchar(191) DEFAULT NULL,
  `custom_field6` varchar(191) DEFAULT NULL,
  `custom_field7` varchar(191) DEFAULT NULL,
  `custom_field8` varchar(191) DEFAULT NULL,
  `custom_field9` varchar(191) DEFAULT NULL,
  `custom_field10` varchar(191) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contacts_business_id_foreign` (`business_id`),
  KEY `contacts_created_by_foreign` (`created_by`),
  KEY `contacts_type_index` (`type`),
  KEY `contacts_contact_status_index` (`contact_status`),
  CONSTRAINT `contacts_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contacts_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` VALUES
(1,1,'customer',NULL,NULL,'Walk-In Customer',NULL,NULL,NULL,NULL,NULL,'CO0001','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,0.0000,1,0.0000,0,0,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2024-08-01 04:19:13','2024-08-01 04:19:13'),
(2,1,'supplier','individual',NULL,'Ms ARCELI MAXIMO SALVADOR','Ms','ARCELI','MAXIMO','SALVADOR','analizaflotildes02@gmail.com','0999293','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'09385050860',NULL,NULL,NULL,NULL,NULL,1,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-09 11:59:41','2025-01-09 11:59:41'),
(3,1,'customer','individual',NULL,'Mr Andrei MAXIMO Viduya','Mr','Andrei','MAXIMO','Viduya','andrei@gmail.com','111111','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'09385050861',NULL,NULL,NULL,NULL,NULL,1,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-09 12:03:05','2025-01-09 12:03:05'),
(4,2,'customer',NULL,NULL,'Walk-In Customer',NULL,NULL,NULL,NULL,NULL,'CO0001','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,0.0000,4,0.0000,0,0,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-17 12:03:44','2025-01-17 12:03:44'),
(5,1,'customer','individual',NULL,'Mr Andrei Salvador','Mr','Andrei',NULL,'Salvador','sorianozayrene@gmail.com','CO0004','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-16','09275108795',NULL,NULL,1,'days',NULL,1,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-17 12:36:39','2025-01-20 15:46:42'),
(6,2,'customer','individual',NULL,'Mr ARCELI MAXIMO SALVADOR','Mr','ARCELI','MAXIMO','SALVADOR','sorianozayrene@gmail.com','CO0002','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'09275108795',NULL,NULL,NULL,NULL,NULL,4,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-17 12:41:11','2025-01-17 12:41:11'),
(7,3,'customer',NULL,NULL,'Walk-In Customer',NULL,NULL,NULL,NULL,NULL,'CO0001','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,0.0000,11,0.0000,0,0,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 10:41:35','2025-01-23 10:41:35'),
(8,1,'customer','individual',NULL,'JENO LEE',NULL,'JENO',NULL,'LEE',NULL,'CO0005','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0423',NULL,NULL,NULL,NULL,5000.0000,1,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 13:46:47','2025-01-23 13:46:47'),
(9,1,'customer','individual',NULL,'MARK LEE',NULL,'MARK',NULL,'LEE',NULL,'CO0006','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0802',NULL,NULL,NULL,NULL,5000.0000,1,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 13:50:48','2025-01-23 13:50:48'),
(10,1,'customer','individual',NULL,'JAEMIN NA',NULL,'JAEMIN',NULL,'NA',NULL,'CO0007','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0813',NULL,NULL,NULL,NULL,5000.0000,1,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 13:51:26','2025-01-23 13:51:26'),
(11,1,'customer','individual',NULL,'JISUNG PARK',NULL,'JISUNG',NULL,'PARK',NULL,'CO0008','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0205',NULL,NULL,NULL,NULL,5000.0000,1,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 13:51:57','2025-01-23 13:51:57'),
(12,1,'customer','individual',NULL,'HAECHAN LEE',NULL,'HAECHAN',NULL,'LEE',NULL,'CO0009','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0606',NULL,NULL,NULL,NULL,5000.0000,1,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 13:52:23','2025-01-23 13:52:23'),
(13,1,'supplier','individual',NULL,'JENO LEE',NULL,'JENO',NULL,'LEE',NULL,'CO0010','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'042300',NULL,NULL,NULL,NULL,5000.0000,1,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 13:55:26','2025-01-23 13:55:26'),
(14,1,'supplier','individual',NULL,'MARK LEE',NULL,'MARK',NULL,'LEE',NULL,'CO0011','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'080299',NULL,NULL,NULL,NULL,5000.0000,1,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 13:55:46','2025-01-23 13:55:46'),
(15,1,'supplier','individual',NULL,'JAEMIN NA',NULL,'JAEMIN',NULL,'NA',NULL,'CO0012','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'081300',NULL,NULL,NULL,NULL,5000.0000,1,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 13:56:02','2025-01-23 13:56:02'),
(16,1,'supplier','individual',NULL,'JISUNG PARK',NULL,'JISUNG',NULL,'PARK',NULL,'CO0013','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'020502',NULL,NULL,NULL,NULL,5000.0000,1,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 13:56:22','2025-01-23 13:56:22'),
(17,1,'supplier','individual',NULL,'HAECHAN LEE',NULL,'HAECHAN',NULL,'LEE',NULL,'CO0014','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'060600',NULL,NULL,NULL,NULL,5000.0000,1,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 13:56:41','2025-01-23 13:56:41');
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currencies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `country` varchar(100) NOT NULL,
  `currency` varchar(100) NOT NULL,
  `code` varchar(25) NOT NULL,
  `symbol` varchar(25) NOT NULL,
  `thousand_separator` varchar(10) NOT NULL,
  `decimal_separator` varchar(10) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=142 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `currencies` WRITE;
/*!40000 ALTER TABLE `currencies` DISABLE KEYS */;
INSERT INTO `currencies` VALUES
(1,'Albania','Leke','ALL','Lek',',','.',NULL,NULL),
(2,'America','Dollars','USD','$',',','.',NULL,NULL),
(3,'Afghanistan','Afghanis','AF','؋',',','.',NULL,NULL),
(4,'Argentina','Pesos','ARS','$',',','.',NULL,NULL),
(5,'Aruba','Guilders','AWG','ƒ',',','.',NULL,NULL),
(6,'Australia','Dollars','AUD','$',',','.',NULL,NULL),
(7,'Azerbaijan','New Manats','AZ','ман',',','.',NULL,NULL),
(8,'Bahamas','Dollars','BSD','$',',','.',NULL,NULL),
(9,'Barbados','Dollars','BBD','$',',','.',NULL,NULL),
(10,'Belarus','Rubles','BYR','p.',',','.',NULL,NULL),
(11,'Belgium','Euro','EUR','€',',','.',NULL,NULL),
(12,'Beliz','Dollars','BZD','BZ$',',','.',NULL,NULL),
(13,'Bermuda','Dollars','BMD','$',',','.',NULL,NULL),
(14,'Bolivia','Bolivianos','BOB','$b',',','.',NULL,NULL),
(15,'Bosnia and Herzegovina','Convertible Marka','BAM','KM',',','.',NULL,NULL),
(16,'Botswana','Pula\'s','BWP','P',',','.',NULL,NULL),
(17,'Bulgaria','Leva','BG','лв',',','.',NULL,NULL),
(18,'Brazil','Reais','BRL','R$',',','.',NULL,NULL),
(19,'Britain [United Kingdom]','Pounds','GBP','£',',','.',NULL,NULL),
(20,'Brunei Darussalam','Dollars','BND','$',',','.',NULL,NULL),
(21,'Cambodia','Riels','KHR','៛',',','.',NULL,NULL),
(22,'Canada','Dollars','CAD','$',',','.',NULL,NULL),
(23,'Cayman Islands','Dollars','KYD','$',',','.',NULL,NULL),
(24,'Chile','Pesos','CLP','$',',','.',NULL,NULL),
(25,'China','Yuan Renminbi','CNY','¥',',','.',NULL,NULL),
(26,'Colombia','Pesos','COP','$',',','.',NULL,NULL),
(27,'Costa Rica','Colón','CRC','₡',',','.',NULL,NULL),
(28,'Croatia','Kuna','HRK','kn',',','.',NULL,NULL),
(29,'Cuba','Pesos','CUP','₱',',','.',NULL,NULL),
(30,'Cyprus','Euro','EUR','€','.',',',NULL,NULL),
(31,'Czech Republic','Koruny','CZK','Kč',',','.',NULL,NULL),
(32,'Denmark','Kroner','DKK','kr',',','.',NULL,NULL),
(33,'Dominican Republic','Pesos','DOP ','RD$',',','.',NULL,NULL),
(34,'East Caribbean','Dollars','XCD','$',',','.',NULL,NULL),
(35,'Egypt','Pounds','EGP','£',',','.',NULL,NULL),
(36,'El Salvador','Colones','SVC','$',',','.',NULL,NULL),
(37,'England [United Kingdom]','Pounds','GBP','£',',','.',NULL,NULL),
(38,'Euro','Euro','EUR','€','.',',',NULL,NULL),
(39,'Falkland Islands','Pounds','FKP','£',',','.',NULL,NULL),
(40,'Fiji','Dollars','FJD','$',',','.',NULL,NULL),
(41,'France','Euro','EUR','€','.',',',NULL,NULL),
(42,'Ghana','Cedis','GHS','¢',',','.',NULL,NULL),
(43,'Gibraltar','Pounds','GIP','£',',','.',NULL,NULL),
(44,'Greece','Euro','EUR','€','.',',',NULL,NULL),
(45,'Guatemala','Quetzales','GTQ','Q',',','.',NULL,NULL),
(46,'Guernsey','Pounds','GGP','£',',','.',NULL,NULL),
(47,'Guyana','Dollars','GYD','$',',','.',NULL,NULL),
(48,'Holland [Netherlands]','Euro','EUR','€','.',',',NULL,NULL),
(49,'Honduras','Lempiras','HNL','L',',','.',NULL,NULL),
(50,'Hong Kong','Dollars','HKD','$',',','.',NULL,NULL),
(51,'Hungary','Forint','HUF','Ft',',','.',NULL,NULL),
(52,'Iceland','Kronur','ISK','kr',',','.',NULL,NULL),
(53,'India','Rupees','INR','₹',',','.',NULL,NULL),
(54,'Indonesia','Rupiahs','IDR','Rp',',','.',NULL,NULL),
(55,'Iran','Rials','IRR','﷼',',','.',NULL,NULL),
(56,'Ireland','Euro','EUR','€','.',',',NULL,NULL),
(57,'Isle of Man','Pounds','IMP','£',',','.',NULL,NULL),
(58,'Israel','New Shekels','ILS','₪',',','.',NULL,NULL),
(59,'Italy','Euro','EUR','€','.',',',NULL,NULL),
(60,'Jamaica','Dollars','JMD','J$',',','.',NULL,NULL),
(61,'Japan','Yen','JPY','¥',',','.',NULL,NULL),
(62,'Jersey','Pounds','JEP','£',',','.',NULL,NULL),
(63,'Kazakhstan','Tenge','KZT','лв',',','.',NULL,NULL),
(64,'Korea [North]','Won','KPW','₩',',','.',NULL,NULL),
(65,'Korea [South]','Won','KRW','₩',',','.',NULL,NULL),
(66,'Kyrgyzstan','Soms','KGS','лв',',','.',NULL,NULL),
(67,'Laos','Kips','LAK','₭',',','.',NULL,NULL),
(68,'Latvia','Lati','LVL','Ls',',','.',NULL,NULL),
(69,'Lebanon','Pounds','LBP','£',',','.',NULL,NULL),
(70,'Liberia','Dollars','LRD','$',',','.',NULL,NULL),
(71,'Liechtenstein','Switzerland Francs','CHF','CHF',',','.',NULL,NULL),
(72,'Lithuania','Litai','LTL','Lt',',','.',NULL,NULL),
(73,'Luxembourg','Euro','EUR','€','.',',',NULL,NULL),
(74,'Macedonia','Denars','MKD','ден',',','.',NULL,NULL),
(75,'Malaysia','Ringgits','MYR','RM',',','.',NULL,NULL),
(76,'Malta','Euro','EUR','€','.',',',NULL,NULL),
(77,'Mauritius','Rupees','MUR','₨',',','.',NULL,NULL),
(78,'Mexico','Pesos','MXN','$',',','.',NULL,NULL),
(79,'Mongolia','Tugriks','MNT','₮',',','.',NULL,NULL),
(80,'Mozambique','Meticais','MZ','MT',',','.',NULL,NULL),
(81,'Namibia','Dollars','NAD','$',',','.',NULL,NULL),
(82,'Nepal','Rupees','NPR','₨',',','.',NULL,NULL),
(83,'Netherlands Antilles','Guilders','ANG','ƒ',',','.',NULL,NULL),
(84,'Netherlands','Euro','EUR','€','.',',',NULL,NULL),
(85,'New Zealand','Dollars','NZD','$',',','.',NULL,NULL),
(86,'Nicaragua','Cordobas','NIO','C$',',','.',NULL,NULL),
(87,'Nigeria','Nairas','NGN','₦',',','.',NULL,NULL),
(88,'North Korea','Won','KPW','₩',',','.',NULL,NULL),
(89,'Norway','Krone','NOK','kr',',','.',NULL,NULL),
(90,'Oman','Rials','OMR','﷼',',','.',NULL,NULL),
(91,'Pakistan','Rupees','PKR','₨',',','.',NULL,NULL),
(92,'Panama','Balboa','PAB','B/.',',','.',NULL,NULL),
(93,'Paraguay','Guarani','PYG','Gs',',','.',NULL,NULL),
(94,'Peru','Nuevos Soles','PE','S/.',',','.',NULL,NULL),
(95,'Philippines','Pesos','PHP','Php',',','.',NULL,NULL),
(96,'Poland','Zlotych','PL','zł',',','.',NULL,NULL),
(97,'Qatar','Rials','QAR','﷼',',','.',NULL,NULL),
(98,'Romania','New Lei','RO','lei',',','.',NULL,NULL),
(99,'Russia','Rubles','RUB','руб',',','.',NULL,NULL),
(100,'Saint Helena','Pounds','SHP','£',',','.',NULL,NULL),
(101,'Saudi Arabia','Riyals','SAR','﷼',',','.',NULL,NULL),
(102,'Serbia','Dinars','RSD','Дин.',',','.',NULL,NULL),
(103,'Seychelles','Rupees','SCR','₨',',','.',NULL,NULL),
(104,'Singapore','Dollars','SGD','$',',','.',NULL,NULL),
(105,'Slovenia','Euro','EUR','€','.',',',NULL,NULL),
(106,'Solomon Islands','Dollars','SBD','$',',','.',NULL,NULL),
(107,'Somalia','Shillings','SOS','S',',','.',NULL,NULL),
(108,'South Africa','Rand','ZAR','R',',','.',NULL,NULL),
(109,'South Korea','Won','KRW','₩',',','.',NULL,NULL),
(110,'Spain','Euro','EUR','€','.',',',NULL,NULL),
(111,'Sri Lanka','Rupees','LKR','₨',',','.',NULL,NULL),
(112,'Sweden','Kronor','SEK','kr',',','.',NULL,NULL),
(113,'Switzerland','Francs','CHF','CHF',',','.',NULL,NULL),
(114,'Suriname','Dollars','SRD','$',',','.',NULL,NULL),
(115,'Syria','Pounds','SYP','£',',','.',NULL,NULL),
(116,'Taiwan','New Dollars','TWD','NT$',',','.',NULL,NULL),
(117,'Thailand','Baht','THB','฿',',','.',NULL,NULL),
(118,'Trinidad and Tobago','Dollars','TTD','TT$',',','.',NULL,NULL),
(119,'Turkey','Lira','TRY','TL',',','.',NULL,NULL),
(120,'Turkey','Liras','TRL','£',',','.',NULL,NULL),
(121,'Tuvalu','Dollars','TVD','$',',','.',NULL,NULL),
(122,'Ukraine','Hryvnia','UAH','₴',',','.',NULL,NULL),
(123,'United Kingdom','Pounds','GBP','£',',','.',NULL,NULL),
(124,'United States of America','Dollars','USD','$',',','.',NULL,NULL),
(125,'Uruguay','Pesos','UYU','$U',',','.',NULL,NULL),
(126,'Uzbekistan','Sums','UZS','лв',',','.',NULL,NULL),
(127,'Vatican City','Euro','EUR','€','.',',',NULL,NULL),
(128,'Venezuela','Bolivares Fuertes','VEF','Bs',',','.',NULL,NULL),
(129,'Vietnam','Dong','VND','₫',',','.',NULL,NULL),
(130,'Yemen','Rials','YER','﷼',',','.',NULL,NULL),
(131,'Zimbabwe','Zimbabwe Dollars','ZWD','Z$',',','.',NULL,NULL),
(132,'Iraq','Iraqi dinar','IQD','د.ع',',','.',NULL,NULL),
(133,'Kenya','Kenyan shilling','KES','KSh',',','.',NULL,NULL),
(134,'Bangladesh','Taka','BDT','৳',',','.',NULL,NULL),
(135,'Algerie','Algerian dinar','DZD','د.ج',' ','.',NULL,NULL),
(136,'United Arab Emirates','United Arab Emirates dirham','AED','د.إ',',','.',NULL,NULL),
(137,'Uganda','Uganda shillings','UGX','USh',',','.',NULL,NULL),
(138,'Tanzania','Tanzanian shilling','TZS','TSh',',','.',NULL,NULL),
(139,'Angola','Kwanza','AOA','Kz',',','.',NULL,NULL),
(140,'Kuwait','Kuwaiti dinar','KWD','KD',',','.',NULL,NULL),
(141,'Bahrain','Bahraini dinar','BHD','BD',',','.',NULL,NULL);
/*!40000 ALTER TABLE `currencies` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `customer_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `name` varchar(191) NOT NULL,
  `amount` double(5,2) NOT NULL,
  `price_calculation_type` varchar(191) DEFAULT 'percentage',
  `selling_price_group_id` int(11) DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_groups_business_id_foreign` (`business_id`),
  KEY `customer_groups_created_by_index` (`created_by`),
  KEY `customer_groups_price_calculation_type_index` (`price_calculation_type`),
  KEY `customer_groups_selling_price_group_id_index` (`selling_price_group_id`),
  CONSTRAINT `customer_groups_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `customer_groups` WRITE;
/*!40000 ALTER TABLE `customer_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_groups` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `dashboard_configurations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboard_configurations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `created_by` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `color` varchar(191) NOT NULL,
  `configuration` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dashboard_configurations_business_id_foreign` (`business_id`),
  CONSTRAINT `dashboard_configurations_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `dashboard_configurations` WRITE;
/*!40000 ALTER TABLE `dashboard_configurations` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboard_configurations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `discount_variations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discount_variations` (
  `discount_id` int(11) NOT NULL,
  `variation_id` int(11) NOT NULL,
  KEY `discount_variations_discount_id_index` (`discount_id`),
  KEY `discount_variations_variation_id_index` (`variation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `discount_variations` WRITE;
/*!40000 ALTER TABLE `discount_variations` DISABLE KEYS */;
INSERT INTO `discount_variations` VALUES
(1,1);
/*!40000 ALTER TABLE `discount_variations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `discounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `business_id` int(11) NOT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `discount_type` varchar(191) DEFAULT NULL,
  `discount_amount` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `starts_at` datetime DEFAULT NULL,
  `ends_at` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `spg` varchar(100) DEFAULT NULL COMMENT 'Applicable in specified selling price group only. Use of applicable_in_spg column is discontinued',
  `applicable_in_cg` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `discounts_business_id_index` (`business_id`),
  KEY `discounts_brand_id_index` (`brand_id`),
  KEY `discounts_category_id_index` (`category_id`),
  KEY `discounts_location_id_index` (`location_id`),
  KEY `discounts_priority_index` (`priority`),
  KEY `discounts_spg_index` (`spg`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `discounts` WRITE;
/*!40000 ALTER TABLE `discounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `discounts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `document_and_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `document_and_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `notable_id` int(11) NOT NULL,
  `notable_type` varchar(191) NOT NULL,
  `heading` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_private` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `document_and_notes_business_id_index` (`business_id`),
  KEY `document_and_notes_notable_id_index` (`notable_id`),
  KEY `document_and_notes_created_by_index` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `document_and_notes` WRITE;
/*!40000 ALTER TABLE `document_and_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `document_and_notes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_allowances_and_deductions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_allowances_and_deductions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `description` varchar(191) NOT NULL,
  `type` enum('allowance','deduction') NOT NULL,
  `amount` decimal(22,4) NOT NULL,
  `amount_type` enum('fixed','percent') NOT NULL,
  `applicable_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_allowances_and_deductions_business_id_index` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_allowances_and_deductions` WRITE;
/*!40000 ALTER TABLE `essentials_allowances_and_deductions` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_allowances_and_deductions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_attendances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_attendances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `business_id` int(11) NOT NULL,
  `clock_in_time` datetime DEFAULT NULL,
  `clock_out_time` datetime DEFAULT NULL,
  `essentials_shift_id` int(11) DEFAULT NULL,
  `ip_address` varchar(191) DEFAULT NULL,
  `clock_in_note` text DEFAULT NULL,
  `clock_out_note` text DEFAULT NULL,
  `clock_in_location` text DEFAULT NULL,
  `clock_out_location` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_attendances_user_id_index` (`user_id`),
  KEY `essentials_attendances_business_id_index` (`business_id`),
  KEY `essentials_attendances_essentials_shift_id_index` (`essentials_shift_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_attendances` WRITE;
/*!40000 ALTER TABLE `essentials_attendances` DISABLE KEYS */;
INSERT INTO `essentials_attendances` VALUES
(1,4,2,'2025-01-17 15:43:43','2025-01-17 15:43:55',3,'64.224.105.24',NULL,NULL,NULL,'','2025-01-17 15:43:43','2025-01-17 15:43:55'),
(2,4,2,'2025-01-17 15:45:30','2025-01-17 15:45:37',3,'64.224.105.24',NULL,NULL,NULL,'','2025-01-17 15:45:30','2025-01-17 15:45:37'),
(3,4,2,'2025-01-17 15:45:51',NULL,4,'64.224.105.24',NULL,NULL,NULL,NULL,'2025-01-17 15:45:51','2025-01-17 15:45:51'),
(4,1,1,'2025-01-20 19:13:34',NULL,6,'64.224.105.17',NULL,NULL,NULL,NULL,'2025-01-20 19:13:34','2025-01-20 19:13:34');
/*!40000 ALTER TABLE `essentials_attendances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_document_shares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_document_shares` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `document_id` int(11) NOT NULL,
  `value_type` enum('user','role') NOT NULL,
  `value` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_document_shares_document_id_index` (`document_id`),
  KEY `essentials_document_shares_value_type_index` (`value_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_document_shares` WRITE;
/*!40000 ALTER TABLE `essentials_document_shares` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_document_shares` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_documents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(191) DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `description` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_documents` WRITE;
/*!40000 ALTER TABLE `essentials_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_documents` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_holidays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_holidays` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `business_id` int(11) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_holidays_business_id_index` (`business_id`),
  KEY `essentials_holidays_location_id_index` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_holidays` WRITE;
/*!40000 ALTER TABLE `essentials_holidays` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_holidays` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_kb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_kb` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` bigint(20) unsigned NOT NULL,
  `title` varchar(191) NOT NULL,
  `content` longtext DEFAULT NULL,
  `status` varchar(191) NOT NULL,
  `kb_type` varchar(191) NOT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL COMMENT 'id from essentials_kb table',
  `share_with` varchar(191) DEFAULT NULL COMMENT 'public, private, only_with',
  `created_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_kb_business_id_index` (`business_id`),
  KEY `essentials_kb_parent_id_index` (`parent_id`),
  KEY `essentials_kb_created_by_index` (`created_by`),
  CONSTRAINT `essentials_kb_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `essentials_kb` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_kb` WRITE;
/*!40000 ALTER TABLE `essentials_kb` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_kb` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_kb_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_kb_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `kb_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_kb_users_kb_id_index` (`kb_id`),
  KEY `essentials_kb_users_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_kb_users` WRITE;
/*!40000 ALTER TABLE `essentials_kb_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_kb_users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_leave_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_leave_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `leave_type` varchar(191) NOT NULL,
  `max_leave_count` int(11) DEFAULT NULL,
  `leave_count_interval` enum('month','year') DEFAULT NULL,
  `business_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_leave_types_business_id_index` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_leave_types` WRITE;
/*!40000 ALTER TABLE `essentials_leave_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_leave_types` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_leaves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_leaves` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `essentials_leave_type_id` int(11) DEFAULT NULL,
  `business_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `ref_no` varchar(191) DEFAULT NULL,
  `status` enum('pending','approved','cancelled') DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `status_note` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_leaves_essentials_leave_type_id_index` (`essentials_leave_type_id`),
  KEY `essentials_leaves_business_id_index` (`business_id`),
  KEY `essentials_leaves_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_leaves` WRITE;
/*!40000 ALTER TABLE `essentials_leaves` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_leaves` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_messages_business_id_index` (`business_id`),
  KEY `essentials_messages_user_id_index` (`user_id`),
  KEY `essentials_messages_location_id_index` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_messages` WRITE;
/*!40000 ALTER TABLE `essentials_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_messages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_payroll_group_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_payroll_group_transactions` (
  `payroll_group_id` bigint(20) unsigned NOT NULL,
  `transaction_id` int(11) NOT NULL,
  KEY `essentials_payroll_group_transactions_payroll_group_id_foreign` (`payroll_group_id`),
  CONSTRAINT `essentials_payroll_group_transactions_payroll_group_id_foreign` FOREIGN KEY (`payroll_group_id`) REFERENCES `essentials_payroll_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_payroll_group_transactions` WRITE;
/*!40000 ALTER TABLE `essentials_payroll_group_transactions` DISABLE KEYS */;
INSERT INTO `essentials_payroll_group_transactions` VALUES
(1,15);
/*!40000 ALTER TABLE `essentials_payroll_group_transactions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_payroll_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_payroll_groups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `location_id` int(11) DEFAULT NULL COMMENT 'payroll for work location',
  `name` varchar(191) NOT NULL,
  `status` varchar(191) NOT NULL,
  `payment_status` varchar(191) NOT NULL DEFAULT 'due',
  `gross_total` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_payroll_groups` WRITE;
/*!40000 ALTER TABLE `essentials_payroll_groups` DISABLE KEYS */;
INSERT INTO `essentials_payroll_groups` VALUES
(1,2,2,'Payroll for January 2025','final','due',11000.0000,4,'2025-01-17 15:48:51','2025-01-17 15:48:51');
/*!40000 ALTER TABLE `essentials_payroll_groups` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_reminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_reminders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `end_time` time DEFAULT NULL,
  `repeat` enum('one_time','every_day','every_week','every_month') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_reminders_business_id_index` (`business_id`),
  KEY `essentials_reminders_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_reminders` WRITE;
/*!40000 ALTER TABLE `essentials_reminders` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_reminders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_shifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_shifts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `type` enum('fixed_shift','flexible_shift') NOT NULL DEFAULT 'fixed_shift',
  `business_id` int(11) NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `is_allowed_auto_clockout` tinyint(1) NOT NULL DEFAULT 0,
  `auto_clockout_time` time DEFAULT NULL,
  `holidays` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_shifts_type_index` (`type`),
  KEY `essentials_shifts_business_id_index` (`business_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_shifts` WRITE;
/*!40000 ALTER TABLE `essentials_shifts` DISABLE KEYS */;
INSERT INTO `essentials_shifts` VALUES
(1,'Arcelie','fixed_shift',2,'13:06:00','16:06:00',0,NULL,NULL,'2025-01-17 13:06:36','2025-01-17 13:06:36'),
(2,'ANDREI','fixed_shift',2,'15:40:00','21:39:00',1,'19:00:00',NULL,'2025-01-17 15:39:55','2025-01-20 19:07:04'),
(3,'Order','flexible_shift',2,NULL,NULL,0,NULL,NULL,'2025-01-17 15:43:22','2025-01-17 15:43:22'),
(4,'Table 1','fixed_shift',2,'15:50:00','23:44:00',0,NULL,NULL,'2025-01-17 15:45:11','2025-01-17 15:45:11'),
(5,'DeulDigital','fixed_shift',1,'19:10:00','21:27:00',0,NULL,NULL,'2025-01-20 16:27:45','2025-01-20 16:32:52'),
(6,'Table 1','fixed_shift',1,'19:15:00','19:20:00',0,NULL,NULL,'2025-01-20 16:38:47','2025-01-20 16:38:47'),
(7,'ANDREI','fixed_shift',1,'19:22:00','20:42:00',0,NULL,NULL,'2025-01-20 16:42:58','2025-01-20 16:42:58');
/*!40000 ALTER TABLE `essentials_shifts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_to_dos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_to_dos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `task` text NOT NULL,
  `date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `task_id` varchar(191) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `status` varchar(191) DEFAULT NULL,
  `estimated_hours` varchar(191) DEFAULT NULL,
  `priority` varchar(191) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_to_dos_status_index` (`status`),
  KEY `essentials_to_dos_priority_index` (`priority`),
  KEY `essentials_to_dos_created_by_index` (`created_by`),
  KEY `essentials_to_dos_business_id_index` (`business_id`),
  KEY `essentials_to_dos_task_id_index` (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_to_dos` WRITE;
/*!40000 ALTER TABLE `essentials_to_dos` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_to_dos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_todo_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_todo_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `comment` text NOT NULL,
  `task_id` int(11) NOT NULL,
  `comment_by` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_todo_comments_task_id_index` (`task_id`),
  KEY `essentials_todo_comments_comment_by_index` (`comment_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_todo_comments` WRITE;
/*!40000 ALTER TABLE `essentials_todo_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_todo_comments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_todos_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_todos_users` (
  `todo_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_todos_users` WRITE;
/*!40000 ALTER TABLE `essentials_todos_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_todos_users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_user_allowance_and_deductions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_user_allowance_and_deductions` (
  `user_id` int(11) NOT NULL,
  `allowance_deduction_id` int(11) NOT NULL,
  KEY `essentials_user_allowance_and_deductions_user_id_index` (`user_id`),
  KEY `allow_deduct_index` (`allowance_deduction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_user_allowance_and_deductions` WRITE;
/*!40000 ALTER TABLE `essentials_user_allowance_and_deductions` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_user_allowance_and_deductions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_user_sales_targets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_user_sales_targets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `target_start` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `target_end` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `commission_percent` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_user_sales_targets` WRITE;
/*!40000 ALTER TABLE `essentials_user_sales_targets` DISABLE KEYS */;
INSERT INTO `essentials_user_sales_targets` VALUES
(1,1,1000000.0000,20000000.0000,5.0000,'2025-01-17 12:20:59','2025-01-17 12:20:59');
/*!40000 ALTER TABLE `essentials_user_sales_targets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_user_shifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_user_shifts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `essentials_shift_id` int(11) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_user_shifts_user_id_index` (`user_id`),
  KEY `essentials_user_shifts_essentials_shift_id_index` (`essentials_shift_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_user_shifts` WRITE;
/*!40000 ALTER TABLE `essentials_user_shifts` DISABLE KEYS */;
INSERT INTO `essentials_user_shifts` VALUES
(6,6,3,'2025-01-17','2025-01-24','2025-01-17 15:43:40','2025-01-17 15:43:40'),
(7,4,4,'2025-01-17','2025-01-24','2025-01-17 15:45:25','2025-01-17 15:45:25'),
(8,6,4,'2025-01-17','2025-01-24','2025-01-17 15:45:25','2025-01-17 15:45:25'),
(10,3,5,'2025-01-20','2025-01-20','2025-01-20 16:31:03','2025-01-20 16:38:06'),
(11,5,5,'2025-01-20','2025-01-20','2025-01-20 16:31:03','2025-01-20 16:38:06'),
(12,1,6,'2025-01-20','2025-01-31','2025-01-20 16:38:58','2025-01-20 16:38:58'),
(13,1,7,'2025-01-20','2025-01-27','2025-01-20 16:43:09','2025-01-20 16:43:09');
/*!40000 ALTER TABLE `essentials_user_shifts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `expense_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expense_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `business_id` int(10) unsigned NOT NULL,
  `code` varchar(191) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `expense_categories_business_id_foreign` (`business_id`),
  CONSTRAINT `expense_categories_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `expense_categories` WRITE;
/*!40000 ALTER TABLE `expense_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `expense_categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `group_sub_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_sub_taxes` (
  `group_tax_id` int(10) unsigned NOT NULL,
  `tax_id` int(10) unsigned NOT NULL,
  KEY `group_sub_taxes_group_tax_id_foreign` (`group_tax_id`),
  KEY `group_sub_taxes_tax_id_foreign` (`tax_id`),
  CONSTRAINT `group_sub_taxes_group_tax_id_foreign` FOREIGN KEY (`group_tax_id`) REFERENCES `tax_rates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `group_sub_taxes_tax_id_foreign` FOREIGN KEY (`tax_id`) REFERENCES `tax_rates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `group_sub_taxes` WRITE;
/*!40000 ALTER TABLE `group_sub_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_sub_taxes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `invoice_layouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice_layouts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `header_text` text DEFAULT NULL,
  `invoice_no_prefix` varchar(191) DEFAULT NULL,
  `quotation_no_prefix` varchar(191) DEFAULT NULL,
  `invoice_heading` varchar(191) DEFAULT NULL,
  `sub_heading_line1` varchar(191) DEFAULT NULL,
  `sub_heading_line2` varchar(191) DEFAULT NULL,
  `sub_heading_line3` varchar(191) DEFAULT NULL,
  `sub_heading_line4` varchar(191) DEFAULT NULL,
  `sub_heading_line5` varchar(191) DEFAULT NULL,
  `invoice_heading_not_paid` varchar(191) DEFAULT NULL,
  `invoice_heading_paid` varchar(191) DEFAULT NULL,
  `quotation_heading` varchar(191) DEFAULT NULL,
  `sub_total_label` varchar(191) DEFAULT NULL,
  `discount_label` varchar(191) DEFAULT NULL,
  `tax_label` varchar(191) DEFAULT NULL,
  `total_label` varchar(191) DEFAULT NULL,
  `round_off_label` varchar(191) DEFAULT NULL,
  `total_due_label` varchar(191) DEFAULT NULL,
  `paid_label` varchar(191) DEFAULT NULL,
  `show_client_id` tinyint(1) NOT NULL DEFAULT 0,
  `client_id_label` varchar(191) DEFAULT NULL,
  `client_tax_label` varchar(191) DEFAULT NULL,
  `date_label` varchar(191) DEFAULT NULL,
  `date_time_format` varchar(191) DEFAULT NULL,
  `show_time` tinyint(1) NOT NULL DEFAULT 1,
  `show_brand` tinyint(1) NOT NULL DEFAULT 0,
  `show_sku` tinyint(1) NOT NULL DEFAULT 1,
  `show_cat_code` tinyint(1) NOT NULL DEFAULT 1,
  `show_expiry` tinyint(1) NOT NULL DEFAULT 0,
  `show_lot` tinyint(1) NOT NULL DEFAULT 0,
  `show_image` tinyint(1) NOT NULL DEFAULT 0,
  `show_sale_description` tinyint(1) NOT NULL DEFAULT 0,
  `sales_person_label` varchar(191) DEFAULT NULL,
  `show_sales_person` tinyint(1) NOT NULL DEFAULT 0,
  `table_product_label` varchar(191) DEFAULT NULL,
  `table_qty_label` varchar(191) DEFAULT NULL,
  `table_unit_price_label` varchar(191) DEFAULT NULL,
  `table_subtotal_label` varchar(191) DEFAULT NULL,
  `cat_code_label` varchar(191) DEFAULT NULL,
  `logo` varchar(191) DEFAULT NULL,
  `show_logo` tinyint(1) NOT NULL DEFAULT 0,
  `show_business_name` tinyint(1) NOT NULL DEFAULT 0,
  `show_location_name` tinyint(1) NOT NULL DEFAULT 1,
  `show_landmark` tinyint(1) NOT NULL DEFAULT 1,
  `show_city` tinyint(1) NOT NULL DEFAULT 1,
  `show_state` tinyint(1) NOT NULL DEFAULT 1,
  `show_zip_code` tinyint(1) NOT NULL DEFAULT 1,
  `show_country` tinyint(1) NOT NULL DEFAULT 1,
  `show_mobile_number` tinyint(1) NOT NULL DEFAULT 1,
  `show_alternate_number` tinyint(1) NOT NULL DEFAULT 0,
  `show_email` tinyint(1) NOT NULL DEFAULT 0,
  `show_tax_1` tinyint(1) NOT NULL DEFAULT 1,
  `show_tax_2` tinyint(1) NOT NULL DEFAULT 0,
  `show_barcode` tinyint(1) NOT NULL DEFAULT 0,
  `show_payments` tinyint(1) NOT NULL DEFAULT 0,
  `show_customer` tinyint(1) NOT NULL DEFAULT 0,
  `customer_label` varchar(191) DEFAULT NULL,
  `commission_agent_label` varchar(191) DEFAULT NULL,
  `show_commission_agent` tinyint(1) NOT NULL DEFAULT 0,
  `show_reward_point` tinyint(1) NOT NULL DEFAULT 0,
  `highlight_color` varchar(10) DEFAULT NULL,
  `footer_text` text DEFAULT NULL,
  `module_info` text DEFAULT NULL,
  `common_settings` text DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `business_id` int(10) unsigned NOT NULL,
  `show_letter_head` tinyint(1) NOT NULL DEFAULT 0,
  `letter_head` varchar(191) DEFAULT NULL,
  `show_qr_code` tinyint(1) NOT NULL DEFAULT 0,
  `qr_code_fields` text DEFAULT NULL,
  `design` varchar(190) DEFAULT 'classic',
  `cn_heading` varchar(191) DEFAULT NULL COMMENT 'cn = credit note',
  `cn_no_label` varchar(191) DEFAULT NULL,
  `cn_amount_label` varchar(191) DEFAULT NULL,
  `table_tax_headings` text DEFAULT NULL,
  `show_previous_bal` tinyint(1) NOT NULL DEFAULT 0,
  `prev_bal_label` varchar(191) DEFAULT NULL,
  `change_return_label` varchar(191) DEFAULT NULL,
  `product_custom_fields` text DEFAULT NULL,
  `contact_custom_fields` text DEFAULT NULL,
  `location_custom_fields` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_layouts_business_id_foreign` (`business_id`),
  CONSTRAINT `invoice_layouts_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `invoice_layouts` WRITE;
/*!40000 ALTER TABLE `invoice_layouts` DISABLE KEYS */;
INSERT INTO `invoice_layouts` VALUES
(1,'Default',NULL,'Invoice No.',NULL,'Invoice',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Subtotal','Discount','Tax','Total',NULL,'Total Due','Total Paid',1,NULL,NULL,'Date',NULL,1,0,1,1,0,0,0,0,NULL,0,'Product','Quantity','Unit Price','Subtotal',NULL,'1737596723_PRIMARY LOGO (1).png',1,1,1,1,1,1,1,1,1,0,0,0,0,1,1,1,'Customer',NULL,0,1,'#000000',NULL,'{\"types_of_service\":{\"types_of_service_label\":null,\"show_types_of_service\":\"1\"},\"tables\":{\"table_label\":null},\"service_staff\":{\"service_staff_label\":null}}','{\"proforma_heading\":null,\"sales_order_heading\":null,\"due_date_label\":null,\"show_due_date\":\"1\",\"total_quantity_label\":null,\"item_discount_label\":null,\"discounted_unit_price_label\":null,\"show_product_description\":\"1\",\"total_items_label\":null,\"num_to_word_format\":\"international\",\"tax_summary_label\":\"##\",\"show_qr_code_label\":\"1\",\"zatca_qr\":\"1\"}',1,1,0,NULL,0,'[\"business_name\",\"tax_1\",\"tax_2\",\"invoice_no\",\"invoice_datetime\",\"total_amount\",\"total_tax\"]','slim2',NULL,NULL,NULL,'[\"VAT\",\"NONVAT\",null,null]',0,NULL,'Change',NULL,NULL,NULL,'2024-08-01 04:19:13','2025-01-23 14:49:06'),
(2,'Default',NULL,'Invoice No.',NULL,'Invoice',NULL,NULL,NULL,NULL,NULL,'','',NULL,'Subtotal','Discount','Tax','Total',NULL,'Total Due','Total Paid',0,NULL,NULL,'Date',NULL,1,0,1,1,0,0,0,0,NULL,0,'Product','Quantity','Unit Price','Subtotal',NULL,NULL,0,0,1,1,1,1,1,1,1,0,0,1,0,0,1,1,'Customer',NULL,0,0,'#000000','',NULL,NULL,1,2,0,NULL,0,NULL,'classic',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'2025-01-17 12:03:44','2025-01-17 12:03:44'),
(3,'Default',NULL,'Invoice No.',NULL,'Invoice',NULL,NULL,NULL,NULL,NULL,'','',NULL,'Subtotal','Discount','Tax','Total',NULL,'Total Due','Total Paid',0,NULL,NULL,'Date',NULL,1,0,1,1,0,0,0,0,NULL,0,'Product','Quantity','Unit Price','Subtotal',NULL,NULL,0,0,1,1,1,1,1,1,1,0,0,1,0,0,1,1,'Customer',NULL,0,0,'#000000','',NULL,NULL,1,3,0,NULL,0,NULL,'classic',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'2025-01-23 10:41:35','2025-01-23 10:41:35');
/*!40000 ALTER TABLE `invoice_layouts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `invoice_schemes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice_schemes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `name` varchar(191) NOT NULL,
  `scheme_type` enum('blank','year') NOT NULL,
  `number_type` varchar(100) NOT NULL DEFAULT 'sequential',
  `prefix` varchar(191) DEFAULT NULL,
  `start_number` int(11) DEFAULT NULL,
  `invoice_count` int(11) NOT NULL DEFAULT 0,
  `total_digits` int(11) DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_schemes_business_id_foreign` (`business_id`),
  KEY `invoice_schemes_scheme_type_index` (`scheme_type`),
  KEY `invoice_schemes_number_type_index` (`number_type`),
  CONSTRAINT `invoice_schemes_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `invoice_schemes` WRITE;
/*!40000 ALTER TABLE `invoice_schemes` DISABLE KEYS */;
INSERT INTO `invoice_schemes` VALUES
(1,1,'Default','year','sequential',NULL,1,65,8,1,'2024-08-01 04:19:13','2025-01-23 14:49:26'),
(2,2,'Default','blank','sequential','',1,0,4,1,'2025-01-17 12:03:44','2025-01-17 12:03:44'),
(3,3,'Default','blank','sequential','',1,0,4,1,'2025-01-23 10:41:35','2025-01-23 10:41:35');
/*!40000 ALTER TABLE `invoice_schemes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `file_name` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `uploaded_by` int(11) DEFAULT NULL,
  `model_type` varchar(191) NOT NULL,
  `model_media_type` varchar(191) DEFAULT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `media_model_type_model_id_index` (`model_type`,`model_id`),
  KEY `media_business_id_index` (`business_id`),
  KEY `media_uploaded_by_index` (`uploaded_by`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
INSERT INTO `media` VALUES
(1,1,'1736404085_2027297823_Copy of SARAH AND AHA (25).png',NULL,1,'App\\Product',NULL,1,'2025-01-09 11:58:05','2025-01-09 11:58:05'),
(3,1,'1736929204_962255555_Untitled (Logo) (1).png',NULL,1,'App\\Product',NULL,2,'2025-01-15 13:50:04','2025-01-15 13:50:04'),
(4,1,'1737369832_1136037742_1 (3).png',NULL,1,'App\\User',NULL,1,'2025-01-20 16:13:52','2025-01-20 16:13:52');
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=353 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'2014_10_12_000000_create_users_table',1),
(2,'2014_10_12_100000_create_password_resets_table',1),
(3,'2016_06_01_000001_create_oauth_auth_codes_table',1),
(4,'2016_06_01_000002_create_oauth_access_tokens_table',1),
(5,'2016_06_01_000003_create_oauth_refresh_tokens_table',1),
(6,'2016_06_01_000004_create_oauth_clients_table',1),
(7,'2016_06_01_000005_create_oauth_personal_access_clients_table',1),
(8,'2017_07_05_071953_create_currencies_table',1),
(9,'2017_07_05_073658_create_business_table',1),
(10,'2017_07_22_075923_add_business_id_users_table',1),
(11,'2017_07_23_113209_create_brands_table',1),
(12,'2017_07_26_083429_create_permission_tables',1),
(13,'2017_07_26_110000_create_tax_rates_table',1),
(14,'2017_07_26_122313_create_units_table',1),
(15,'2017_07_27_075706_create_contacts_table',1),
(16,'2017_08_04_071038_create_categories_table',1),
(17,'2017_08_08_115903_create_products_table',1),
(18,'2017_08_09_061616_create_variation_templates_table',1),
(19,'2017_08_09_061638_create_variation_value_templates_table',1),
(20,'2017_08_10_061146_create_product_variations_table',1),
(21,'2017_08_10_061216_create_variations_table',1),
(22,'2017_08_19_054827_create_transactions_table',1),
(23,'2017_08_31_073533_create_purchase_lines_table',1),
(24,'2017_10_15_064638_create_transaction_payments_table',1),
(25,'2017_10_31_065621_add_default_sales_tax_to_business_table',1),
(26,'2017_11_20_051930_create_table_group_sub_taxes',1),
(27,'2017_11_20_063603_create_transaction_sell_lines',1),
(28,'2017_11_21_064540_create_barcodes_table',1),
(29,'2017_11_23_181237_create_invoice_schemes_table',1),
(30,'2017_12_25_122822_create_business_locations_table',1),
(31,'2017_12_25_160253_add_location_id_to_transactions_table',1),
(32,'2017_12_25_163227_create_variation_location_details_table',1),
(33,'2018_01_04_115627_create_sessions_table',1),
(34,'2018_01_05_112817_create_invoice_layouts_table',1),
(35,'2018_01_06_112303_add_invoice_scheme_id_and_invoice_layout_id_to_business_locations',1),
(36,'2018_01_08_104124_create_expense_categories_table',1),
(37,'2018_01_08_123327_modify_transactions_table_for_expenses',1),
(38,'2018_01_09_111005_modify_payment_status_in_transactions_table',1),
(39,'2018_01_09_111109_add_paid_on_column_to_transaction_payments_table',1),
(40,'2018_01_25_172439_add_printer_related_fields_to_business_locations_table',1),
(41,'2018_01_27_184322_create_printers_table',1),
(42,'2018_01_30_181442_create_cash_registers_table',1),
(43,'2018_01_31_125836_create_cash_register_transactions_table',1),
(44,'2018_02_07_173326_modify_business_table',1),
(45,'2018_02_08_105425_add_enable_product_expiry_column_to_business_table',1),
(46,'2018_02_08_111027_add_expiry_period_and_expiry_period_type_columns_to_products_table',1),
(47,'2018_02_08_131118_add_mfg_date_and_exp_date_purchase_lines_table',1),
(48,'2018_02_08_155348_add_exchange_rate_to_transactions_table',1),
(49,'2018_02_09_124945_modify_transaction_payments_table_for_contact_payments',1),
(50,'2018_02_12_113640_create_transaction_sell_lines_purchase_lines_table',1),
(51,'2018_02_12_114605_add_quantity_sold_in_purchase_lines_table',1),
(52,'2018_02_13_183323_alter_decimal_fields_size',1),
(53,'2018_02_14_161928_add_transaction_edit_days_to_business_table',1),
(54,'2018_02_15_161032_add_document_column_to_transactions_table',1),
(55,'2018_02_17_124709_add_more_options_to_invoice_layouts',1),
(56,'2018_02_19_111517_add_keyboard_shortcut_column_to_business_table',1),
(57,'2018_02_19_121537_stock_adjustment_move_to_transaction_table',1),
(58,'2018_02_20_165505_add_is_direct_sale_column_to_transactions_table',1),
(59,'2018_02_21_105329_create_system_table',1),
(60,'2018_02_23_100549_version_1_2',1),
(61,'2018_02_23_125648_add_enable_editing_sp_from_purchase_column_to_business_table',1),
(62,'2018_02_26_103612_add_sales_commission_agent_column_to_business_table',1),
(63,'2018_02_26_130519_modify_users_table_for_sales_cmmsn_agnt',1),
(64,'2018_02_26_134500_add_commission_agent_to_transactions_table',1),
(65,'2018_02_27_121422_add_item_addition_method_to_business_table',1),
(66,'2018_02_27_170232_modify_transactions_table_for_stock_transfer',1),
(67,'2018_03_05_153510_add_enable_inline_tax_column_to_business_table',1),
(68,'2018_03_06_210206_modify_product_barcode_types',1),
(69,'2018_03_13_181541_add_expiry_type_to_business_table',1),
(70,'2018_03_16_113446_product_expiry_setting_for_business',1),
(71,'2018_03_19_113601_add_business_settings_options',1),
(72,'2018_03_26_125334_add_pos_settings_to_business_table',1),
(73,'2018_03_26_165350_create_customer_groups_table',1),
(74,'2018_03_27_122720_customer_group_related_changes_in_tables',1),
(75,'2018_03_29_110138_change_tax_field_to_nullable_in_business_table',1),
(76,'2018_03_29_115502_add_changes_for_sr_number_in_products_and_sale_lines_table',1),
(77,'2018_03_29_134340_add_inline_discount_fields_in_purchase_lines',1),
(78,'2018_03_31_140921_update_transactions_table_exchange_rate',1),
(79,'2018_04_03_103037_add_contact_id_to_contacts_table',1),
(80,'2018_04_03_122709_add_changes_to_invoice_layouts_table',1),
(81,'2018_04_09_135320_change_exchage_rate_size_in_business_table',1),
(82,'2018_04_17_123122_add_lot_number_to_business',1),
(83,'2018_04_17_160845_add_product_racks_table',1),
(84,'2018_04_20_182015_create_res_tables_table',1),
(85,'2018_04_24_105246_restaurant_fields_in_transaction_table',1),
(86,'2018_04_24_114149_add_enabled_modules_business_table',1),
(87,'2018_04_24_133704_add_modules_fields_in_invoice_layout_table',1),
(88,'2018_04_27_132653_quotation_related_change',1),
(89,'2018_05_02_104439_add_date_format_and_time_format_to_business',1),
(90,'2018_05_02_111939_add_sell_return_to_transaction_payments',1),
(91,'2018_05_14_114027_add_rows_positions_for_products',1),
(92,'2018_05_14_125223_add_weight_to_products_table',1),
(93,'2018_05_14_164754_add_opening_stock_permission',1),
(94,'2018_05_15_134729_add_design_to_invoice_layouts',1),
(95,'2018_05_16_183307_add_tax_fields_invoice_layout',1),
(96,'2018_05_18_191956_add_sell_return_to_transaction_table',1),
(97,'2018_05_21_131349_add_custom_fileds_to_contacts_table',1),
(98,'2018_05_21_131607_invoice_layout_fields_for_sell_return',1),
(99,'2018_05_21_131949_add_custom_fileds_and_website_to_business_locations_table',1),
(100,'2018_05_22_123527_create_reference_counts_table',1),
(101,'2018_05_22_154540_add_ref_no_prefixes_column_to_business_table',1),
(102,'2018_05_24_132620_add_ref_no_column_to_transaction_payments_table',1),
(103,'2018_05_24_161026_add_location_id_column_to_business_location_table',1),
(104,'2018_05_25_180603_create_modifiers_related_table',1),
(105,'2018_05_29_121714_add_purchase_line_id_to_stock_adjustment_line_table',1),
(106,'2018_05_31_114645_add_res_order_status_column_to_transactions_table',1),
(107,'2018_06_05_103530_rename_purchase_line_id_in_stock_adjustment_lines_table',1),
(108,'2018_06_05_111905_modify_products_table_for_modifiers',1),
(109,'2018_06_06_110524_add_parent_sell_line_id_column_to_transaction_sell_lines_table',1),
(110,'2018_06_07_152443_add_is_service_staff_to_roles_table',1),
(111,'2018_06_07_182258_add_image_field_to_products_table',1),
(112,'2018_06_13_133705_create_bookings_table',1),
(113,'2018_06_15_173636_add_email_column_to_contacts_table',1),
(114,'2018_06_27_182835_add_superadmin_related_fields_business',1),
(115,'2018_07_10_101913_add_custom_fields_to_products_table',1),
(116,'2018_07_17_103434_add_sales_person_name_label_to_invoice_layouts_table',1),
(117,'2018_07_17_163920_add_theme_skin_color_column_to_business_table',1),
(118,'2018_07_24_160319_add_lot_no_line_id_to_transaction_sell_lines_table',1),
(119,'2018_07_25_110004_add_show_expiry_and_show_lot_colums_to_invoice_layouts_table',1),
(120,'2018_07_25_172004_add_discount_columns_to_transaction_sell_lines_table',1),
(121,'2018_07_26_124720_change_design_column_type_in_invoice_layouts_table',1),
(122,'2018_07_26_170424_add_unit_price_before_discount_column_to_transaction_sell_line_table',1),
(123,'2018_07_28_103614_add_credit_limit_column_to_contacts_table',1),
(124,'2018_08_08_110755_add_new_payment_methods_to_transaction_payments_table',1),
(125,'2018_08_08_122225_modify_cash_register_transactions_table_for_new_payment_methods',1),
(126,'2018_08_14_104036_add_opening_balance_type_to_transactions_table',1),
(127,'2018_09_04_155900_create_accounts_table',1),
(128,'2018_09_06_114438_create_selling_price_groups_table',1),
(129,'2018_09_06_154057_create_variation_group_prices_table',1),
(130,'2018_09_07_102413_add_permission_to_access_default_selling_price',1),
(131,'2018_09_07_134858_add_selling_price_group_id_to_transactions_table',1),
(132,'2018_09_10_112448_update_product_type_to_single_if_null_in_products_table',1),
(133,'2018_09_10_152703_create_account_transactions_table',1),
(134,'2018_09_10_173656_add_account_id_column_to_transaction_payments_table',1),
(135,'2018_09_19_123914_create_notification_templates_table',1),
(136,'2018_09_22_110504_add_sms_and_email_settings_columns_to_business_table',1),
(137,'2018_09_24_134942_add_lot_no_line_id_to_stock_adjustment_lines_table',1),
(138,'2018_09_26_105557_add_transaction_payments_for_existing_expenses',1),
(139,'2018_09_27_111609_modify_transactions_table_for_purchase_return',1),
(140,'2018_09_27_131154_add_quantity_returned_column_to_purchase_lines_table',1),
(141,'2018_10_02_131401_add_return_quantity_column_to_transaction_sell_lines_table',1),
(142,'2018_10_03_104918_add_qty_returned_column_to_transaction_sell_lines_purchase_lines_table',1),
(143,'2018_10_03_185947_add_default_notification_templates_to_database',1),
(144,'2018_10_09_153105_add_business_id_to_transaction_payments_table',1),
(145,'2018_10_16_135229_create_permission_for_sells_and_purchase',1),
(146,'2018_10_22_114441_add_columns_for_variable_product_modifications',1),
(147,'2018_10_22_134428_modify_variable_product_data',1),
(148,'2018_10_30_181558_add_table_tax_headings_to_invoice_layout',1),
(149,'2018_10_31_122619_add_pay_terms_field_transactions_table',1),
(150,'2018_10_31_161328_add_new_permissions_for_pos_screen',1),
(151,'2018_10_31_174752_add_access_selected_contacts_only_to_users_table',1),
(152,'2018_10_31_175627_add_user_contact_access',1),
(153,'2018_10_31_180559_add_auto_send_sms_column_to_notification_templates_table',1),
(154,'2018_11_02_171949_change_card_type_column_to_varchar_in_transaction_payments_table',1),
(155,'2018_11_08_105621_add_role_permissions',1),
(156,'2018_11_26_114135_add_is_suspend_column_to_transactions_table',1),
(157,'2018_11_28_104410_modify_units_table_for_multi_unit',1),
(158,'2018_11_28_170952_add_sub_unit_id_to_purchase_lines_and_sell_lines',1),
(159,'2018_11_29_115918_add_primary_key_in_system_table',1),
(160,'2018_12_03_185546_add_product_description_column_to_products_table',1),
(161,'2018_12_06_114937_modify_system_table_and_users_table',1),
(162,'2018_12_13_160007_add_custom_fields_display_options_to_invoice_layouts_table',1),
(163,'2018_12_14_103307_modify_system_table',1),
(164,'2018_12_18_133837_add_prev_balance_due_columns_to_invoice_layouts_table',1),
(165,'2018_12_18_170656_add_invoice_token_column_to_transaction_table',1),
(166,'2018_12_20_133639_add_date_time_format_column_to_invoice_layouts_table',1),
(167,'2018_12_21_120659_add_recurring_invoice_fields_to_transactions_table',1),
(168,'2018_12_24_154933_create_notifications_table',1),
(169,'2019_01_08_112015_add_document_column_to_transaction_payments_table',1),
(170,'2019_01_10_124645_add_account_permission',1),
(171,'2019_01_16_125825_add_subscription_no_column_to_transactions_table',1),
(172,'2019_01_28_111647_add_order_addresses_column_to_transactions_table',1),
(173,'2019_02_13_173821_add_is_inactive_column_to_products_table',1),
(174,'2019_02_19_103118_create_discounts_table',1),
(175,'2019_02_21_120324_add_discount_id_column_to_transaction_sell_lines_table',1),
(176,'2019_02_21_134324_add_permission_for_discount',1),
(177,'2019_03_04_170832_add_service_staff_columns_to_transaction_sell_lines_table',1),
(178,'2019_03_09_102425_add_sub_type_column_to_transactions_table',1),
(179,'2019_03_09_124457_add_indexing_transaction_sell_lines_purchase_lines_table',1),
(180,'2019_03_12_120336_create_activity_log_table',1),
(181,'2019_03_15_132925_create_media_table',1),
(182,'2019_05_08_130339_add_indexing_to_parent_id_in_transaction_payments_table',1),
(183,'2019_05_10_132311_add_missing_column_indexing',1),
(184,'2019_05_14_091812_add_show_image_column_to_invoice_layouts_table',1),
(185,'2019_05_25_104922_add_view_purchase_price_permission',1),
(186,'2019_06_17_103515_add_profile_informations_columns_to_users_table',1),
(187,'2019_06_18_135524_add_permission_to_view_own_sales_only',1),
(188,'2019_06_19_112058_add_database_changes_for_reward_points',1),
(189,'2019_06_28_133732_change_type_column_to_string_in_transactions_table',1),
(190,'2019_07_13_111420_add_is_created_from_api_column_to_transactions_table',1),
(191,'2019_07_15_165136_add_fields_for_combo_product',1),
(192,'2019_07_19_103446_add_mfg_quantity_used_column_to_purchase_lines_table',1),
(193,'2019_07_22_152649_add_not_for_selling_in_product_table',1),
(194,'2019_07_29_185351_add_show_reward_point_column_to_invoice_layouts_table',1),
(195,'2019_08_08_162302_add_sub_units_related_fields',1),
(196,'2019_08_26_133419_update_price_fields_decimal_point',1),
(197,'2019_09_02_160054_remove_location_permissions_from_roles',1),
(198,'2019_09_03_185259_add_permission_for_pos_screen',1),
(199,'2019_09_04_163141_add_location_id_to_cash_registers_table',1),
(200,'2019_09_04_184008_create_types_of_services_table',1),
(201,'2019_09_06_131445_add_types_of_service_fields_to_transactions_table',1),
(202,'2019_09_09_134810_add_default_selling_price_group_id_column_to_business_locations_table',1),
(203,'2019_09_12_105616_create_product_locations_table',1),
(204,'2019_09_17_122522_add_custom_labels_column_to_business_table',1),
(205,'2019_09_18_164319_add_shipping_fields_to_transactions_table',1),
(206,'2019_09_19_170927_close_all_active_registers',1),
(207,'2019_09_23_161906_add_media_description_cloumn_to_media_table',1),
(208,'2019_10_18_155633_create_account_types_table',1),
(209,'2019_10_22_163335_add_common_settings_column_to_business_table',1),
(210,'2019_10_29_132521_add_update_purchase_status_permission',1),
(211,'2019_11_09_110522_add_indexing_to_lot_number',1),
(212,'2019_11_19_170824_add_is_active_column_to_business_locations_table',1),
(213,'2019_11_21_162913_change_quantity_field_types_to_decimal',1),
(214,'2019_11_25_160340_modify_categories_table_for_polymerphic_relationship',1),
(215,'2019_12_02_105025_create_warranties_table',1),
(216,'2019_12_03_180342_add_common_settings_field_to_invoice_layouts_table',1),
(217,'2019_12_05_183955_add_more_fields_to_users_table',1),
(218,'2019_12_06_174904_add_change_return_label_column_to_invoice_layouts_table',1),
(219,'2019_12_11_121307_add_draft_and_quotation_list_permissions',1),
(220,'2019_12_12_180126_copy_expense_total_to_total_before_tax',1),
(221,'2019_12_19_181412_make_alert_quantity_field_nullable_on_products_table',1),
(222,'2019_12_25_173413_create_dashboard_configurations_table',1),
(223,'2020_01_08_133506_create_document_and_notes_table',1),
(224,'2020_01_09_113252_add_cc_bcc_column_to_notification_templates_table',1),
(225,'2020_01_16_174818_add_round_off_amount_field_to_transactions_table',1),
(226,'2020_01_28_162345_add_weighing_scale_settings_in_business_settings_table',1),
(227,'2020_02_18_172447_add_import_fields_to_transactions_table',1),
(228,'2020_03_13_135844_add_is_active_column_to_selling_price_groups_table',1),
(229,'2020_03_16_115449_add_contact_status_field_to_contacts_table',1),
(230,'2020_03_26_124736_add_allow_login_column_in_users_table',1),
(231,'2020_04_13_154150_add_feature_products_column_to_business_loactions',1),
(232,'2020_04_15_151802_add_user_type_to_users_table',1),
(233,'2020_04_22_153905_add_subscription_repeat_on_column_to_transactions_table',1),
(234,'2020_04_28_111436_add_shipping_address_to_contacts_table',1),
(235,'2020_06_01_094654_add_max_sale_discount_column_to_users_table',1),
(236,'2020_06_12_162245_modify_contacts_table',1),
(237,'2020_06_22_103104_change_recur_interval_default_to_one',1),
(238,'2020_07_09_174621_add_balance_field_to_contacts_table',1),
(239,'2020_07_23_104933_change_status_column_to_varchar_in_transaction_table',1),
(240,'2020_09_07_171059_change_completed_stock_transfer_status_to_final',1),
(241,'2020_09_21_123224_modify_booking_status_column_in_bookings_table',1),
(242,'2020_09_22_121639_create_discount_variations_table',1),
(243,'2020_10_05_121550_modify_business_location_table_for_invoice_layout',1),
(244,'2020_10_16_175726_set_status_as_received_for_opening_stock',1),
(245,'2020_10_23_170823_add_for_group_tax_column_to_tax_rates_table',1),
(246,'2020_11_04_130940_add_more_custom_fields_to_contacts_table',1),
(247,'2020_11_10_152841_add_cash_register_permissions',1),
(248,'2020_11_17_164041_modify_type_column_to_varchar_in_contacts_table',1),
(249,'2020_12_18_181447_add_shipping_custom_fields_to_transactions_table',1),
(250,'2020_12_22_164303_add_sub_status_column_to_transactions_table',1),
(251,'2020_12_24_153050_add_custom_fields_to_transactions_table',1),
(252,'2020_12_28_105403_add_whatsapp_text_column_to_notification_templates_table',1),
(253,'2020_12_29_165925_add_model_document_type_to_media_table',1),
(254,'2021_02_08_175632_add_contact_number_fields_to_users_table',1),
(255,'2021_02_11_172217_add_indexing_for_multiple_columns',1),
(256,'2021_02_23_122043_add_more_columns_to_customer_groups_table',1),
(257,'2021_02_24_175551_add_print_invoice_permission_to_all_roles',1),
(258,'2021_03_03_162021_add_purchase_order_columns_to_purchase_lines_and_transactions_table',1),
(259,'2021_03_11_120229_add_sales_order_columns',1),
(260,'2021_03_16_120705_add_business_id_to_activity_log_table',1),
(261,'2021_03_16_153427_add_code_columns_to_business_table',1),
(262,'2021_03_18_173308_add_account_details_column_to_accounts_table',1),
(263,'2021_03_18_183119_add_prefer_payment_account_columns_to_transactions_table',1),
(264,'2021_03_22_120810_add_more_types_of_service_custom_fields',1),
(265,'2021_03_24_183132_add_shipping_export_custom_field_details_to_contacts_table',1),
(266,'2021_03_25_170715_add_export_custom_fields_info_to_transactions_table',1),
(267,'2021_04_15_063449_add_denominations_column_to_cash_registers_table',1),
(268,'2021_05_22_083426_add_indexing_to_account_transactions_table',1),
(269,'2021_07_08_065808_add_additional_expense_columns_to_transaction_table',1),
(270,'2021_07_13_082918_add_qr_code_columns_to_invoice_layouts_table',1),
(271,'2021_07_21_061615_add_fields_to_show_commission_agent_in_invoice_layout',1),
(272,'2021_08_13_105549_add_crm_contact_id_to_users_table',1),
(273,'2021_08_25_114932_add_payment_link_fields_to_transaction_payments_table',1),
(274,'2021_09_01_063110_add_spg_column_to_discounts_table',1),
(275,'2021_09_03_061528_modify_cash_register_transactions_table',1),
(276,'2021_10_05_061658_add_source_column_to_transactions_table',1),
(277,'2021_12_16_121851_add_parent_id_column_to_expense_categories_table',1),
(278,'2022_04_14_075120_add_payment_type_column_to_transaction_payments_table',1),
(279,'2022_04_21_083327_create_cash_denominations_table',1),
(280,'2022_05_10_055307_add_delivery_date_column_to_transactions_table',1),
(281,'2022_06_13_123135_add_currency_precision_and_quantity_precision_fields_to_business_table',1),
(282,'2022_06_28_133342_add_secondary_unit_columns_to_products_sell_line_purchase_lines_tables',1),
(283,'2022_07_13_114307_create_purchase_requisition_related_columns',1),
(284,'2022_08_25_132707_add_service_staff_timer_fields_to_products_and_users_table',1),
(285,'2023_01_28_114255_add_letter_head_column_to_invoice_layouts_table',1),
(286,'2023_02_11_161510_add_event_column_to_activity_log_table',1),
(287,'2023_02_11_161511_add_batch_uuid_column_to_activity_log_table',1),
(288,'2023_03_02_170312_add_provider_to_oauth_clients_table',1),
(289,'2023_03_21_122731_add_sale_invoice_scheme_id_business_table',1),
(290,'2023_03_21_170446_add_number_type_to_invoice_scheme',1),
(291,'2023_04_17_155216_add_custom_fields_to_products',1),
(292,'2023_04_28_130247_add_price_type_to_group_price_table',1),
(293,'2023_06_21_033923_add_delivery_person_in_transactions',1),
(294,'2023_09_13_153555_add_service_staff_pin_columns_in_users',1),
(295,'2023_09_15_154404_add_is_kitchen_order_in_transactions',1),
(296,'2023_12_06_152840_add_contact_type_in_contacts',1),
(297,'2018_06_27_185405_create_packages_table',2),
(298,'2018_06_28_182803_create_subscriptions_table',2),
(299,'2018_07_17_182021_add_rows_to_system_table',2),
(300,'2018_07_19_131721_add_options_to_packages_table',2),
(301,'2018_08_17_155534_add_min_termination_alert_days',2),
(302,'2018_08_28_105945_add_business_based_username_settings_to_system_table',2),
(303,'2018_08_30_105906_add_superadmin_communicator_logs_table',2),
(304,'2018_11_02_130636_add_custom_permissions_to_packages_table',2),
(305,'2018_11_05_161848_add_more_fields_to_packages_table',2),
(306,'2018_12_10_124621_modify_system_table_values_null_default',2),
(307,'2019_05_10_135434_add_missing_database_column_indexes',2),
(308,'2019_08_16_115300_create_superadmin_frontend_pages_table',2),
(309,'2023_06_10_132121_create_coupons_table',2),
(310,'2023_06_16_141928_add_column_in_subscriptions',2),
(311,'2023_06_29_183442_add_mark_package_as_popular',2),
(312,'2023_07_04_151432_add_column_business',2),
(313,'2023_07_13_191306_add_businesses_column_in_coupons',2),
(314,'2018_10_01_151252_create_documents_table',3),
(315,'2018_10_02_151803_create_document_shares_table',3),
(316,'2018_10_09_134558_create_reminders_table',3),
(317,'2018_11_16_170756_create_to_dos_table',3),
(318,'2019_02_22_120329_essentials_messages',3),
(319,'2019_02_22_161513_add_message_permissions',3),
(320,'2019_03_29_164339_add_essentials_version_to_system_table',3),
(321,'2019_05_17_153306_create_essentials_leave_types_table',3),
(322,'2019_05_17_175921_create_essentials_leaves_table',3),
(323,'2019_05_21_154517_add_essentials_settings_columns_to_business_table',3),
(324,'2019_05_21_181653_create_table_essentials_attendance',3),
(325,'2019_05_30_110049_create_essentials_payrolls_table',3),
(326,'2019_06_04_105723_create_essentials_holidays_table',3),
(327,'2019_06_28_134217_add_payroll_columns_to_transactions_table',3),
(328,'2019_08_26_103520_add_approve_leave_permission',3),
(329,'2019_08_27_103724_create_essentials_allowance_and_deduction_table',3),
(330,'2019_08_27_105236_create_essentials_user_allowances_and_deductions',3),
(331,'2019_09_20_115906_add_more_columns_to_essentials_to_dos_table',3),
(332,'2019_09_23_120439_create_essentials_todo_comments_table',3),
(333,'2019_12_05_170724_add_hrm_columns_to_users_table',3),
(334,'2019_12_09_105809_add_allowance_and_deductions_permission',3),
(335,'2020_03_28_152838_create_essentials_shift_table',3),
(336,'2020_03_30_162029_create_user_shifts_table',3),
(337,'2020_03_31_134558_add_shift_id_to_attendance_table',3),
(338,'2020_11_05_105157_modify_todos_date_column_type',3),
(339,'2020_11_11_174852_add_end_time_column_to_essentials_reminders_table',3),
(340,'2020_11_26_170527_create_essentials_kb_table',3),
(341,'2020_11_30_112615_create_essentials_kb_users_table',3),
(342,'2021_02_12_185514_add_clock_in_location_to_essentials_attendances_table',3),
(343,'2021_02_16_190203_add_essentials_module_indexing',3),
(344,'2021_02_27_133448_add_columns_to_users_table',3),
(345,'2021_03_04_174857_create_payroll_groups_table',3),
(346,'2021_03_04_175025_create_payroll_group_transactions_table',3),
(347,'2021_03_09_123914_add_auto_clockout_to_essentials_shifts',3),
(348,'2021_06_17_121451_add_location_id_to_table',3),
(349,'2021_09_28_091541_create_essentials_user_sales_targets_table',3),
(350,'2024_02_27_081100_AddApprovePosPermission',4),
(351,'2023_02_17_140135_AddVersionForAiAssistance',5),
(352,'2023_02_21_182321_create_aiassistance_generation_table',5);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` int(10) unsigned NOT NULL,
  `model_type` varchar(191) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_type_model_id_index` (`model_type`,`model_id`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
INSERT INTO `model_has_permissions` VALUES
(80,'App\\User',3),
(80,'App\\User',5),
(80,'App\\User',9),
(80,'App\\User',10),
(80,'App\\User',12),
(80,'App\\User',13),
(80,'App\\User',14),
(80,'App\\User',15),
(80,'App\\User',16),
(89,'App\\User',6);
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` int(10) unsigned NOT NULL,
  `model_type` varchar(191) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_type_model_id_index` (`model_type`,`model_id`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES
(1,'App\\User',1),
(1,'App\\User',10),
(2,'App\\User',3),
(3,'App\\User',4),
(4,'App\\User',6),
(5,'App\\User',5),
(6,'App\\User',9),
(6,'App\\User',12),
(8,'App\\User',11),
(10,'App\\User',13),
(11,'App\\User',14),
(12,'App\\User',16),
(13,'App\\User',15);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notification_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `template_for` varchar(191) NOT NULL,
  `email_body` text DEFAULT NULL,
  `sms_body` text DEFAULT NULL,
  `whatsapp_text` text DEFAULT NULL,
  `subject` varchar(191) DEFAULT NULL,
  `cc` varchar(191) DEFAULT NULL,
  `bcc` varchar(191) DEFAULT NULL,
  `auto_send` tinyint(1) NOT NULL DEFAULT 0,
  `auto_send_sms` tinyint(1) NOT NULL DEFAULT 0,
  `auto_send_wa_notif` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notification_templates` WRITE;
/*!40000 ALTER TABLE `notification_templates` DISABLE KEYS */;
INSERT INTO `notification_templates` VALUES
(1,1,'new_sale','<p>Dear {contact_name},</p>\n\n                    <p>Your invoice number is {invoice_number}<br />\n                    Total amount: {total_amount}<br />\n                    Paid amount: {received_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2024-08-01 04:19:13','2024-08-01 04:19:13'),
(2,1,'payment_received','<p>Dear {contact_name},</p>\n\n                <p>We have received a payment of {received_amount}</p>\n\n                <p>{business_logo}</p>','Dear {contact_name}, We have received a payment of {received_amount}. {business_name}',NULL,'Payment Received, from {business_name}',NULL,NULL,0,0,0,'2024-08-01 04:19:13','2024-08-01 04:19:13'),
(3,1,'payment_reminder','<p>Dear {contact_name},</p>\n\n                    <p>This is to remind you that you have pending payment of {due_amount}. Kindly pay it as soon as possible.</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, You have pending payment of {due_amount}. Kindly pay it as soon as possible. {business_name}',NULL,'Payment Reminder, from {business_name}',NULL,NULL,0,0,0,'2024-08-01 04:19:13','2024-08-01 04:19:13'),
(4,1,'new_booking','<p>Dear {contact_name},</p>\n\n                    <p>Your booking is confirmed</p>\n\n                    <p>Date: {start_time} to {end_time}</p>\n\n                    <p>Table: {table}</p>\n\n                    <p>Location: {location}</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, Your booking is confirmed. Date: {start_time} to {end_time}, Table: {table}, Location: {location}',NULL,'Booking Confirmed - {business_name}',NULL,NULL,0,0,0,'2024-08-01 04:19:13','2024-08-01 04:19:13'),
(5,1,'new_order','<p>Dear {contact_name},</p>\n\n                    <p>We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','Dear {contact_name}, We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible. {business_name}',NULL,'New Order, from {business_name}',NULL,NULL,0,0,0,'2024-08-01 04:19:13','2024-08-01 04:19:13'),
(6,1,'payment_paid','<p>Dear {contact_name},</p>\n\n                    <p>We have paid amount {paid_amount} again invoice number {order_ref_number}.<br />\n                    Kindly note it down.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have paid amount {paid_amount} again invoice number {order_ref_number}.\n                    Kindly note it down. {business_name}',NULL,'Payment Paid, from {business_name}',NULL,NULL,0,0,0,'2024-08-01 04:19:13','2024-08-01 04:19:13'),
(7,1,'items_received','<p>Dear {contact_name},</p>\n\n                    <p>We have received all items from invoice reference number {order_ref_number}. Thank you for processing it.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have received all items from invoice reference number {order_ref_number}. Thank you for processing it. {business_name}',NULL,'Items received, from {business_name}',NULL,NULL,0,0,0,'2024-08-01 04:19:13','2024-08-01 04:19:13'),
(8,1,'items_pending','<p>Dear {contact_name},<br />\n                    This is to remind you that we have not yet received some items from invoice reference number {order_ref_number}. Please process it as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','This is to remind you that we have not yet received some items from invoice reference number {order_ref_number} . Please process it as soon as possible.{business_name}',NULL,'Items Pending, from {business_name}',NULL,NULL,0,0,0,'2024-08-01 04:19:13','2024-08-01 04:19:13'),
(9,1,'new_quotation','<p>Dear {contact_name},</p>\n\n                    <p>Your quotation number is {invoice_number}<br />\n                    Total amount: {total_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2024-08-01 04:19:13','2024-08-01 04:19:13'),
(10,1,'purchase_order','<p>Dear {contact_name},</p>\n\n                    <p>We have a new purchase order with reference number {order_ref_number}. The respective invoice is attached here with.</p>\n\n                    <p>{business_logo}</p>','We have a new purchase order with reference number {order_ref_number}. {business_name}',NULL,'New Purchase Order, from {business_name}',NULL,NULL,0,0,0,'2024-08-01 04:19:13','2024-08-01 04:19:13'),
(11,2,'new_sale','<p>Dear {contact_name},</p>\n\n                    <p>Your invoice number is {invoice_number}<br />\n                    Total amount: {total_amount}<br />\n                    Paid amount: {received_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2025-01-17 12:03:44','2025-01-17 12:03:44'),
(12,2,'payment_received','<p>Dear {contact_name},</p>\n\n                <p>We have received a payment of {received_amount}</p>\n\n                <p>{business_logo}</p>','Dear {contact_name}, We have received a payment of {received_amount}. {business_name}',NULL,'Payment Received, from {business_name}',NULL,NULL,0,0,0,'2025-01-17 12:03:44','2025-01-17 12:03:44'),
(13,2,'payment_reminder','<p>Dear {contact_name},</p>\n\n                    <p>This is to remind you that you have pending payment of {due_amount}. Kindly pay it as soon as possible.</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, You have pending payment of {due_amount}. Kindly pay it as soon as possible. {business_name}',NULL,'Payment Reminder, from {business_name}',NULL,NULL,0,0,0,'2025-01-17 12:03:44','2025-01-17 12:03:44'),
(14,2,'new_booking','<p>Dear {contact_name},</p>\n\n                    <p>Your booking is confirmed</p>\n\n                    <p>Date: {start_time} to {end_time}</p>\n\n                    <p>Table: {table}</p>\n\n                    <p>Location: {location}</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, Your booking is confirmed. Date: {start_time} to {end_time}, Table: {table}, Location: {location}',NULL,'Booking Confirmed - {business_name}',NULL,NULL,0,0,0,'2025-01-17 12:03:44','2025-01-17 12:03:44'),
(15,2,'new_order','<p>Dear {contact_name},</p>\n\n                    <p>We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','Dear {contact_name}, We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible. {business_name}',NULL,'New Order, from {business_name}',NULL,NULL,0,0,0,'2025-01-17 12:03:44','2025-01-17 12:03:44'),
(16,2,'payment_paid','<p>Dear {contact_name},</p>\n\n                    <p>We have paid amount {paid_amount} again invoice number {order_ref_number}.<br />\n                    Kindly note it down.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have paid amount {paid_amount} again invoice number {order_ref_number}.\n                    Kindly note it down. {business_name}',NULL,'Payment Paid, from {business_name}',NULL,NULL,0,0,0,'2025-01-17 12:03:44','2025-01-17 12:03:44'),
(17,2,'items_received','<p>Dear {contact_name},</p>\n\n                    <p>We have received all items from invoice reference number {order_ref_number}. Thank you for processing it.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have received all items from invoice reference number {order_ref_number}. Thank you for processing it. {business_name}',NULL,'Items received, from {business_name}',NULL,NULL,0,0,0,'2025-01-17 12:03:44','2025-01-17 12:03:44'),
(18,2,'items_pending','<p>Dear {contact_name},<br />\n                    This is to remind you that we have not yet received some items from invoice reference number {order_ref_number}. Please process it as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','This is to remind you that we have not yet received some items from invoice reference number {order_ref_number} . Please process it as soon as possible.{business_name}',NULL,'Items Pending, from {business_name}',NULL,NULL,0,0,0,'2025-01-17 12:03:44','2025-01-17 12:03:44'),
(19,2,'new_quotation','<p>Dear {contact_name},</p>\n\n                    <p>Your quotation number is {invoice_number}<br />\n                    Total amount: {total_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2025-01-17 12:03:44','2025-01-17 12:03:44'),
(20,2,'purchase_order','<p>Dear {contact_name},</p>\n\n                    <p>We have a new purchase order with reference number {order_ref_number}. The respective invoice is attached here with.</p>\n\n                    <p>{business_logo}</p>','We have a new purchase order with reference number {order_ref_number}. {business_name}',NULL,'New Purchase Order, from {business_name}',NULL,NULL,0,0,0,'2025-01-17 12:03:44','2025-01-17 12:03:44'),
(21,3,'new_sale','<p>Dear {contact_name},</p>\n\n                    <p>Your invoice number is {invoice_number}<br />\n                    Total amount: {total_amount}<br />\n                    Paid amount: {received_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2025-01-23 10:41:35','2025-01-23 10:41:35'),
(22,3,'payment_received','<p>Dear {contact_name},</p>\n\n                <p>We have received a payment of {received_amount}</p>\n\n                <p>{business_logo}</p>','Dear {contact_name}, We have received a payment of {received_amount}. {business_name}',NULL,'Payment Received, from {business_name}',NULL,NULL,0,0,0,'2025-01-23 10:41:35','2025-01-23 10:41:35'),
(23,3,'payment_reminder','<p>Dear {contact_name},</p>\n\n                    <p>This is to remind you that you have pending payment of {due_amount}. Kindly pay it as soon as possible.</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, You have pending payment of {due_amount}. Kindly pay it as soon as possible. {business_name}',NULL,'Payment Reminder, from {business_name}',NULL,NULL,0,0,0,'2025-01-23 10:41:35','2025-01-23 10:41:35'),
(24,3,'new_booking','<p>Dear {contact_name},</p>\n\n                    <p>Your booking is confirmed</p>\n\n                    <p>Date: {start_time} to {end_time}</p>\n\n                    <p>Table: {table}</p>\n\n                    <p>Location: {location}</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, Your booking is confirmed. Date: {start_time} to {end_time}, Table: {table}, Location: {location}',NULL,'Booking Confirmed - {business_name}',NULL,NULL,0,0,0,'2025-01-23 10:41:35','2025-01-23 10:41:35'),
(25,3,'new_order','<p>Dear {contact_name},</p>\n\n                    <p>We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','Dear {contact_name}, We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible. {business_name}',NULL,'New Order, from {business_name}',NULL,NULL,0,0,0,'2025-01-23 10:41:35','2025-01-23 10:41:35'),
(26,3,'payment_paid','<p>Dear {contact_name},</p>\n\n                    <p>We have paid amount {paid_amount} again invoice number {order_ref_number}.<br />\n                    Kindly note it down.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have paid amount {paid_amount} again invoice number {order_ref_number}.\n                    Kindly note it down. {business_name}',NULL,'Payment Paid, from {business_name}',NULL,NULL,0,0,0,'2025-01-23 10:41:35','2025-01-23 10:41:35'),
(27,3,'items_received','<p>Dear {contact_name},</p>\n\n                    <p>We have received all items from invoice reference number {order_ref_number}. Thank you for processing it.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have received all items from invoice reference number {order_ref_number}. Thank you for processing it. {business_name}',NULL,'Items received, from {business_name}',NULL,NULL,0,0,0,'2025-01-23 10:41:35','2025-01-23 10:41:35'),
(28,3,'items_pending','<p>Dear {contact_name},<br />\n                    This is to remind you that we have not yet received some items from invoice reference number {order_ref_number}. Please process it as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','This is to remind you that we have not yet received some items from invoice reference number {order_ref_number} . Please process it as soon as possible.{business_name}',NULL,'Items Pending, from {business_name}',NULL,NULL,0,0,0,'2025-01-23 10:41:35','2025-01-23 10:41:35'),
(29,3,'new_quotation','<p>Dear {contact_name},</p>\n\n                    <p>Your quotation number is {invoice_number}<br />\n                    Total amount: {total_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2025-01-23 10:41:35','2025-01-23 10:41:35'),
(30,3,'purchase_order','<p>Dear {contact_name},</p>\n\n                    <p>We have a new purchase order with reference number {order_ref_number}. The respective invoice is attached here with.</p>\n\n                    <p>{business_logo}</p>','We have a new purchase order with reference number {order_ref_number}. {business_name}',NULL,'New Purchase Order, from {business_name}',NULL,NULL,0,0,0,'2025-01-23 10:41:35','2025-01-23 10:41:35');
/*!40000 ALTER TABLE `notification_templates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` char(36) NOT NULL,
  `type` varchar(191) NOT NULL,
  `notifiable_type` varchar(191) NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `name` varchar(191) DEFAULT NULL,
  `scopes` text DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_access_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_auth_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `scopes` text DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_auth_codes` WRITE;
/*!40000 ALTER TABLE `oauth_auth_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_auth_codes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `secret` varchar(100) NOT NULL,
  `provider` varchar(191) DEFAULT NULL,
  `redirect` text NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_clients` WRITE;
/*!40000 ALTER TABLE `oauth_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_clients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_personal_access_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_personal_access_clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_personal_access_clients_client_id_index` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_personal_access_clients` WRITE;
/*!40000 ALTER TABLE `oauth_personal_access_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_personal_access_clients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) NOT NULL,
  `access_token_id` varchar(100) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_refresh_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_refresh_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` text NOT NULL,
  `location_count` int(11) NOT NULL COMMENT 'No. of Business Locations, 0 = infinite option.',
  `user_count` int(11) NOT NULL,
  `product_count` int(11) NOT NULL,
  `bookings` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Enable/Disable bookings',
  `kitchen` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Enable/Disable kitchen',
  `order_screen` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Enable/Disable order_screen',
  `tables` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Enable/Disable tables',
  `invoice_count` int(11) NOT NULL,
  `interval` enum('days','months','years') NOT NULL,
  `interval_count` int(11) NOT NULL,
  `trial_days` int(11) NOT NULL,
  `price` decimal(22,4) NOT NULL,
  `custom_permissions` longtext NOT NULL,
  `created_by` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL,
  `mark_package_as_popular` tinyint(1) NOT NULL,
  `businesses` longtext DEFAULT NULL,
  `is_private` tinyint(1) NOT NULL DEFAULT 0,
  `is_one_time` tinyint(1) NOT NULL DEFAULT 0,
  `enable_custom_link` tinyint(1) NOT NULL DEFAULT 0,
  `custom_link` varchar(191) DEFAULT NULL,
  `custom_link_text` varchar(191) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `packages` WRITE;
/*!40000 ALTER TABLE `packages` DISABLE KEYS */;
INSERT INTO `packages` VALUES
(1,'PREMIUM','0',0,0,0,0,0,0,0,0,'years',1,0,0.0000,'{\"aiassistance_max_token\":null,\"essentials_module\":\"1\",\"PosCustom\":\"1\"}',1,1,1,1,NULL,0,1,0,'','',NULL,'2025-01-09 11:54:29','2025-01-23 10:53:18');
/*!40000 ALTER TABLE `packages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `guard_name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=170 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES
(1,'profit_loss_report.view','web','2024-08-01 03:50:49',NULL),
(2,'direct_sell.access','web','2024-08-01 03:50:49',NULL),
(3,'product.opening_stock','web','2024-08-01 03:50:49','2024-08-01 03:50:49'),
(4,'crud_all_bookings','web','2024-08-01 03:50:49','2024-08-01 03:50:49'),
(5,'crud_own_bookings','web','2024-08-01 03:50:49','2024-08-01 03:50:49'),
(6,'access_default_selling_price','web','2024-08-01 03:50:50','2024-08-01 03:50:50'),
(7,'purchase.payments','web','2024-08-01 03:50:50','2024-08-01 03:50:50'),
(8,'sell.payments','web','2024-08-01 03:50:50','2024-08-01 03:50:50'),
(9,'edit_product_price_from_sale_screen','web','2024-08-01 03:50:50','2024-08-01 03:50:50'),
(10,'edit_product_discount_from_sale_screen','web','2024-08-01 03:50:50','2024-08-01 03:50:50'),
(11,'roles.view','web','2024-08-01 03:50:50','2024-08-01 03:50:50'),
(12,'roles.create','web','2024-08-01 03:50:50','2024-08-01 03:50:50'),
(13,'roles.update','web','2024-08-01 03:50:50','2024-08-01 03:50:50'),
(14,'roles.delete','web','2024-08-01 03:50:50','2024-08-01 03:50:50'),
(15,'account.access','web','2024-08-01 03:50:50','2024-08-01 03:50:50'),
(16,'discount.access','web','2024-08-01 03:50:50','2024-08-01 03:50:50'),
(17,'view_purchase_price','web','2024-08-01 03:50:50','2024-08-01 03:50:50'),
(18,'view_own_sell_only','web','2024-08-01 03:50:50','2024-08-01 03:50:50'),
(19,'edit_product_discount_from_pos_screen','web','2024-08-01 03:50:51','2024-08-01 03:50:51'),
(20,'edit_product_price_from_pos_screen','web','2024-08-01 03:50:51','2024-08-01 03:50:51'),
(21,'access_shipping','web','2024-08-01 03:50:51','2024-08-01 03:50:51'),
(22,'purchase.update_status','web','2024-08-01 03:50:51','2024-08-01 03:50:51'),
(23,'list_drafts','web','2024-08-01 03:50:51','2024-08-01 03:50:51'),
(24,'list_quotations','web','2024-08-01 03:50:51','2024-08-01 03:50:51'),
(25,'view_cash_register','web','2024-08-01 03:50:52','2024-08-01 03:50:52'),
(26,'close_cash_register','web','2024-08-01 03:50:52','2024-08-01 03:50:52'),
(27,'print_invoice','web','2024-08-01 03:50:53','2024-08-01 03:50:53'),
(28,'user.view','web','2024-08-01 03:50:53',NULL),
(29,'user.create','web','2024-08-01 03:50:53',NULL),
(30,'user.update','web','2024-08-01 03:50:53',NULL),
(31,'user.delete','web','2024-08-01 03:50:53',NULL),
(32,'supplier.view','web','2024-08-01 03:50:53',NULL),
(33,'supplier.create','web','2024-08-01 03:50:53',NULL),
(34,'supplier.update','web','2024-08-01 03:50:53',NULL),
(35,'supplier.delete','web','2024-08-01 03:50:53',NULL),
(36,'customer.view','web','2024-08-01 03:50:53',NULL),
(37,'customer.create','web','2024-08-01 03:50:53',NULL),
(38,'customer.update','web','2024-08-01 03:50:53',NULL),
(39,'customer.delete','web','2024-08-01 03:50:53',NULL),
(40,'product.view','web','2024-08-01 03:50:53',NULL),
(41,'product.create','web','2024-08-01 03:50:53',NULL),
(42,'product.update','web','2024-08-01 03:50:53',NULL),
(43,'product.delete','web','2024-08-01 03:50:53',NULL),
(44,'purchase.view','web','2024-08-01 03:50:53',NULL),
(45,'purchase.create','web','2024-08-01 03:50:53',NULL),
(46,'purchase.update','web','2024-08-01 03:50:53',NULL),
(47,'purchase.delete','web','2024-08-01 03:50:53',NULL),
(48,'sell.view','web','2024-08-01 03:50:53',NULL),
(49,'sell.create','web','2024-08-01 03:50:53',NULL),
(50,'sell.update','web','2024-08-01 03:50:53',NULL),
(51,'sell.delete','web','2024-08-01 03:50:53',NULL),
(52,'purchase_n_sell_report.view','web','2024-08-01 03:50:53',NULL),
(53,'contacts_report.view','web','2024-08-01 03:50:53',NULL),
(54,'stock_report.view','web','2024-08-01 03:50:53',NULL),
(55,'tax_report.view','web','2024-08-01 03:50:53',NULL),
(56,'trending_product_report.view','web','2024-08-01 03:50:53',NULL),
(57,'register_report.view','web','2024-08-01 03:50:53',NULL),
(58,'sales_representative.view','web','2024-08-01 03:50:53',NULL),
(59,'expense_report.view','web','2024-08-01 03:50:53',NULL),
(60,'business_settings.access','web','2024-08-01 03:50:53',NULL),
(61,'barcode_settings.access','web','2024-08-01 03:50:53',NULL),
(62,'invoice_settings.access','web','2024-08-01 03:50:53',NULL),
(63,'brand.view','web','2024-08-01 03:50:53',NULL),
(64,'brand.create','web','2024-08-01 03:50:53',NULL),
(65,'brand.update','web','2024-08-01 03:50:53',NULL),
(66,'brand.delete','web','2024-08-01 03:50:53',NULL),
(67,'tax_rate.view','web','2024-08-01 03:50:53',NULL),
(68,'tax_rate.create','web','2024-08-01 03:50:53',NULL),
(69,'tax_rate.update','web','2024-08-01 03:50:53',NULL),
(70,'tax_rate.delete','web','2024-08-01 03:50:53',NULL),
(71,'unit.view','web','2024-08-01 03:50:53',NULL),
(72,'unit.create','web','2024-08-01 03:50:53',NULL),
(73,'unit.update','web','2024-08-01 03:50:53',NULL),
(74,'unit.delete','web','2024-08-01 03:50:53',NULL),
(75,'category.view','web','2024-08-01 03:50:53',NULL),
(76,'category.create','web','2024-08-01 03:50:53',NULL),
(77,'category.update','web','2024-08-01 03:50:53',NULL),
(78,'category.delete','web','2024-08-01 03:50:53',NULL),
(79,'expense.access','web','2024-08-01 03:50:53',NULL),
(80,'access_all_locations','web','2024-08-01 03:50:53',NULL),
(81,'dashboard.data','web','2024-08-01 03:50:53',NULL),
(82,'location.1','web','2024-08-01 04:19:13','2024-08-01 04:19:13'),
(83,'essentials.create_message','web','2024-08-01 14:01:31','2024-08-01 14:01:31'),
(84,'essentials.view_message','web','2024-08-01 14:01:31','2024-08-01 14:01:31'),
(85,'essentials.approve_leave','web','2024-08-01 14:01:31','2024-08-01 14:01:31'),
(86,'essentials.assign_todos','web','2024-08-01 14:01:31','2024-08-01 14:01:31'),
(87,'essentials.add_allowance_and_deduction','web','2024-08-01 14:01:31','2024-08-01 14:01:31'),
(88,'poscustom.enabled','web','2024-08-01 14:05:32','2024-08-01 14:05:32'),
(89,'location.2','web','2025-01-17 12:03:44','2025-01-17 12:03:44'),
(90,'view_export_buttons','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(91,'edit_purchase_payment','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(92,'delete_purchase_payment','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(93,'edit_pos_payment','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(94,'disable_pay_checkout','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(95,'disable_draft','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(96,'disable_express_checkout','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(97,'disable_discount','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(98,'disable_suspend_sale','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(99,'disable_credit_sale','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(100,'disable_quotation','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(101,'disable_card','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(102,'view_paid_sells_only','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(103,'view_due_sells_only','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(104,'view_partial_sells_only','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(105,'view_overdue_sells_only','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(106,'direct_sell.update','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(107,'direct_sell.delete','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(108,'view_commission_agent_sell','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(109,'edit_sell_payment','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(110,'delete_sell_payment','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(111,'access_types_of_service','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(112,'access_sell_return','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(113,'access_own_sell_return','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(114,'edit_invoice_number','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(115,'access_printers','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(116,'poscustom.buttonpos','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(117,'poscustom.category_bar','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(118,'customer.view_own','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(119,'customer_irrespective_of_sell','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(120,'view_own_purchase','web','2025-01-17 12:23:13','2025-01-17 12:23:13'),
(121,'access_tables','web','2025-01-17 12:25:08','2025-01-17 12:25:08'),
(122,'essentials.allow_users_for_attendance_from_web','web','2025-01-17 12:25:08','2025-01-17 12:25:08'),
(123,'essentials.allow_users_for_attendance_from_api','web','2025-01-17 12:25:08','2025-01-17 12:25:08'),
(124,'essentials.view_own_attendance','web','2025-01-17 12:25:08','2025-01-17 12:25:08'),
(125,'draft.update','web','2025-01-17 12:26:46','2025-01-17 12:26:46'),
(126,'draft.delete','web','2025-01-17 12:26:46','2025-01-17 12:26:46'),
(127,'quotation.update','web','2025-01-17 12:26:46','2025-01-17 12:26:46'),
(128,'quotation.delete','web','2025-01-17 12:26:47','2025-01-17 12:26:47'),
(129,'draft.view_own','web','2025-01-17 12:26:47','2025-01-17 12:26:47'),
(130,'quotation.view_own','web','2025-01-17 12:26:47','2025-01-17 12:26:47'),
(131,'view_product_stock_value','web','2025-01-17 12:27:54','2025-01-17 12:27:54'),
(132,'access_pending_shipments_only','web','2025-01-17 13:01:33','2025-01-17 13:01:33'),
(133,'access_commission_agent_shipping','web','2025-01-17 13:01:33','2025-01-17 13:01:33'),
(134,'expense.add','web','2025-01-17 13:01:33','2025-01-17 13:01:33'),
(135,'expense.edit','web','2025-01-17 13:01:33','2025-01-17 13:01:33'),
(136,'expense.delete','web','2025-01-17 13:01:33','2025-01-17 13:01:33'),
(137,'access_own_shipping','web','2025-01-17 13:01:33','2025-01-17 13:01:33'),
(138,'view_own_expense','web','2025-01-17 13:01:33','2025-01-17 13:01:33'),
(139,'essentials.crud_own_leave','web','2025-01-17 13:01:33','2025-01-17 13:01:33'),
(140,'edit_account_transaction','web','2025-01-23 10:39:43','2025-01-23 10:39:43'),
(141,'delete_account_transaction','web','2025-01-23 10:39:43','2025-01-23 10:39:43'),
(142,'aiassistance.access_aiassistance_module','web','2025-01-23 10:39:43','2025-01-23 10:39:43'),
(143,'essentials.crud_leave_type','web','2025-01-23 10:39:43','2025-01-23 10:39:43'),
(144,'essentials.view_allowance_and_deduction','web','2025-01-23 10:39:43','2025-01-23 10:39:43'),
(145,'essentials.crud_department','web','2025-01-23 10:39:43','2025-01-23 10:39:43'),
(146,'essentials.crud_designation','web','2025-01-23 10:39:43','2025-01-23 10:39:43'),
(147,'essentials.view_all_payroll','web','2025-01-23 10:39:43','2025-01-23 10:39:43'),
(148,'essentials.create_payroll','web','2025-01-23 10:39:43','2025-01-23 10:39:43'),
(149,'essentials.update_payroll','web','2025-01-23 10:39:43','2025-01-23 10:39:43'),
(150,'essentials.delete_payroll','web','2025-01-23 10:39:43','2025-01-23 10:39:43'),
(151,'essentials.add_todos','web','2025-01-23 10:39:43','2025-01-23 10:39:43'),
(152,'essentials.edit_todos','web','2025-01-23 10:39:43','2025-01-23 10:39:43'),
(153,'essentials.delete_todos','web','2025-01-23 10:39:43','2025-01-23 10:39:43'),
(154,'essentials.access_sales_target','web','2025-01-23 10:39:43','2025-01-23 10:39:43'),
(155,'supplier.view_own','web','2025-01-23 10:39:43','2025-01-23 10:39:43'),
(156,'essentials.crud_all_leave','web','2025-01-23 10:39:43','2025-01-23 10:39:43'),
(157,'essentials.crud_all_attendance','web','2025-01-23 10:39:43','2025-01-23 10:39:43'),
(158,'location.3','web','2025-01-23 10:41:35','2025-01-23 10:41:35'),
(159,'purchase_requisition.create','web','2025-01-23 13:58:10','2025-01-23 13:58:10'),
(160,'purchase_requisition.delete','web','2025-01-23 13:58:10','2025-01-23 13:58:10'),
(161,'purchase_requisition.view_own','web','2025-01-23 13:58:10','2025-01-23 13:58:10'),
(162,'purchase_order.create','web','2025-01-23 13:59:00','2025-01-23 13:59:00'),
(163,'purchase_order.update','web','2025-01-23 13:59:00','2025-01-23 13:59:00'),
(164,'purchase_order.delete','web','2025-01-23 13:59:00','2025-01-23 13:59:00'),
(165,'so.create','web','2025-01-23 13:59:00','2025-01-23 13:59:00'),
(166,'so.update','web','2025-01-23 13:59:00','2025-01-23 13:59:00'),
(167,'so.delete','web','2025-01-23 13:59:00','2025-01-23 13:59:00'),
(168,'purchase_order.view_own','web','2025-01-23 13:59:00','2025-01-23 13:59:00'),
(169,'so.view_own','web','2025-01-23 13:59:01','2025-01-23 13:59:01');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `printers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `printers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `name` varchar(191) NOT NULL,
  `connection_type` enum('network','windows','linux') NOT NULL,
  `capability_profile` enum('default','simple','SP2000','TEP-200M','P822D') NOT NULL DEFAULT 'default',
  `char_per_line` varchar(191) DEFAULT NULL,
  `ip_address` varchar(191) DEFAULT NULL,
  `port` varchar(191) DEFAULT NULL,
  `path` varchar(191) DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `printers_business_id_foreign` (`business_id`),
  CONSTRAINT `printers_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `printers` WRITE;
/*!40000 ALTER TABLE `printers` DISABLE KEYS */;
/*!40000 ALTER TABLE `printers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_locations` (
  `product_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  KEY `product_locations_product_id_index` (`product_id`),
  KEY `product_locations_location_id_index` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_locations` WRITE;
/*!40000 ALTER TABLE `product_locations` DISABLE KEYS */;
INSERT INTO `product_locations` VALUES
(1,1),
(2,1),
(3,1),
(7,1),
(8,1),
(9,1),
(10,1),
(11,1),
(12,1);
/*!40000 ALTER TABLE `product_locations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_racks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_racks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `location_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `rack` varchar(191) DEFAULT NULL,
  `row` varchar(191) DEFAULT NULL,
  `position` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_racks_business_id_index` (`business_id`),
  KEY `product_racks_location_id_index` (`location_id`),
  KEY `product_racks_product_id_index` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_racks` WRITE;
/*!40000 ALTER TABLE `product_racks` DISABLE KEYS */;
INSERT INTO `product_racks` VALUES
(1,1,1,7,NULL,NULL,NULL,'2025-01-23 09:41:49','2025-01-23 09:42:20'),
(2,1,1,8,NULL,NULL,NULL,'2025-01-23 09:55:22','2025-01-23 09:55:22'),
(3,1,1,9,NULL,NULL,NULL,'2025-01-23 13:27:48','2025-01-23 14:33:27'),
(4,1,1,3,NULL,NULL,NULL,'2025-01-23 13:30:24','2025-01-23 13:30:24'),
(5,1,1,2,NULL,NULL,NULL,'2025-01-23 13:31:35','2025-01-23 13:31:35'),
(6,1,1,10,NULL,NULL,NULL,'2025-01-23 13:38:27','2025-01-23 13:40:04'),
(7,1,1,12,NULL,NULL,NULL,'2025-01-23 13:45:24','2025-01-23 13:45:24');
/*!40000 ALTER TABLE `product_racks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_variations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_variations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `variation_template_id` int(11) DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `is_dummy` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_variations_name_index` (`name`),
  KEY `product_variations_product_id_index` (`product_id`),
  CONSTRAINT `product_variations_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_variations` WRITE;
/*!40000 ALTER TABLE `product_variations` DISABLE KEYS */;
INSERT INTO `product_variations` VALUES
(1,NULL,'DUMMY',1,1,'2025-01-09 11:58:05','2025-01-09 11:58:05'),
(2,NULL,'DUMMY',2,1,'2025-01-15 13:50:04','2025-01-15 13:50:04'),
(3,NULL,'DUMMY',3,1,'2025-01-17 11:46:59','2025-01-17 11:46:59'),
(4,NULL,'DUMMY',4,0,'2025-01-20 16:22:20','2025-01-20 16:22:20'),
(5,NULL,'DUMMY',5,0,'2025-01-20 16:25:32','2025-01-20 16:25:32'),
(6,NULL,'DUMMY',6,0,'2025-01-20 16:25:43','2025-01-20 16:25:43'),
(7,NULL,'DUMMY',7,1,'2025-01-23 09:41:49','2025-01-23 09:41:49'),
(8,NULL,'DUMMY',8,1,'2025-01-23 09:55:22','2025-01-23 09:55:22'),
(9,NULL,'DUMMY',9,1,'2025-01-23 13:27:48','2025-01-23 13:27:48'),
(10,NULL,'DUMMY',10,1,'2025-01-23 13:38:27','2025-01-23 13:38:27'),
(11,NULL,'DUMMY',12,1,'2025-01-23 13:45:24','2025-01-23 13:45:24');
/*!40000 ALTER TABLE `product_variations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `business_id` int(10) unsigned NOT NULL,
  `type` enum('single','variable','modifier','combo') DEFAULT NULL,
  `unit_id` int(11) unsigned DEFAULT NULL,
  `secondary_unit_id` int(11) DEFAULT NULL,
  `sub_unit_ids` text DEFAULT NULL,
  `brand_id` int(10) unsigned DEFAULT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `sub_category_id` int(10) unsigned DEFAULT NULL,
  `tax` int(10) unsigned DEFAULT NULL,
  `tax_type` enum('inclusive','exclusive') NOT NULL,
  `enable_stock` tinyint(1) NOT NULL DEFAULT 0,
  `alert_quantity` decimal(22,4) DEFAULT NULL,
  `sku` varchar(191) NOT NULL,
  `barcode_type` enum('C39','C128','EAN13','EAN8','UPCA','UPCE') DEFAULT 'C128',
  `expiry_period` decimal(4,2) DEFAULT NULL,
  `expiry_period_type` enum('days','months') DEFAULT NULL,
  `enable_sr_no` tinyint(1) NOT NULL DEFAULT 0,
  `weight` varchar(191) DEFAULT NULL,
  `product_custom_field1` varchar(191) DEFAULT NULL,
  `product_custom_field2` varchar(191) DEFAULT NULL,
  `product_custom_field3` varchar(191) DEFAULT NULL,
  `product_custom_field4` varchar(191) DEFAULT NULL,
  `product_custom_field5` varchar(191) DEFAULT NULL,
  `product_custom_field6` varchar(191) DEFAULT NULL,
  `product_custom_field7` varchar(191) DEFAULT NULL,
  `product_custom_field8` varchar(191) DEFAULT NULL,
  `product_custom_field9` varchar(191) DEFAULT NULL,
  `product_custom_field10` varchar(191) DEFAULT NULL,
  `product_custom_field11` varchar(191) DEFAULT NULL,
  `product_custom_field12` varchar(191) DEFAULT NULL,
  `product_custom_field13` varchar(191) DEFAULT NULL,
  `product_custom_field14` varchar(191) DEFAULT NULL,
  `product_custom_field15` varchar(191) DEFAULT NULL,
  `product_custom_field16` varchar(191) DEFAULT NULL,
  `product_custom_field17` varchar(191) DEFAULT NULL,
  `product_custom_field18` varchar(191) DEFAULT NULL,
  `product_custom_field19` varchar(191) DEFAULT NULL,
  `product_custom_field20` varchar(191) DEFAULT NULL,
  `image` varchar(191) DEFAULT NULL,
  `product_description` text DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `preparation_time_in_minutes` int(11) DEFAULT NULL,
  `warranty_id` int(11) DEFAULT NULL,
  `is_inactive` tinyint(1) NOT NULL DEFAULT 0,
  `not_for_selling` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `products_brand_id_foreign` (`brand_id`),
  KEY `products_category_id_foreign` (`category_id`),
  KEY `products_sub_category_id_foreign` (`sub_category_id`),
  KEY `products_tax_foreign` (`tax`),
  KEY `products_name_index` (`name`),
  KEY `products_business_id_index` (`business_id`),
  KEY `products_unit_id_index` (`unit_id`),
  KEY `products_created_by_index` (`created_by`),
  KEY `products_warranty_id_index` (`warranty_id`),
  KEY `products_type_index` (`type`),
  KEY `products_tax_type_index` (`tax_type`),
  KEY `products_barcode_type_index` (`barcode_type`),
  KEY `products_secondary_unit_id_index` (`secondary_unit_id`),
  CONSTRAINT `products_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE,
  CONSTRAINT `products_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `products_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `products_sub_category_id_foreign` FOREIGN KEY (`sub_category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `products_tax_foreign` FOREIGN KEY (`tax`) REFERENCES `tax_rates` (`id`),
  CONSTRAINT `products_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES
(1,'Coke',1,'single',1,NULL,NULL,NULL,NULL,NULL,NULL,'exclusive',1,10.0000,'1001','C128',NULL,NULL,0,NULL,'','','','','','','','','','','','','','','','','','','','','1736404112_Copy of SARAH AND AHA (25).png','<p>Coke \'yan</p>',1,NULL,NULL,0,0,'2025-01-09 11:58:05','2025-01-09 11:58:32'),
(2,'JENO POSTER',1,'single',1,NULL,NULL,1,NULL,NULL,NULL,'exclusive',1,5.0000,'0002','C128',12.00,'months',0,NULL,'','','','','','','','','','','','','','','','','','','','','1737610295_jeno.jpeg','<p>Jeno poster from concert</p>',1,NULL,NULL,0,0,'2025-01-15 13:50:04','2025-01-23 13:31:35'),
(3,'JAEMIN POSTER',1,'single',1,NULL,NULL,1,NULL,NULL,NULL,'exclusive',1,100.0000,'0003','C128',12.00,'months',0,NULL,'','','','','','','','','','','','','','','','','','','','','1737610224_jaemin.jpeg',NULL,1,NULL,NULL,0,0,'2025-01-17 11:46:59','2025-01-23 13:30:24'),
(4,'Large',1,'modifier',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'inclusive',0,NULL,'0004','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,0,0,'2025-01-20 16:22:20','2025-01-20 16:22:20'),
(5,'Small',1,'modifier',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'inclusive',0,NULL,'0005','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,0,0,'2025-01-20 16:25:32','2025-01-20 16:25:32'),
(6,'Ice',1,'modifier',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'inclusive',0,NULL,'0006','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,0,0,'2025-01-20 16:25:43','2025-01-20 16:25:43'),
(7,'Sample Product',1,'single',1,NULL,NULL,2,NULL,NULL,1,'exclusive',1,10.0000,'0007','C128',12.00,'months',0,NULL,'','','','','','','','','','','','','','','','','','','','',NULL,NULL,1,NULL,NULL,0,0,'2025-01-23 09:41:49','2025-01-23 09:42:20'),
(8,'Table 1',1,'single',1,NULL,NULL,1,NULL,NULL,1,'inclusive',1,5.0000,'0008','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,0,0,'2025-01-23 09:55:22','2025-01-23 09:55:22'),
(9,'HAECHAN POSTER',1,'single',1,NULL,NULL,1,NULL,NULL,1,'inclusive',1,NULL,'0009','C128',12.00,'months',0,NULL,'','','','','','','','','','','','','','','','','','','','','1737610068_haechan.png',NULL,1,NULL,NULL,0,0,'2025-01-23 13:27:48','2025-01-23 14:33:27'),
(10,'JISUNG POSTER',1,'single',1,NULL,NULL,1,NULL,NULL,NULL,'inclusive',1,NULL,'0010','C128',12.00,'months',0,NULL,'','','','','','','','','','','','','','','','','','','','','1737610804_jisung.jpeg',NULL,1,NULL,NULL,0,0,'2025-01-23 13:38:27','2025-01-23 13:40:04'),
(11,'MARK POSTER',1,NULL,1,NULL,NULL,1,NULL,NULL,NULL,'inclusive',1,NULL,'0011','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,0,0,'2025-01-23 13:45:17','2025-01-23 13:45:17'),
(12,'MARK POSTER',1,'single',1,NULL,NULL,1,NULL,NULL,NULL,'exclusive',1,NULL,'0012','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1737611124_mark.jpeg',NULL,1,NULL,NULL,0,0,'2025-01-23 13:45:24','2025-01-23 13:45:24');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purchase_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `variation_id` int(10) unsigned NOT NULL,
  `quantity` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `secondary_unit_quantity` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `pp_without_discount` decimal(22,4) NOT NULL DEFAULT 0.0000 COMMENT 'Purchase price before inline discounts',
  `discount_percent` decimal(5,2) NOT NULL DEFAULT 0.00 COMMENT 'Inline discount percentage',
  `purchase_price` decimal(22,4) NOT NULL,
  `purchase_price_inc_tax` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `item_tax` decimal(22,4) NOT NULL COMMENT 'Tax for one quantity',
  `tax_id` int(10) unsigned DEFAULT NULL,
  `purchase_requisition_line_id` int(11) DEFAULT NULL,
  `purchase_order_line_id` int(11) DEFAULT NULL,
  `quantity_sold` decimal(22,4) NOT NULL DEFAULT 0.0000 COMMENT 'Quanity sold from this purchase line',
  `quantity_adjusted` decimal(22,4) NOT NULL DEFAULT 0.0000 COMMENT 'Quanity adjusted in stock adjustment from this purchase line',
  `quantity_returned` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `po_quantity_purchased` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `mfg_quantity_used` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `mfg_date` date DEFAULT NULL,
  `exp_date` date DEFAULT NULL,
  `lot_number` varchar(191) DEFAULT NULL,
  `sub_unit_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_lines_transaction_id_foreign` (`transaction_id`),
  KEY `purchase_lines_product_id_foreign` (`product_id`),
  KEY `purchase_lines_variation_id_foreign` (`variation_id`),
  KEY `purchase_lines_tax_id_foreign` (`tax_id`),
  KEY `purchase_lines_sub_unit_id_index` (`sub_unit_id`),
  KEY `purchase_lines_lot_number_index` (`lot_number`),
  CONSTRAINT `purchase_lines_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `purchase_lines_tax_id_foreign` FOREIGN KEY (`tax_id`) REFERENCES `tax_rates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `purchase_lines_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `purchase_lines_variation_id_foreign` FOREIGN KEY (`variation_id`) REFERENCES `variations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purchase_lines` WRITE;
/*!40000 ALTER TABLE `purchase_lines` DISABLE KEYS */;
INSERT INTO `purchase_lines` VALUES
(1,1,1,1,1000.0000,0.0000,0.0000,0.00,0.0000,0.0000,0.0000,NULL,NULL,NULL,124.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2025-01-09 12:00:40','2025-01-23 11:56:05'),
(2,5,2,2,1544.0000,0.0000,500.0000,0.00,500.0000,500.0000,0.0000,NULL,NULL,NULL,1544.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2025-01-15 13:50:25','2025-01-23 14:09:39'),
(3,9,3,3,539.0000,0.0000,250.0000,0.00,250.0000,250.0000,0.0000,NULL,NULL,NULL,539.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2025-01-17 11:47:59','2025-01-23 14:10:50'),
(4,27,7,7,500000.0000,0.0000,446.4300,0.00,446.4300,500.0000,53.5700,1,NULL,NULL,50.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2025-01-23 09:43:13','2025-01-23 12:34:20'),
(5,32,8,8,1000.0000,0.0000,10.7100,0.00,10.7100,11.9952,1.2852,1,NULL,NULL,21.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2025-01-23 09:55:40','2025-01-23 12:34:20'),
(6,64,9,9,1000.0000,0.0000,500.0000,0.00,500.0000,500.0000,0.0000,NULL,NULL,NULL,1000.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2025-01-23 13:28:35','2025-01-23 14:20:13'),
(7,65,10,10,500.0000,0.0000,500.0000,0.00,500.0000,500.0000,0.0000,NULL,NULL,NULL,500.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2025-01-23 13:38:40','2025-01-23 14:11:56'),
(8,66,12,11,1000.0000,0.0000,500.0000,0.00,500.0000,500.0000,0.0000,NULL,NULL,NULL,1000.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2025-01-23 13:45:48','2025-01-23 14:13:13'),
(9,77,9,9,500.0000,0.0000,500.0000,0.00,500.0000,560.0000,60.0000,1,NULL,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2025-01-23 14:44:38','2025-01-23 14:44:38'),
(10,78,9,9,5000.0000,0.0000,500.0000,0.00,500.0000,560.0000,60.0000,1,NULL,NULL,2.0000,0.0000,0.0000,0.0000,0.0000,NULL,'2025-05-31',NULL,NULL,'2025-01-23 14:45:53','2025-01-23 14:49:26');
/*!40000 ALTER TABLE `purchase_lines` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `reference_counts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reference_counts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ref_type` varchar(191) NOT NULL,
  `ref_count` int(11) NOT NULL,
  `business_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reference_counts_business_id_index` (`business_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `reference_counts` WRITE;
/*!40000 ALTER TABLE `reference_counts` DISABLE KEYS */;
INSERT INTO `reference_counts` VALUES
(1,'contacts',14,1,'2024-08-01 04:19:13','2025-01-23 13:56:41'),
(2,'business_location',1,1,'2024-08-01 04:19:13','2024-08-01 04:19:13'),
(3,'purchase',3,1,'2025-01-09 12:00:40','2025-01-23 14:45:53'),
(4,'draft',4,1,'2025-01-09 12:03:19','2025-01-23 09:31:04'),
(5,'sell_payment',68,1,'2025-01-15 13:51:25','2025-01-23 14:55:11'),
(6,'contacts',2,2,'2025-01-17 12:03:44','2025-01-17 12:41:11'),
(7,'business_location',1,2,'2025-01-17 12:03:44','2025-01-17 12:03:44'),
(8,'payroll',1,2,'2025-01-17 15:48:51','2025-01-17 15:48:51'),
(9,'contacts',1,3,'2025-01-23 10:41:35','2025-01-23 10:41:35'),
(10,'business_location',1,3,'2025-01-23 10:41:35','2025-01-23 10:41:35'),
(11,'purchase_order',1,1,'2025-01-23 14:44:38','2025-01-23 14:44:38'),
(12,'purchase_payment',2,1,'2025-01-23 14:45:53','2025-01-23 14:46:05'),
(13,'expense',1,1,'2025-01-23 14:50:32','2025-01-23 14:50:32');
/*!40000 ALTER TABLE `reference_counts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `res_product_modifier_sets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `res_product_modifier_sets` (
  `modifier_set_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL COMMENT 'Table use to store the modifier sets applicable for a product',
  KEY `res_product_modifier_sets_modifier_set_id_foreign` (`modifier_set_id`),
  CONSTRAINT `res_product_modifier_sets_modifier_set_id_foreign` FOREIGN KEY (`modifier_set_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `res_product_modifier_sets` WRITE;
/*!40000 ALTER TABLE `res_product_modifier_sets` DISABLE KEYS */;
INSERT INTO `res_product_modifier_sets` VALUES
(4,1),
(6,1),
(5,1);
/*!40000 ALTER TABLE `res_product_modifier_sets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `res_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `res_tables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `location_id` int(10) unsigned NOT NULL,
  `name` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `res_tables_business_id_foreign` (`business_id`),
  CONSTRAINT `res_tables_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `res_tables` WRITE;
/*!40000 ALTER TABLE `res_tables` DISABLE KEYS */;
INSERT INTO `res_tables` VALUES
(1,1,1,'Table 1','Cute table',1,NULL,'2025-01-17 12:19:05','2025-01-17 12:19:05');
/*!40000 ALTER TABLE `res_tables` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES
(1,4),
(1,5),
(1,6),
(1,12),
(1,13),
(2,4),
(2,5),
(2,6),
(2,12),
(2,13),
(3,4),
(3,6),
(3,12),
(3,13),
(5,4),
(5,5),
(5,12),
(5,13),
(6,4),
(6,5),
(6,6),
(6,12),
(6,13),
(7,6),
(7,12),
(8,4),
(8,5),
(8,6),
(8,12),
(8,13),
(9,4),
(9,5),
(9,6),
(9,12),
(9,13),
(10,4),
(10,5),
(10,6),
(10,12),
(10,13),
(11,6),
(11,12),
(12,12),
(13,12),
(14,12),
(16,4),
(16,5),
(16,6),
(16,12),
(16,13),
(17,4),
(17,6),
(17,12),
(17,13),
(18,4),
(18,5),
(18,6),
(18,12),
(18,13),
(19,4),
(19,5),
(19,6),
(19,12),
(19,13),
(20,4),
(20,5),
(20,6),
(20,12),
(20,13),
(22,6),
(22,12),
(25,2),
(25,4),
(25,5),
(25,6),
(25,9),
(25,12),
(25,13),
(26,2),
(26,4),
(26,5),
(26,6),
(26,9),
(26,12),
(26,13),
(27,4),
(27,5),
(27,6),
(27,12),
(27,13),
(28,6),
(28,12),
(28,13),
(29,12),
(29,13),
(30,12),
(30,13),
(31,12),
(31,13),
(32,6),
(33,12),
(34,12),
(35,12),
(36,4),
(37,4),
(37,6),
(37,12),
(37,13),
(38,4),
(38,6),
(38,12),
(38,13),
(39,4),
(39,6),
(39,12),
(39,13),
(40,4),
(40,6),
(40,12),
(40,13),
(41,4),
(41,6),
(41,12),
(41,13),
(42,4),
(42,6),
(42,12),
(42,13),
(43,4),
(43,6),
(43,12),
(43,13),
(45,6),
(45,12),
(46,6),
(46,12),
(47,6),
(47,12),
(48,2),
(48,4),
(48,5),
(48,6),
(48,9),
(48,12),
(48,13),
(49,2),
(49,4),
(49,5),
(49,6),
(49,9),
(49,12),
(49,13),
(50,2),
(50,4),
(50,5),
(50,6),
(50,9),
(50,12),
(50,13),
(51,2),
(51,4),
(51,5),
(51,6),
(51,9),
(51,12),
(51,13),
(52,4),
(52,5),
(52,6),
(52,12),
(52,13),
(53,4),
(53,5),
(53,6),
(53,12),
(53,13),
(54,4),
(54,5),
(54,6),
(54,12),
(54,13),
(55,4),
(55,5),
(55,6),
(55,12),
(55,13),
(56,4),
(56,5),
(56,6),
(56,12),
(56,13),
(57,4),
(57,5),
(57,6),
(57,12),
(57,13),
(58,4),
(58,5),
(58,6),
(58,12),
(58,13),
(59,4),
(59,5),
(59,6),
(59,12),
(59,13),
(60,4),
(60,6),
(60,12),
(61,4),
(61,6),
(61,12),
(62,4),
(62,6),
(62,12),
(63,4),
(63,5),
(63,6),
(63,12),
(64,4),
(64,5),
(64,6),
(64,12),
(65,4),
(65,5),
(65,6),
(65,12),
(66,4),
(66,5),
(66,6),
(66,12),
(67,4),
(67,5),
(67,6),
(67,12),
(67,13),
(68,4),
(68,5),
(68,6),
(68,12),
(68,13),
(69,4),
(69,5),
(69,6),
(69,12),
(69,13),
(70,4),
(70,5),
(70,6),
(70,12),
(70,13),
(71,4),
(71,5),
(71,6),
(71,12),
(71,13),
(72,4),
(72,5),
(72,6),
(72,12),
(72,13),
(73,4),
(73,5),
(73,6),
(73,12),
(73,13),
(74,4),
(74,5),
(74,6),
(74,12),
(74,13),
(75,4),
(75,5),
(75,6),
(75,12),
(75,13),
(76,4),
(76,5),
(76,6),
(76,12),
(76,13),
(77,4),
(77,5),
(77,6),
(77,12),
(77,13),
(78,4),
(78,5),
(78,6),
(78,12),
(78,13),
(80,9),
(81,4),
(81,5),
(81,6),
(81,12),
(81,13),
(88,4),
(90,4),
(90,12),
(91,6),
(91,12),
(92,6),
(92,12),
(93,4),
(93,5),
(93,6),
(93,12),
(93,13),
(94,4),
(94,5),
(94,6),
(94,12),
(94,13),
(95,4),
(95,5),
(95,6),
(95,12),
(95,13),
(96,4),
(96,5),
(96,6),
(96,12),
(96,13),
(97,4),
(97,5),
(97,6),
(97,12),
(97,13),
(98,4),
(98,5),
(98,6),
(98,12),
(98,13),
(99,4),
(99,5),
(99,6),
(99,12),
(99,13),
(100,4),
(100,5),
(100,6),
(100,12),
(100,13),
(101,4),
(101,5),
(101,6),
(101,12),
(101,13),
(102,4),
(102,5),
(102,6),
(102,12),
(102,13),
(103,4),
(103,5),
(103,6),
(103,12),
(103,13),
(104,4),
(104,5),
(104,6),
(104,12),
(104,13),
(105,4),
(105,5),
(105,6),
(105,12),
(105,13),
(106,4),
(106,5),
(106,6),
(106,12),
(106,13),
(107,4),
(107,5),
(107,6),
(107,12),
(107,13),
(108,4),
(108,5),
(108,6),
(108,12),
(108,13),
(109,4),
(109,5),
(109,6),
(109,12),
(109,13),
(110,4),
(110,5),
(110,6),
(110,12),
(110,13),
(111,4),
(111,5),
(111,6),
(111,12),
(111,13),
(112,4),
(112,5),
(112,6),
(112,12),
(112,13),
(113,4),
(113,5),
(113,6),
(113,12),
(113,13),
(114,4),
(114,5),
(114,6),
(114,12),
(114,13),
(115,4),
(115,6),
(115,12),
(116,4),
(116,5),
(116,6),
(116,12),
(116,13),
(117,4),
(117,5),
(117,6),
(117,12),
(117,13),
(118,6),
(118,12),
(118,13),
(119,4),
(119,6),
(119,12),
(119,13),
(120,6),
(120,12),
(121,4),
(121,5),
(122,4),
(122,5),
(123,4),
(123,5),
(124,4),
(124,5),
(125,4),
(125,5),
(125,6),
(125,12),
(126,4),
(126,5),
(126,6),
(126,12),
(127,4),
(127,5),
(127,6),
(127,12),
(128,4),
(128,5),
(128,6),
(128,12),
(129,4),
(129,5),
(129,6),
(129,12),
(130,4),
(130,5),
(130,6),
(130,12),
(131,4),
(131,5),
(131,6),
(131,12),
(131,13),
(132,4),
(132,6),
(132,12),
(132,13),
(133,4),
(133,6),
(133,12),
(133,13),
(134,4),
(134,6),
(134,12),
(135,4),
(135,6),
(135,12),
(136,4),
(136,6),
(136,12),
(137,4),
(137,6),
(137,12),
(137,13),
(138,4),
(138,6),
(138,12),
(139,4),
(155,12),
(159,12),
(160,12),
(161,12),
(162,12),
(163,12),
(164,12),
(165,12),
(165,13),
(166,12),
(166,13),
(167,12),
(167,13),
(168,12),
(169,12),
(169,13);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `guard_name` varchar(191) NOT NULL,
  `business_id` int(10) unsigned NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `is_service_staff` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `roles_business_id_foreign` (`business_id`),
  CONSTRAINT `roles_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(1,'Admin#1','web',1,1,0,'2024-08-01 04:19:13','2024-08-01 04:19:13'),
(2,'Cashier#1','web',1,0,0,'2024-08-01 04:19:13','2024-08-01 04:19:13'),
(3,'Admin#2','web',2,1,0,'2025-01-17 12:03:44','2025-01-17 12:03:44'),
(4,'Cashier#2','web',2,0,1,'2025-01-17 12:03:44','2025-01-17 13:01:33'),
(5,'Order#1','web',1,0,1,'2025-01-17 12:23:13','2025-01-17 12:23:13'),
(6,'NCT JENO#1','web',1,0,0,'2025-01-22 22:19:45','2025-01-23 13:57:38'),
(7,'test#1','web',1,0,1,'2025-01-23 10:39:43','2025-01-23 10:39:43'),
(8,'Admin#3','web',3,1,0,'2025-01-23 10:41:35','2025-01-23 10:41:35'),
(9,'Cashier#3','web',3,0,0,'2025-01-23 10:41:35','2025-01-23 10:41:35'),
(10,'NCT JAEMIN#1','web',1,0,1,'2025-01-23 13:58:10','2025-01-23 13:58:10'),
(11,'NCT JISUNG#1','web',1,0,0,'2025-01-23 13:59:00','2025-01-23 13:59:00'),
(12,'NCT MARK#1','web',1,0,1,'2025-01-23 14:00:26','2025-01-23 14:00:26'),
(13,'NCT HAECHAN#1','web',1,0,0,'2025-01-23 14:01:35','2025-01-23 14:01:35');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sell_line_warranties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sell_line_warranties` (
  `sell_line_id` int(11) NOT NULL,
  `warranty_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sell_line_warranties` WRITE;
/*!40000 ALTER TABLE `sell_line_warranties` DISABLE KEYS */;
/*!40000 ALTER TABLE `sell_line_warranties` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `selling_price_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `selling_price_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `business_id` int(10) unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `selling_price_groups_business_id_foreign` (`business_id`),
  CONSTRAINT `selling_price_groups_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `selling_price_groups` WRITE;
/*!40000 ALTER TABLE `selling_price_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `selling_price_groups` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(191) NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` text NOT NULL,
  `last_activity` int(11) NOT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `stock_adjustment_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_adjustment_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `variation_id` int(10) unsigned NOT NULL,
  `quantity` decimal(22,4) NOT NULL,
  `secondary_unit_quantity` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `unit_price` decimal(22,4) DEFAULT NULL COMMENT 'Last purchase unit price',
  `removed_purchase_line` int(11) DEFAULT NULL,
  `lot_no_line_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_adjustment_lines_product_id_foreign` (`product_id`),
  KEY `stock_adjustment_lines_variation_id_foreign` (`variation_id`),
  KEY `stock_adjustment_lines_transaction_id_index` (`transaction_id`),
  KEY `stock_adjustment_lines_lot_no_line_id_index` (`lot_no_line_id`),
  CONSTRAINT `stock_adjustment_lines_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stock_adjustment_lines_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stock_adjustment_lines_variation_id_foreign` FOREIGN KEY (`variation_id`) REFERENCES `variations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `stock_adjustment_lines` WRITE;
/*!40000 ALTER TABLE `stock_adjustment_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_adjustment_lines` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `stock_adjustments_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_adjustments_temp` (
  `id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `stock_adjustments_temp` WRITE;
/*!40000 ALTER TABLE `stock_adjustments_temp` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_adjustments_temp` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscriptions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `package_id` int(10) unsigned NOT NULL,
  `start_date` date DEFAULT NULL,
  `trial_end_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `package_price` decimal(22,4) NOT NULL,
  `original_price` decimal(22,4) DEFAULT NULL,
  `coupon_code` varchar(191) DEFAULT NULL,
  `package_details` longtext NOT NULL,
  `created_id` int(10) unsigned NOT NULL,
  `paid_via` varchar(191) DEFAULT NULL,
  `payment_transaction_id` varchar(191) DEFAULT NULL,
  `status` enum('approved','waiting','declined') NOT NULL DEFAULT 'waiting',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subscriptions_business_id_foreign` (`business_id`),
  KEY `subscriptions_package_id_index` (`package_id`),
  KEY `subscriptions_created_id_index` (`created_id`),
  CONSTRAINT `subscriptions_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
INSERT INTO `subscriptions` VALUES
(1,1,1,'2025-01-09','2026-01-09','2026-01-09',0.0000,0.0000,NULL,'{\"location_count\":\"0\",\"user_count\":\"0\",\"product_count\":\"0\",\"invoice_count\":\"0\",\"name\":\"PREMIUM\",\"aiassistance_max_token\":null,\"essentials_module\":\"1\",\"PosCustom\":\"1\"}',1,'offline',NULL,'approved',NULL,'2025-01-09 11:55:36','2025-01-23 10:53:23'),
(2,2,1,'2025-01-17','2026-01-17','2026-01-17',0.0000,0.0000,NULL,'{\"location_count\":\"0\",\"user_count\":\"0\",\"product_count\":\"0\",\"invoice_count\":\"0\",\"name\":\"PREMIUM\",\"aiassistance_max_token\":null,\"essentials_module\":\"1\",\"PosCustom\":\"1\"}',1,'offline','10002','approved',NULL,'2025-01-17 12:06:16','2025-01-23 10:53:23'),
(3,3,1,'2025-01-23','2026-01-23','2026-01-23',0.0000,0.0000,NULL,'{\"location_count\":\"0\",\"user_count\":\"0\",\"product_count\":\"0\",\"invoice_count\":\"0\",\"name\":\"PREMIUM\",\"aiassistance_max_token\":null,\"essentials_module\":\"1\",\"PosCustom\":\"1\"}',1,'offline','10002K','approved',NULL,'2025-01-23 10:42:07','2025-01-23 10:53:23');
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `superadmin_communicator_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `superadmin_communicator_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_ids` text DEFAULT NULL,
  `subject` varchar(191) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `superadmin_communicator_logs` WRITE;
/*!40000 ALTER TABLE `superadmin_communicator_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `superadmin_communicator_logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `superadmin_coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `superadmin_coupons` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `coupon_code` varchar(191) NOT NULL,
  `discount_type` varchar(191) NOT NULL,
  `discount` decimal(8,2) NOT NULL,
  `expiry_date` date DEFAULT NULL,
  `applied_on_packages` varchar(191) DEFAULT NULL,
  `applied_on_business` varchar(191) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `superadmin_coupons` WRITE;
/*!40000 ALTER TABLE `superadmin_coupons` DISABLE KEYS */;
/*!40000 ALTER TABLE `superadmin_coupons` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `superadmin_frontend_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `superadmin_frontend_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) DEFAULT NULL,
  `slug` varchar(191) NOT NULL,
  `content` longtext NOT NULL,
  `is_shown` tinyint(1) NOT NULL,
  `menu_order` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `superadmin_frontend_pages` WRITE;
/*!40000 ALTER TABLE `superadmin_frontend_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `superadmin_frontend_pages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `system`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(191) NOT NULL,
  `value` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `system` WRITE;
/*!40000 ALTER TABLE `system` DISABLE KEYS */;
INSERT INTO `system` VALUES
(1,'db_version','6.2'),
(2,'default_business_active_status','1'),
(3,'superadmin_version','6.0'),
(4,'app_currency_id','95'),
(5,'invoice_business_name','WebWonder'),
(6,'invoice_business_landmark','Landmark'),
(7,'invoice_business_zip','Zip'),
(8,'invoice_business_state','State'),
(9,'invoice_business_city','City'),
(10,'invoice_business_country','Country'),
(11,'email','superadmin@example.com'),
(12,'package_expiry_alert_days','5'),
(13,'enable_business_based_username','0'),
(14,'essentials_version','5.0'),
(15,'PosCustom_version','2.8'),
(16,'aiassistance_version','2.0'),
(17,'superadmin_register_tc','<p><strong>1. Introduction</strong></p>\r\n<p>Welcome to WebWonderPOS. By registering for and using our POS system, you agree to the following Terms &amp; Conditions. Please read them carefully.</p>\r\n<p><strong>2. Service Description</strong></p>\r\n<p>WebWonderPOS provides a Point of Sale (POS) system designed to assist with business transactions and management. Our POS system offers features and tools to streamline sales processes.</p>\r\n<p><strong>Disclaimer: Non-Official Receipts</strong></p>\r\n<p>This invoice/receipt is for order confirmation purposes only and does not constitute an Official Receipt. WebWonderPOS is not accredited by the Bureau of Internal Revenue (BIR). To ensure compliance with BIR regulations, you must register your equipment with the BIR if required. Failure to do so may result in penalties.</p>\r\n<p><strong>3. Payment Terms</strong></p>\r\n<p>To activate the system, you must make an advance payment. This payment will be tracked by the system as a partial payment. The remaining balance must be settled according to the agreed-upon terms.</p>\r\n<p><strong>4. User Responsibility</strong></p>\r\n<p>As a user of WebWonderPOS, you are responsible for:</p>\r\n<ul>\r\n<li>Properly using and configuring the system in accordance with the provided documentation and support.</li>\r\n<li>Regularly backing up your data to prevent any loss.</li>\r\n<li>Protecting your login credentials and other sensitive information related to the POS system.</li>\r\n</ul>\r\n<p><strong>5. Data Loss Disclaimer</strong></p>\r\n<p>WebWonderPOS is not liable for any loss of data that may occur due to improper use or failure to follow the provided guidelines. It is the user&rsquo;s responsibility to maintain proper backups and use the system according to the instructions.</p>\r\n<p><strong>6. Limitation of Liability</strong></p>\r\n<p>WebWonderPOS will not be held liable for any indirect, incidental, or consequential damages arising from the use or inability to use the POS system, including but not limited to loss of profits, data, or business interruption.</p>\r\n<p><strong>7. Changes to Terms</strong></p>\r\n<p>We reserve the right to update or modify these Terms &amp; Conditions at any time. Any changes will be effective immediately upon posting on our website or through direct communication.</p>\r\n<p><strong>8. Contact Information</strong></p>\r\n<p>For any questions or concerns regarding these Terms &amp; Conditions, please contact us at:</p>\r\n<p>WebWonderPOS<br />Email:&nbsp;<a rel=\"noreferrer\">contact@webwonderpos.com</a></p>'),
(18,'welcome_email_subject',NULL),
(19,'welcome_email_body',NULL),
(20,'additional_js',NULL),
(21,'additional_css',NULL),
(22,'offline_payment_details',NULL),
(23,'superadmin_enable_register_tc','0'),
(24,'allow_email_settings_to_businesses','0'),
(25,'enable_new_business_registration_notification','0'),
(26,'enable_new_subscription_notification','0'),
(27,'enable_welcome_email','0'),
(28,'enable_offline_payment','1');
/*!40000 ALTER TABLE `system` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tax_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tax_rates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `name` varchar(191) NOT NULL,
  `amount` double(22,4) NOT NULL,
  `is_tax_group` tinyint(1) NOT NULL DEFAULT 0,
  `for_tax_group` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tax_rates_business_id_foreign` (`business_id`),
  KEY `tax_rates_created_by_foreign` (`created_by`),
  CONSTRAINT `tax_rates_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tax_rates_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tax_rates` WRITE;
/*!40000 ALTER TABLE `tax_rates` DISABLE KEYS */;
INSERT INTO `tax_rates` VALUES
(1,1,'VAT',12.0000,0,0,1,NULL,'2025-01-23 09:37:13','2025-01-23 09:37:13'),
(2,1,'NONVAT',3.0000,0,0,1,NULL,'2025-01-23 09:38:37','2025-01-23 09:38:37');
/*!40000 ALTER TABLE `tax_rates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `transaction_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction_payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` int(11) unsigned DEFAULT NULL,
  `business_id` int(11) DEFAULT NULL,
  `is_return` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Used during sales to return the change',
  `amount` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `method` varchar(191) DEFAULT NULL,
  `payment_type` varchar(191) DEFAULT NULL,
  `transaction_no` varchar(191) DEFAULT NULL,
  `card_transaction_number` varchar(191) DEFAULT NULL,
  `card_number` varchar(191) DEFAULT NULL,
  `card_type` varchar(191) DEFAULT NULL,
  `card_holder_name` varchar(191) DEFAULT NULL,
  `card_month` varchar(191) DEFAULT NULL,
  `card_year` varchar(191) DEFAULT NULL,
  `card_security` varchar(5) DEFAULT NULL,
  `cheque_number` varchar(191) DEFAULT NULL,
  `bank_account_number` varchar(191) DEFAULT NULL,
  `paid_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `paid_through_link` tinyint(1) NOT NULL DEFAULT 0,
  `gateway` varchar(191) DEFAULT NULL,
  `is_advance` tinyint(1) NOT NULL DEFAULT 0,
  `payment_for` int(11) DEFAULT NULL COMMENT 'stores the contact id',
  `parent_id` int(11) DEFAULT NULL,
  `note` varchar(191) DEFAULT NULL,
  `document` varchar(191) DEFAULT NULL,
  `payment_ref_no` varchar(191) DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transaction_payments_transaction_id_foreign` (`transaction_id`),
  KEY `transaction_payments_created_by_index` (`created_by`),
  KEY `transaction_payments_parent_id_index` (`parent_id`),
  KEY `transaction_payments_payment_type_index` (`payment_type`),
  CONSTRAINT `transaction_payments_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `transaction_payments` WRITE;
/*!40000 ALTER TABLE `transaction_payments` DISABLE KEYS */;
INSERT INTO `transaction_payments` VALUES
(1,6,1,0,350.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-15 13:51:25',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0001',NULL,'2025-01-15 13:51:25','2025-01-15 13:51:25'),
(2,7,1,0,400.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-15 14:02:14',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0002',NULL,'2025-01-15 14:02:14','2025-01-15 14:02:14'),
(3,8,1,0,4450.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-17 11:11:11',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0003',NULL,'2025-01-17 11:11:11','2025-01-17 11:11:11'),
(4,10,1,0,3900.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-17 11:57:56',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0004',NULL,'2025-01-17 11:57:56','2025-01-17 11:57:56'),
(5,11,1,0,700.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-17 12:10:41',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0005',NULL,'2025-01-17 12:10:41','2025-01-17 12:10:41'),
(6,12,1,0,1750.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-17 12:13:55',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0006',NULL,'2025-01-17 12:13:55','2025-01-17 12:13:55'),
(7,13,1,0,400.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-17 12:19:38',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0007',NULL,'2025-01-17 12:19:38','2025-01-17 12:19:38'),
(8,14,1,0,1000.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-17 12:28:17',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0008',NULL,'2025-01-17 12:28:17','2025-01-17 12:28:17'),
(9,16,1,0,1000.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-20 15:43:49',1,0,NULL,0,3,NULL,NULL,NULL,'SP2025/0009',NULL,'2025-01-20 15:43:49','2025-01-20 15:43:49'),
(10,17,1,0,100.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-20 15:44:27',1,0,NULL,0,3,NULL,NULL,NULL,'SP2025/0010',NULL,'2025-01-20 15:44:27','2025-01-20 15:44:27'),
(11,18,1,0,100.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-20 19:13:00',1,0,NULL,0,5,NULL,NULL,NULL,'SP2025/0011',NULL,'2025-01-20 19:13:55','2025-01-20 19:13:55'),
(12,19,1,0,1230.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-22 22:28:56',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0012',NULL,'2025-01-22 22:28:56','2025-01-22 22:28:56'),
(13,20,1,0,250.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 08:22:09',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0013',NULL,'2025-01-23 08:22:09','2025-01-23 08:22:09'),
(14,21,1,0,700.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 09:06:10',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0014',NULL,'2025-01-23 09:06:10','2025-01-23 09:06:10'),
(15,24,1,0,3651.2000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 09:38:57',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0015',NULL,'2025-01-23 09:38:57','2025-01-23 09:38:57'),
(16,25,1,0,3500.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 09:41:08',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0016',NULL,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(17,26,1,0,4312.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 09:42:47',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0017',NULL,'2025-01-23 09:42:47','2025-01-23 09:42:47'),
(18,28,1,0,4000.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 09:43:28',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0018',NULL,'2025-01-23 09:43:28','2025-01-23 09:43:28'),
(19,29,1,0,6180.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 09:45:49',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0019',NULL,'2025-01-23 09:45:49','2025-01-23 09:45:49'),
(20,30,1,0,610.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 09:48:38',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0020',NULL,'2025-01-23 09:48:38','2025-01-23 09:48:38'),
(21,31,1,0,6000.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 09:50:33',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0021',NULL,'2025-01-23 09:50:33','2025-01-23 09:50:33'),
(22,33,1,0,650000.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 09:55:54',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0022',NULL,'2025-01-23 09:55:54','2025-01-23 09:55:54'),
(23,34,1,0,519.6800,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 10:01:17',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0023',NULL,'2025-01-23 10:01:17','2025-01-23 10:01:17'),
(24,35,1,0,51200.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 10:16:03',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0024',NULL,'2025-01-23 10:16:03','2025-01-23 10:16:03'),
(25,36,1,0,600.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 10:37:23',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0025',NULL,'2025-01-23 10:37:23','2025-01-23 10:37:23'),
(26,37,1,0,224.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 11:56:05',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0026',NULL,'2025-01-23 11:56:05','2025-01-23 11:56:05'),
(27,38,1,0,280.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 11:58:22',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0027',NULL,'2025-01-23 11:58:22','2025-01-23 11:58:22'),
(28,39,1,0,1232.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 11:59:11',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0028',NULL,'2025-01-23 11:59:11','2025-01-23 11:59:11'),
(29,40,1,0,672.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 12:00:32',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0029',NULL,'2025-01-23 12:00:32','2025-01-23 12:00:32'),
(30,41,1,0,672.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 12:03:39',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0030',NULL,'2025-01-23 12:03:39','2025-01-23 12:03:39'),
(31,42,1,0,280.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 12:05:53',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0031',NULL,'2025-01-23 12:05:53','2025-01-23 12:05:53'),
(32,43,1,0,280.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 12:06:21',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0032',NULL,'2025-01-23 12:06:21','2025-01-23 12:06:21'),
(33,44,1,0,392.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 12:09:48',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0033',NULL,'2025-01-23 12:09:48','2025-01-23 12:09:48'),
(34,45,1,0,500.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 12:10:41',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0034',NULL,'2025-01-23 12:10:41','2025-01-23 12:10:41'),
(35,46,1,0,350.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 12:12:12',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0035',NULL,'2025-01-23 12:12:12','2025-01-23 12:12:12'),
(36,47,1,0,560.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 12:12:21',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0036',NULL,'2025-01-23 12:12:21','2025-01-23 12:12:21'),
(37,48,1,0,500.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 12:12:39',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0037',NULL,'2025-01-23 12:12:39','2025-01-23 12:12:39'),
(38,49,1,0,446.4300,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 12:14:15',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0038',NULL,'2025-01-23 12:14:15','2025-01-23 12:14:15'),
(39,50,1,0,446.4300,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 12:15:22',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0039',NULL,'2025-01-23 12:15:22','2025-01-23 12:15:22'),
(40,51,1,0,500.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 12:16:26',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0040',NULL,'2025-01-23 12:16:26','2025-01-23 12:16:26'),
(41,52,1,0,500.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 12:18:11',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0041',NULL,'2025-01-23 12:18:11','2025-01-23 12:18:11'),
(42,53,1,0,500.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 12:18:54',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0042',NULL,'2025-01-23 12:18:54','2025-01-23 12:18:54'),
(43,54,1,0,500.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 12:19:01',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0043',NULL,'2025-01-23 12:19:01','2025-01-23 12:19:01'),
(44,55,1,0,1000.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 12:20:03',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0044',NULL,'2025-01-23 12:20:03','2025-01-23 12:20:03'),
(45,56,1,0,50000.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 12:25:35',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0045',NULL,'2025-01-23 12:25:35','2025-01-23 12:25:35'),
(46,57,1,0,500.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 12:26:30',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0046',NULL,'2025-01-23 12:26:30','2025-01-23 12:26:30'),
(47,58,1,0,50000.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 12:27:06',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0047',NULL,'2025-01-23 12:27:06','2025-01-23 12:27:06'),
(48,59,1,0,50000.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 12:27:28',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0048',NULL,'2025-01-23 12:27:28','2025-01-23 12:27:28'),
(49,60,1,0,50000.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 12:29:06',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0049',NULL,'2025-01-23 12:29:06','2025-01-23 12:29:06'),
(50,61,1,0,50000.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 12:31:19',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0050',NULL,'2025-01-23 12:31:19','2025-01-23 12:31:19'),
(51,62,1,0,50500.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 12:32:58',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0051',NULL,'2025-01-23 12:32:58','2025-01-23 12:32:58'),
(52,63,1,0,51000.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 12:34:20',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0052',NULL,'2025-01-23 12:34:20','2025-01-23 12:34:20'),
(53,67,1,0,500000.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 14:08:03',1,0,NULL,0,8,NULL,NULL,NULL,'SP2025/0053',NULL,'2025-01-23 14:08:03','2025-01-23 14:08:03'),
(54,68,1,0,250000.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 14:09:39',1,0,NULL,0,8,NULL,NULL,NULL,'SP2025/0054',NULL,'2025-01-23 14:09:39','2025-01-23 14:09:39'),
(55,69,1,0,150000.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 14:10:18',1,0,NULL,0,10,NULL,NULL,NULL,'SP2025/0055',NULL,'2025-01-23 14:10:18','2025-01-23 14:10:18'),
(56,70,1,0,100000.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 14:10:50',1,0,NULL,0,10,NULL,NULL,NULL,'SP2025/0056',NULL,'2025-01-23 14:10:50','2025-01-23 14:10:50'),
(57,71,1,0,140000.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 14:11:28',1,0,NULL,0,11,NULL,NULL,NULL,'SP2025/0057',NULL,'2025-01-23 14:11:28','2025-01-23 14:11:28'),
(58,72,1,0,110000.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 14:11:56',1,0,NULL,0,11,NULL,NULL,NULL,'SP2025/0058',NULL,'2025-01-23 14:11:56','2025-01-23 14:11:56'),
(59,73,1,0,350000.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 14:12:26',1,0,NULL,0,9,NULL,NULL,NULL,'SP2025/0059',NULL,'2025-01-23 14:12:26','2025-01-23 14:12:26'),
(60,74,1,0,150000.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 14:13:13',1,0,NULL,0,9,NULL,NULL,NULL,'SP2025/0060',NULL,'2025-01-23 14:13:13','2025-01-23 14:13:13'),
(61,75,1,0,200000.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 14:16:52',1,0,NULL,0,12,NULL,NULL,NULL,'SP2025/0061',NULL,'2025-01-23 14:16:52','2025-01-23 14:16:52'),
(62,76,1,0,300000.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 14:20:13',1,0,NULL,0,12,NULL,NULL,NULL,'SP2025/0062',NULL,'2025-01-23 14:20:13','2025-01-23 14:20:13'),
(63,78,1,0,10000.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 14:44:00',1,0,NULL,0,17,NULL,NULL,NULL,'PP2025/0001',NULL,'2025-01-23 14:45:53','2025-01-23 14:45:53'),
(64,27,1,0,250000000.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 14:45:00',1,0,NULL,0,2,NULL,NULL,NULL,'PP2025/0002',NULL,'2025-01-23 14:46:05','2025-01-23 14:46:05'),
(65,79,1,0,570.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 14:47:06',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0063',NULL,'2025-01-23 14:47:06','2025-01-23 14:47:06'),
(66,79,1,1,10.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 14:47:06',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0064',NULL,'2025-01-23 14:47:06','2025-01-23 14:47:06'),
(67,80,1,0,600.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 14:49:26',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0065',NULL,'2025-01-23 14:49:26','2025-01-23 14:49:26'),
(68,80,1,1,40.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 14:49:26',1,0,NULL,0,1,NULL,NULL,NULL,'SP2025/0066',NULL,'2025-01-23 14:49:26','2025-01-23 14:49:26'),
(69,81,1,0,1500.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 14:50:00',1,0,NULL,0,NULL,NULL,NULL,NULL,'SP2025/0067',NULL,'2025-01-23 14:50:32','2025-01-23 14:50:32'),
(70,18,1,0,1900.0000,'cash',NULL,NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 14:55:00',1,0,NULL,0,5,NULL,NULL,NULL,'SP2025/0068',NULL,'2025-01-23 14:55:11','2025-01-23 14:55:11');
/*!40000 ALTER TABLE `transaction_payments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `transaction_sell_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction_sell_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `variation_id` int(10) unsigned NOT NULL,
  `quantity` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `secondary_unit_quantity` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `quantity_returned` decimal(20,4) NOT NULL DEFAULT 0.0000,
  `unit_price_before_discount` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `unit_price` decimal(22,4) DEFAULT NULL COMMENT 'Sell price excluding tax',
  `line_discount_type` enum('fixed','percentage') DEFAULT NULL,
  `line_discount_amount` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `unit_price_inc_tax` decimal(22,4) DEFAULT NULL COMMENT 'Sell price including tax',
  `item_tax` decimal(22,4) NOT NULL COMMENT 'Tax for one quantity',
  `tax_id` int(10) unsigned DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `lot_no_line_id` int(11) DEFAULT NULL,
  `sell_line_note` text DEFAULT NULL,
  `so_line_id` int(11) DEFAULT NULL,
  `so_quantity_invoiced` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `res_service_staff_id` int(11) DEFAULT NULL,
  `res_line_order_status` varchar(191) DEFAULT NULL,
  `parent_sell_line_id` int(11) DEFAULT NULL,
  `children_type` varchar(191) NOT NULL DEFAULT '' COMMENT 'Type of children for the parent, like modifier or combo',
  `sub_unit_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transaction_sell_lines_transaction_id_foreign` (`transaction_id`),
  KEY `transaction_sell_lines_product_id_foreign` (`product_id`),
  KEY `transaction_sell_lines_variation_id_foreign` (`variation_id`),
  KEY `transaction_sell_lines_tax_id_foreign` (`tax_id`),
  KEY `transaction_sell_lines_children_type_index` (`children_type`),
  KEY `transaction_sell_lines_parent_sell_line_id_index` (`parent_sell_line_id`),
  KEY `transaction_sell_lines_line_discount_type_index` (`line_discount_type`),
  KEY `transaction_sell_lines_discount_id_index` (`discount_id`),
  KEY `transaction_sell_lines_lot_no_line_id_index` (`lot_no_line_id`),
  KEY `transaction_sell_lines_sub_unit_id_index` (`sub_unit_id`),
  CONSTRAINT `transaction_sell_lines_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transaction_sell_lines_tax_id_foreign` FOREIGN KEY (`tax_id`) REFERENCES `tax_rates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transaction_sell_lines_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transaction_sell_lines_variation_id_foreign` FOREIGN KEY (`variation_id`) REFERENCES `variations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `transaction_sell_lines` WRITE;
/*!40000 ALTER TABLE `transaction_sell_lines` DISABLE KEYS */;
INSERT INTO `transaction_sell_lines` VALUES
(1,2,1,1,8.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-09 12:02:22','2025-01-09 12:02:22'),
(2,3,1,1,100.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-09 12:03:19','2025-01-09 12:03:19'),
(3,4,1,1,7.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-11 10:43:35','2025-01-11 10:43:35'),
(4,6,2,2,1.0000,0.0000,0.0000,350.0000,350.0000,'fixed',0.0000,350.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-15 13:51:25','2025-01-15 13:51:25'),
(5,7,1,1,4.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-15 14:02:14','2025-01-15 14:02:14'),
(6,8,1,1,20.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-17 11:11:11','2025-01-17 11:11:11'),
(7,8,2,2,7.0000,0.0000,0.0000,350.0000,350.0000,'fixed',0.0000,350.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-17 11:11:11','2025-01-17 11:11:11'),
(8,10,2,2,9.0000,0.0000,0.0000,350.0000,350.0000,'fixed',0.0000,350.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-17 11:57:56','2025-01-17 11:57:56'),
(9,10,3,3,1.0000,0.0000,0.0000,250.0000,250.0000,'fixed',0.0000,250.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-17 11:57:56','2025-01-17 11:57:56'),
(10,10,1,1,5.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-17 11:57:56','2025-01-17 11:57:56'),
(11,11,1,1,7.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2025-01-17 12:10:41','2025-01-17 12:14:18'),
(12,12,3,3,7.0000,0.0000,0.0000,250.0000,250.0000,'fixed',0.0000,250.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2025-01-17 12:13:55','2025-01-17 12:14:16'),
(13,13,1,1,4.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-17 12:19:38','2025-01-17 12:19:38'),
(14,14,1,1,10.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-17 12:28:17','2025-01-17 12:28:17'),
(15,16,3,3,6.0000,0.0000,0.0000,250.0000,250.0000,'fixed',0.0000,250.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-20 15:43:49','2025-01-20 15:43:49'),
(16,17,1,1,22.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-20 15:44:27','2025-01-20 15:44:27'),
(17,18,1,1,20.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-20 15:48:06','2025-01-20 15:48:06'),
(18,19,3,3,5.0000,0.0000,0.0000,250.0000,250.0000,'fixed',0.0000,250.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-22 22:28:56','2025-01-22 22:28:56'),
(19,20,3,3,1.0000,0.0000,0.0000,250.0000,250.0000,'fixed',0.0000,250.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 08:22:09','2025-01-23 08:22:09'),
(20,21,2,2,2.0000,0.0000,0.0000,350.0000,350.0000,'fixed',0.0000,350.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:06:10','2025-01-23 09:06:10'),
(21,22,2,2,2.0000,0.0000,0.0000,350.0000,350.0000,'fixed',0.0000,350.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:06:46','2025-01-23 09:06:46'),
(22,23,1,1,1.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:31:04','2025-01-23 09:31:04'),
(23,23,4,4,1.0000,0.0000,0.0000,10.0000,10.0000,NULL,0.0000,10.0000,0.0000,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,22,'modifier',NULL,'2025-01-23 09:31:04','2025-01-23 09:31:04'),
(24,24,1,1,1.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:38:57','2025-01-23 09:38:57'),
(25,24,2,2,9.0000,0.0000,0.0000,350.0000,350.0000,'fixed',0.0000,350.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:38:57','2025-01-23 09:38:57'),
(26,24,4,4,1.0000,0.0000,0.0000,10.0000,10.0000,NULL,0.0000,10.0000,0.0000,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,24,'modifier',NULL,'2025-01-23 09:38:57','2025-01-23 09:38:57'),
(27,25,2,2,2.0000,0.0000,0.0000,350.0000,350.0000,'fixed',0.0000,350.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(28,25,3,3,6.0000,0.0000,0.0000,250.0000,250.0000,'fixed',0.0000,250.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(29,25,1,1,1.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(30,25,1,1,1.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(31,25,1,1,1.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(32,25,1,1,1.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(33,25,1,1,1.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(34,25,1,1,1.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(35,25,1,1,1.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(36,25,1,1,1.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(37,25,1,1,1.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(38,25,1,1,1.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(39,25,1,1,1.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(40,25,1,1,1.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(41,25,1,1,1.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(42,26,1,1,1.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:42:47','2025-01-23 09:42:47'),
(43,26,1,1,1.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:42:47','2025-01-23 09:42:47'),
(44,26,1,1,1.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:42:47','2025-01-23 09:42:47'),
(45,26,1,1,1.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:42:47','2025-01-23 09:42:47'),
(46,26,1,1,1.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:42:47','2025-01-23 09:42:47'),
(47,26,3,3,5.0000,0.0000,0.0000,250.0000,250.0000,'fixed',0.0000,250.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:42:47','2025-01-23 09:42:47'),
(48,26,2,2,6.0000,0.0000,0.0000,350.0000,350.0000,'fixed',0.0000,350.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:42:47','2025-01-23 09:42:47'),
(49,28,7,7,8.0000,0.0000,0.0000,446.4300,446.4300,'fixed',0.0000,500.0000,53.5700,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:43:28','2025-01-23 09:43:28'),
(50,29,7,7,12.0000,0.0000,0.0000,446.4300,446.4300,'fixed',0.0000,500.0000,53.5700,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:45:49','2025-01-23 09:45:49'),
(51,30,7,7,1.0000,0.0000,0.0000,446.4300,446.4300,'fixed',0.0000,500.0000,53.5700,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:48:38','2025-01-23 09:48:38'),
(52,30,1,1,1.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:48:38','2025-01-23 09:48:38'),
(53,30,4,4,1.0000,0.0000,0.0000,10.0000,10.0000,NULL,0.0000,10.0000,0.0000,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,52,'modifier',NULL,'2025-01-23 09:48:38','2025-01-23 09:48:38'),
(54,31,7,7,12.0000,0.0000,0.0000,446.4300,446.4300,'fixed',0.0000,500.0000,53.5700,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:50:33','2025-01-23 09:50:33'),
(55,33,8,8,13.0000,0.0000,0.0000,44642.8600,44642.8600,'fixed',0.0000,50000.0000,5357.1400,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 09:55:54','2025-01-23 09:55:54'),
(56,34,1,1,1.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 10:01:17','2025-01-23 10:01:17'),
(57,34,2,2,1.0000,0.0000,0.0000,350.0000,350.0000,'fixed',0.0000,350.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 10:01:17','2025-01-23 10:01:17'),
(58,34,4,4,1.0000,0.0000,0.0000,10.0000,10.0000,NULL,0.0000,10.0000,0.0000,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,56,'modifier',NULL,'2025-01-23 10:01:17','2025-01-23 10:01:17'),
(59,34,6,6,1.0000,0.0000,0.0000,4.0000,4.0000,NULL,0.0000,4.0000,0.0000,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,56,'modifier',NULL,'2025-01-23 10:01:17','2025-01-23 10:01:17'),
(60,35,1,1,1.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 10:16:03','2025-01-23 10:16:03'),
(61,35,3,3,1.0000,0.0000,0.0000,250.0000,250.0000,'fixed',0.0000,250.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 10:16:03','2025-01-23 10:16:03'),
(62,35,2,2,1.0000,0.0000,0.0000,350.0000,350.0000,'fixed',0.0000,350.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 10:16:03','2025-01-23 10:16:03'),
(63,35,7,7,1.0000,0.0000,0.0000,446.4300,446.4300,'fixed',0.0000,500.0000,53.5700,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 10:16:03','2025-01-23 10:16:03'),
(64,35,8,8,1.0000,0.0000,0.0000,44642.8600,44642.8600,'fixed',0.0000,50000.0000,5357.1400,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 10:16:03','2025-01-23 10:16:03'),
(65,36,3,3,1.0000,0.0000,0.0000,250.0000,250.0000,'fixed',0.0000,250.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 10:37:23','2025-01-23 10:37:23'),
(66,36,2,2,1.0000,0.0000,0.0000,350.0000,350.0000,'fixed',0.0000,350.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 10:37:23','2025-01-23 10:37:23'),
(67,37,1,1,1.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 11:56:05','2025-01-23 11:56:05'),
(68,37,1,1,1.0000,0.0000,0.0000,100.0000,100.0000,'fixed',0.0000,100.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 11:56:05','2025-01-23 11:56:05'),
(69,38,3,3,1.0000,0.0000,0.0000,250.0000,250.0000,'fixed',0.0000,250.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 11:58:22','2025-01-23 11:58:22'),
(70,39,2,2,1.0000,0.0000,0.0000,350.0000,350.0000,'fixed',0.0000,350.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 11:59:11','2025-01-23 11:59:11'),
(71,39,3,3,1.0000,0.0000,0.0000,250.0000,250.0000,'fixed',0.0000,250.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 11:59:11','2025-01-23 11:59:11'),
(72,39,7,7,1.0000,0.0000,0.0000,446.4300,446.4300,'fixed',0.0000,500.0000,53.5700,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 11:59:11','2025-01-23 11:59:11'),
(73,40,3,3,1.0000,0.0000,0.0000,250.0000,250.0000,'fixed',0.0000,250.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:00:32','2025-01-23 12:00:32'),
(74,40,2,2,1.0000,0.0000,0.0000,350.0000,350.0000,'fixed',0.0000,350.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:00:32','2025-01-23 12:00:32'),
(75,41,3,3,1.0000,0.0000,0.0000,250.0000,250.0000,'fixed',0.0000,250.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:03:39','2025-01-23 12:03:39'),
(76,41,2,2,1.0000,0.0000,0.0000,350.0000,350.0000,'fixed',0.0000,350.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:03:39','2025-01-23 12:03:39'),
(77,42,3,3,1.0000,0.0000,0.0000,250.0000,250.0000,'fixed',0.0000,250.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:05:53','2025-01-23 12:05:53'),
(78,43,3,3,1.0000,0.0000,0.0000,250.0000,250.0000,'fixed',0.0000,250.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:06:21','2025-01-23 12:06:21'),
(79,44,2,2,1.0000,0.0000,0.0000,350.0000,350.0000,'fixed',0.0000,350.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:09:48','2025-01-23 12:09:48'),
(80,45,7,7,1.0000,0.0000,0.0000,446.4300,446.4300,'fixed',0.0000,500.0000,53.5700,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:10:41','2025-01-23 12:10:41'),
(81,46,2,2,1.0000,0.0000,0.0000,350.0000,350.0000,'fixed',0.0000,350.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:12:12','2025-01-23 12:12:12'),
(82,47,7,7,1.0000,0.0000,0.0000,446.4300,446.4300,'fixed',0.0000,500.0000,53.5700,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:12:21','2025-01-23 12:12:21'),
(83,48,7,7,1.0000,0.0000,0.0000,446.4300,446.4300,'fixed',0.0000,500.0000,53.5700,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:12:39','2025-01-23 12:12:39'),
(84,49,7,7,1.0000,0.0000,0.0000,446.4300,446.4300,'fixed',0.0000,446.4300,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:14:15','2025-01-23 12:14:15'),
(85,50,7,7,1.0000,0.0000,0.0000,446.4300,446.4300,'fixed',0.0000,446.4300,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:15:22','2025-01-23 12:15:22'),
(86,51,7,7,1.0000,0.0000,0.0000,446.4300,446.4300,'fixed',0.0000,500.0000,53.5700,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:16:26','2025-01-23 12:16:26'),
(87,52,7,7,1.0000,0.0000,0.0000,446.4300,446.4300,'fixed',0.0000,500.0000,53.5700,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:18:11','2025-01-23 12:18:11'),
(88,53,7,7,1.0000,0.0000,0.0000,446.4300,446.4300,'fixed',0.0000,500.0000,53.5700,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:18:54','2025-01-23 12:18:54'),
(89,54,7,7,1.0000,0.0000,0.0000,446.4300,446.4300,'fixed',0.0000,500.0000,53.5700,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:19:01','2025-01-23 12:19:01'),
(90,55,7,7,2.0000,0.0000,0.0000,446.4300,446.4300,'fixed',0.0000,500.0000,53.5700,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:20:03','2025-01-23 12:20:03'),
(91,56,8,8,1.0000,0.0000,0.0000,44642.8600,44642.8600,'fixed',0.0000,50000.0000,5357.1400,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:25:35','2025-01-23 12:25:35'),
(92,57,7,7,1.0000,0.0000,0.0000,446.4300,446.4300,'fixed',0.0000,500.0000,53.5700,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:26:30','2025-01-23 12:26:30'),
(93,58,8,8,1.0000,0.0000,0.0000,44642.8600,44642.8600,'fixed',0.0000,50000.0000,5357.1400,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:27:06','2025-01-23 12:27:06'),
(94,59,8,8,1.0000,0.0000,0.0000,44642.8600,44642.8600,'fixed',0.0000,50000.0000,5357.1400,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:27:28','2025-01-23 12:27:28'),
(95,60,8,8,1.0000,0.0000,0.0000,44642.8600,44642.8600,'fixed',0.0000,50000.0000,5357.1400,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:29:06','2025-01-23 12:29:06'),
(96,61,8,8,1.0000,0.0000,0.0000,44642.8600,44642.8600,'fixed',0.0000,50000.0000,5357.1400,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:31:19','2025-01-23 12:31:19'),
(97,62,7,7,1.0000,0.0000,0.0000,446.4300,446.4300,'fixed',0.0000,500.0000,53.5700,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:32:58','2025-01-23 12:32:58'),
(98,62,8,8,1.0000,0.0000,0.0000,44642.8600,44642.8600,'fixed',0.0000,50000.0000,5357.1400,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:32:58','2025-01-23 12:32:58'),
(99,63,7,7,2.0000,0.0000,0.0000,446.4300,446.4300,'fixed',0.0000,500.0000,53.5700,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:34:20','2025-01-23 12:34:20'),
(100,63,8,8,1.0000,0.0000,0.0000,44642.8600,44642.8600,'fixed',0.0000,50000.0000,5357.1400,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 12:34:20','2025-01-23 12:34:20'),
(101,67,2,2,1000.0000,0.0000,0.0000,500.0000,500.0000,'fixed',0.0000,500.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 14:08:03','2025-01-23 14:08:03'),
(102,68,2,2,500.0000,0.0000,0.0000,500.0000,500.0000,'fixed',0.0000,500.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 14:09:39','2025-01-23 14:09:39'),
(103,69,3,3,300.0000,0.0000,0.0000,500.0000,500.0000,'fixed',0.0000,500.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 14:10:18','2025-01-23 14:10:18'),
(104,70,3,3,200.0000,0.0000,0.0000,500.0000,500.0000,'fixed',0.0000,500.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 14:10:50','2025-01-23 14:10:50'),
(105,71,10,10,280.0000,0.0000,0.0000,500.0000,500.0000,'fixed',0.0000,500.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 14:11:28','2025-01-23 14:11:28'),
(106,72,10,10,220.0000,0.0000,0.0000,500.0000,500.0000,'fixed',0.0000,500.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 14:11:56','2025-01-23 14:11:56'),
(107,73,12,11,700.0000,0.0000,0.0000,500.0000,500.0000,'fixed',0.0000,500.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 14:12:26','2025-01-23 14:12:26'),
(108,74,12,11,300.0000,0.0000,0.0000,500.0000,500.0000,'fixed',0.0000,500.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 14:13:13','2025-01-23 14:13:13'),
(109,75,9,9,400.0000,0.0000,0.0000,500.0000,500.0000,'fixed',0.0000,500.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 14:16:52','2025-01-23 14:16:52'),
(110,76,9,9,600.0000,0.0000,0.0000,500.0000,500.0000,'fixed',0.0000,500.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 14:20:13','2025-01-23 14:20:13'),
(111,79,9,9,1.0000,0.0000,0.0000,500.0000,500.0000,'fixed',0.0000,560.0000,60.0000,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 14:47:06','2025-01-23 14:47:06'),
(112,80,9,9,1.0000,0.0000,0.0000,500.0000,500.0000,'fixed',0.0000,560.0000,60.0000,1,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,'',NULL,'2025-01-23 14:49:26','2025-01-23 14:49:26');
/*!40000 ALTER TABLE `transaction_sell_lines` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `transaction_sell_lines_purchase_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction_sell_lines_purchase_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sell_line_id` int(10) unsigned DEFAULT NULL COMMENT 'id from transaction_sell_lines',
  `stock_adjustment_line_id` int(10) unsigned DEFAULT NULL COMMENT 'id from stock_adjustment_lines',
  `purchase_line_id` int(10) unsigned NOT NULL COMMENT 'id from purchase_lines',
  `quantity` decimal(22,4) NOT NULL,
  `qty_returned` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sell_line_id` (`sell_line_id`),
  KEY `stock_adjustment_line_id` (`stock_adjustment_line_id`),
  KEY `purchase_line_id` (`purchase_line_id`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `transaction_sell_lines_purchase_lines` WRITE;
/*!40000 ALTER TABLE `transaction_sell_lines_purchase_lines` DISABLE KEYS */;
INSERT INTO `transaction_sell_lines_purchase_lines` VALUES
(1,1,NULL,1,8.0000,0.0000,'2025-01-09 12:02:22','2025-01-09 12:02:22'),
(2,4,NULL,2,1.0000,0.0000,'2025-01-15 13:51:25','2025-01-15 13:51:25'),
(3,5,NULL,1,4.0000,0.0000,'2025-01-15 14:02:14','2025-01-15 14:02:14'),
(4,6,NULL,1,20.0000,0.0000,'2025-01-17 11:11:11','2025-01-17 11:11:11'),
(5,7,NULL,2,7.0000,0.0000,'2025-01-17 11:11:11','2025-01-17 11:11:11'),
(6,8,NULL,2,9.0000,0.0000,'2025-01-17 11:57:56','2025-01-17 11:57:56'),
(7,9,NULL,3,1.0000,0.0000,'2025-01-17 11:57:56','2025-01-17 11:57:56'),
(8,10,NULL,1,5.0000,0.0000,'2025-01-17 11:57:56','2025-01-17 11:57:56'),
(9,11,NULL,1,7.0000,0.0000,'2025-01-17 12:10:41','2025-01-17 12:10:41'),
(10,12,NULL,3,7.0000,0.0000,'2025-01-17 12:13:55','2025-01-17 12:13:55'),
(11,13,NULL,1,4.0000,0.0000,'2025-01-17 12:19:38','2025-01-17 12:19:38'),
(12,14,NULL,1,10.0000,0.0000,'2025-01-17 12:28:17','2025-01-17 12:28:17'),
(13,15,NULL,3,6.0000,0.0000,'2025-01-20 15:43:49','2025-01-20 15:43:49'),
(14,16,NULL,1,22.0000,0.0000,'2025-01-20 15:44:27','2025-01-20 15:44:27'),
(15,17,NULL,1,20.0000,0.0000,'2025-01-20 15:48:06','2025-01-20 15:48:06'),
(16,18,NULL,3,5.0000,0.0000,'2025-01-22 22:28:56','2025-01-22 22:28:56'),
(17,19,NULL,3,1.0000,0.0000,'2025-01-23 08:22:09','2025-01-23 08:22:09'),
(18,20,NULL,2,2.0000,0.0000,'2025-01-23 09:06:10','2025-01-23 09:06:10'),
(19,24,NULL,1,1.0000,0.0000,'2025-01-23 09:38:57','2025-01-23 09:38:57'),
(20,25,NULL,2,9.0000,0.0000,'2025-01-23 09:38:57','2025-01-23 09:38:57'),
(21,27,NULL,2,2.0000,0.0000,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(22,28,NULL,3,6.0000,0.0000,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(23,29,NULL,1,1.0000,0.0000,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(24,30,NULL,1,1.0000,0.0000,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(25,31,NULL,1,1.0000,0.0000,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(26,32,NULL,1,1.0000,0.0000,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(27,33,NULL,1,1.0000,0.0000,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(28,34,NULL,1,1.0000,0.0000,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(29,35,NULL,1,1.0000,0.0000,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(30,36,NULL,1,1.0000,0.0000,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(31,37,NULL,1,1.0000,0.0000,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(32,38,NULL,1,1.0000,0.0000,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(33,39,NULL,1,1.0000,0.0000,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(34,40,NULL,1,1.0000,0.0000,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(35,41,NULL,1,1.0000,0.0000,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(36,42,NULL,1,1.0000,0.0000,'2025-01-23 09:42:47','2025-01-23 09:42:47'),
(37,43,NULL,1,1.0000,0.0000,'2025-01-23 09:42:47','2025-01-23 09:42:47'),
(38,44,NULL,1,1.0000,0.0000,'2025-01-23 09:42:47','2025-01-23 09:42:47'),
(39,45,NULL,1,1.0000,0.0000,'2025-01-23 09:42:47','2025-01-23 09:42:47'),
(40,46,NULL,1,1.0000,0.0000,'2025-01-23 09:42:47','2025-01-23 09:42:47'),
(41,47,NULL,3,5.0000,0.0000,'2025-01-23 09:42:47','2025-01-23 09:42:47'),
(42,48,NULL,2,6.0000,0.0000,'2025-01-23 09:42:47','2025-01-23 09:42:47'),
(43,49,NULL,4,8.0000,0.0000,'2025-01-23 09:43:28','2025-01-23 09:43:28'),
(44,50,NULL,4,12.0000,0.0000,'2025-01-23 09:45:49','2025-01-23 09:45:49'),
(45,51,NULL,4,1.0000,0.0000,'2025-01-23 09:48:38','2025-01-23 09:48:38'),
(46,52,NULL,1,1.0000,0.0000,'2025-01-23 09:48:38','2025-01-23 09:48:38'),
(47,54,NULL,4,12.0000,0.0000,'2025-01-23 09:50:33','2025-01-23 09:50:33'),
(48,55,NULL,5,13.0000,0.0000,'2025-01-23 09:55:54','2025-01-23 09:55:54'),
(49,56,NULL,1,1.0000,0.0000,'2025-01-23 10:01:17','2025-01-23 10:01:17'),
(50,57,NULL,2,1.0000,0.0000,'2025-01-23 10:01:17','2025-01-23 10:01:17'),
(51,60,NULL,1,1.0000,0.0000,'2025-01-23 10:16:03','2025-01-23 10:16:03'),
(52,61,NULL,3,1.0000,0.0000,'2025-01-23 10:16:03','2025-01-23 10:16:03'),
(53,62,NULL,2,1.0000,0.0000,'2025-01-23 10:16:03','2025-01-23 10:16:03'),
(54,63,NULL,4,1.0000,0.0000,'2025-01-23 10:16:03','2025-01-23 10:16:03'),
(55,64,NULL,5,1.0000,0.0000,'2025-01-23 10:16:03','2025-01-23 10:16:03'),
(56,65,NULL,3,1.0000,0.0000,'2025-01-23 10:37:23','2025-01-23 10:37:23'),
(57,66,NULL,2,1.0000,0.0000,'2025-01-23 10:37:23','2025-01-23 10:37:23'),
(58,67,NULL,1,1.0000,0.0000,'2025-01-23 11:56:05','2025-01-23 11:56:05'),
(59,68,NULL,1,1.0000,0.0000,'2025-01-23 11:56:05','2025-01-23 11:56:05'),
(60,69,NULL,3,1.0000,0.0000,'2025-01-23 11:58:22','2025-01-23 11:58:22'),
(61,70,NULL,2,1.0000,0.0000,'2025-01-23 11:59:11','2025-01-23 11:59:11'),
(62,71,NULL,3,1.0000,0.0000,'2025-01-23 11:59:11','2025-01-23 11:59:11'),
(63,72,NULL,4,1.0000,0.0000,'2025-01-23 11:59:11','2025-01-23 11:59:11'),
(64,73,NULL,3,1.0000,0.0000,'2025-01-23 12:00:32','2025-01-23 12:00:32'),
(65,74,NULL,2,1.0000,0.0000,'2025-01-23 12:00:32','2025-01-23 12:00:32'),
(66,75,NULL,3,1.0000,0.0000,'2025-01-23 12:03:39','2025-01-23 12:03:39'),
(67,76,NULL,2,1.0000,0.0000,'2025-01-23 12:03:39','2025-01-23 12:03:39'),
(68,77,NULL,3,1.0000,0.0000,'2025-01-23 12:05:53','2025-01-23 12:05:53'),
(69,78,NULL,3,1.0000,0.0000,'2025-01-23 12:06:21','2025-01-23 12:06:21'),
(70,79,NULL,2,1.0000,0.0000,'2025-01-23 12:09:48','2025-01-23 12:09:48'),
(71,80,NULL,4,1.0000,0.0000,'2025-01-23 12:10:41','2025-01-23 12:10:41'),
(72,81,NULL,2,1.0000,0.0000,'2025-01-23 12:12:12','2025-01-23 12:12:12'),
(73,82,NULL,4,1.0000,0.0000,'2025-01-23 12:12:21','2025-01-23 12:12:21'),
(74,83,NULL,4,1.0000,0.0000,'2025-01-23 12:12:39','2025-01-23 12:12:39'),
(75,84,NULL,4,1.0000,0.0000,'2025-01-23 12:14:15','2025-01-23 12:14:15'),
(76,85,NULL,4,1.0000,0.0000,'2025-01-23 12:15:22','2025-01-23 12:15:22'),
(77,86,NULL,4,1.0000,0.0000,'2025-01-23 12:16:26','2025-01-23 12:16:26'),
(78,87,NULL,4,1.0000,0.0000,'2025-01-23 12:18:11','2025-01-23 12:18:11'),
(79,88,NULL,4,1.0000,0.0000,'2025-01-23 12:18:54','2025-01-23 12:18:54'),
(80,89,NULL,4,1.0000,0.0000,'2025-01-23 12:19:01','2025-01-23 12:19:01'),
(81,90,NULL,4,2.0000,0.0000,'2025-01-23 12:20:03','2025-01-23 12:20:03'),
(82,91,NULL,5,1.0000,0.0000,'2025-01-23 12:25:35','2025-01-23 12:25:35'),
(83,92,NULL,4,1.0000,0.0000,'2025-01-23 12:26:30','2025-01-23 12:26:30'),
(84,93,NULL,5,1.0000,0.0000,'2025-01-23 12:27:06','2025-01-23 12:27:06'),
(85,94,NULL,5,1.0000,0.0000,'2025-01-23 12:27:28','2025-01-23 12:27:28'),
(86,95,NULL,5,1.0000,0.0000,'2025-01-23 12:29:06','2025-01-23 12:29:06'),
(87,96,NULL,5,1.0000,0.0000,'2025-01-23 12:31:19','2025-01-23 12:31:19'),
(88,97,NULL,4,1.0000,0.0000,'2025-01-23 12:32:58','2025-01-23 12:32:58'),
(89,98,NULL,5,1.0000,0.0000,'2025-01-23 12:32:58','2025-01-23 12:32:58'),
(90,99,NULL,4,2.0000,0.0000,'2025-01-23 12:34:20','2025-01-23 12:34:20'),
(91,100,NULL,5,1.0000,0.0000,'2025-01-23 12:34:20','2025-01-23 12:34:20'),
(92,101,NULL,2,1000.0000,0.0000,'2025-01-23 14:08:03','2025-01-23 14:08:03'),
(93,102,NULL,2,500.0000,0.0000,'2025-01-23 14:09:39','2025-01-23 14:09:39'),
(94,103,NULL,3,300.0000,0.0000,'2025-01-23 14:10:18','2025-01-23 14:10:18'),
(95,104,NULL,3,200.0000,0.0000,'2025-01-23 14:10:50','2025-01-23 14:10:50'),
(96,105,NULL,7,280.0000,0.0000,'2025-01-23 14:11:28','2025-01-23 14:11:28'),
(97,106,NULL,7,220.0000,0.0000,'2025-01-23 14:11:56','2025-01-23 14:11:56'),
(98,107,NULL,8,700.0000,0.0000,'2025-01-23 14:12:26','2025-01-23 14:12:26'),
(99,108,NULL,8,300.0000,0.0000,'2025-01-23 14:13:13','2025-01-23 14:13:13'),
(100,109,NULL,6,400.0000,0.0000,'2025-01-23 14:16:52','2025-01-23 14:16:52'),
(101,110,NULL,6,600.0000,0.0000,'2025-01-23 14:20:13','2025-01-23 14:20:13'),
(102,111,NULL,10,1.0000,0.0000,'2025-01-23 14:47:06','2025-01-23 14:47:06'),
(103,112,NULL,10,1.0000,0.0000,'2025-01-23 14:49:26','2025-01-23 14:49:26');
/*!40000 ALTER TABLE `transaction_sell_lines_purchase_lines` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `location_id` int(10) unsigned DEFAULT NULL,
  `is_kitchen_order` tinyint(1) NOT NULL DEFAULT 0,
  `res_table_id` int(10) unsigned DEFAULT NULL COMMENT 'fields to restaurant module',
  `res_waiter_id` int(10) unsigned DEFAULT NULL COMMENT 'fields to restaurant module',
  `res_order_status` enum('received','cooked','served') DEFAULT NULL,
  `type` varchar(191) DEFAULT NULL,
  `sub_type` varchar(20) DEFAULT NULL,
  `status` varchar(191) NOT NULL,
  `sub_status` varchar(191) DEFAULT NULL,
  `is_quotation` tinyint(1) NOT NULL DEFAULT 0,
  `payment_status` enum('paid','due','partial') DEFAULT NULL,
  `adjustment_type` enum('normal','abnormal') DEFAULT NULL,
  `contact_id` int(11) unsigned DEFAULT NULL,
  `customer_group_id` int(11) DEFAULT NULL COMMENT 'used to add customer group while selling',
  `invoice_no` varchar(191) DEFAULT NULL,
  `ref_no` varchar(191) DEFAULT NULL,
  `source` varchar(191) DEFAULT NULL,
  `subscription_no` varchar(191) DEFAULT NULL,
  `subscription_repeat_on` varchar(191) DEFAULT NULL,
  `transaction_date` datetime NOT NULL,
  `total_before_tax` decimal(22,4) NOT NULL DEFAULT 0.0000 COMMENT 'Total before the purchase/invoice tax, this includeds the indivisual product tax',
  `tax_id` int(10) unsigned DEFAULT NULL,
  `tax_amount` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `discount_type` enum('fixed','percentage') DEFAULT NULL,
  `discount_amount` decimal(22,4) DEFAULT 0.0000,
  `rp_redeemed` int(11) NOT NULL DEFAULT 0 COMMENT 'rp is the short form of reward points',
  `rp_redeemed_amount` decimal(22,4) NOT NULL DEFAULT 0.0000 COMMENT 'rp is the short form of reward points',
  `shipping_details` varchar(191) DEFAULT NULL,
  `shipping_address` text DEFAULT NULL,
  `delivery_date` datetime DEFAULT NULL,
  `shipping_status` varchar(191) DEFAULT NULL,
  `delivered_to` varchar(191) DEFAULT NULL,
  `delivery_person` bigint(20) DEFAULT NULL,
  `shipping_charges` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `shipping_custom_field_1` varchar(191) DEFAULT NULL,
  `shipping_custom_field_2` varchar(191) DEFAULT NULL,
  `shipping_custom_field_3` varchar(191) DEFAULT NULL,
  `shipping_custom_field_4` varchar(191) DEFAULT NULL,
  `shipping_custom_field_5` varchar(191) DEFAULT NULL,
  `additional_notes` text DEFAULT NULL,
  `staff_note` text DEFAULT NULL,
  `is_export` tinyint(1) NOT NULL DEFAULT 0,
  `export_custom_fields_info` longtext DEFAULT NULL,
  `round_off_amount` decimal(22,4) NOT NULL DEFAULT 0.0000 COMMENT 'Difference of rounded total and actual total',
  `additional_expense_key_1` varchar(191) DEFAULT NULL,
  `additional_expense_value_1` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `additional_expense_key_2` varchar(191) DEFAULT NULL,
  `additional_expense_value_2` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `additional_expense_key_3` varchar(191) DEFAULT NULL,
  `additional_expense_value_3` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `additional_expense_key_4` varchar(191) DEFAULT NULL,
  `additional_expense_value_4` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `final_total` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `expense_category_id` int(10) unsigned DEFAULT NULL,
  `expense_sub_category_id` int(11) DEFAULT NULL,
  `expense_for` int(10) unsigned DEFAULT NULL,
  `commission_agent` int(11) DEFAULT NULL,
  `document` varchar(191) DEFAULT NULL,
  `is_direct_sale` tinyint(1) NOT NULL DEFAULT 0,
  `is_suspend` tinyint(1) NOT NULL DEFAULT 0,
  `exchange_rate` decimal(20,3) NOT NULL DEFAULT 1.000,
  `total_amount_recovered` decimal(22,4) DEFAULT NULL COMMENT 'Used for stock adjustment.',
  `transfer_parent_id` int(11) DEFAULT NULL,
  `return_parent_id` int(11) DEFAULT NULL,
  `opening_stock_product_id` int(11) DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `essentials_duration` decimal(8,2) NOT NULL,
  `essentials_duration_unit` varchar(20) DEFAULT NULL,
  `essentials_amount_per_unit_duration` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `essentials_allowances` text DEFAULT NULL,
  `essentials_deductions` text DEFAULT NULL,
  `purchase_requisition_ids` text DEFAULT NULL,
  `prefer_payment_method` varchar(191) DEFAULT NULL,
  `prefer_payment_account` int(11) DEFAULT NULL,
  `sales_order_ids` text DEFAULT NULL,
  `purchase_order_ids` text DEFAULT NULL,
  `custom_field_1` varchar(191) DEFAULT NULL,
  `custom_field_2` varchar(191) DEFAULT NULL,
  `custom_field_3` varchar(191) DEFAULT NULL,
  `custom_field_4` varchar(191) DEFAULT NULL,
  `import_batch` int(11) DEFAULT NULL,
  `import_time` datetime DEFAULT NULL,
  `types_of_service_id` int(11) DEFAULT NULL,
  `packing_charge` decimal(22,4) DEFAULT NULL,
  `packing_charge_type` enum('fixed','percent') DEFAULT NULL,
  `service_custom_field_1` text DEFAULT NULL,
  `service_custom_field_2` text DEFAULT NULL,
  `service_custom_field_3` text DEFAULT NULL,
  `service_custom_field_4` text DEFAULT NULL,
  `service_custom_field_5` text DEFAULT NULL,
  `service_custom_field_6` text DEFAULT NULL,
  `is_created_from_api` tinyint(1) NOT NULL DEFAULT 0,
  `rp_earned` int(11) NOT NULL DEFAULT 0 COMMENT 'rp is the short form of reward points',
  `order_addresses` text DEFAULT NULL,
  `is_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `recur_interval` double(22,4) DEFAULT NULL,
  `recur_interval_type` enum('days','months','years') DEFAULT NULL,
  `recur_repetitions` int(11) DEFAULT NULL,
  `recur_stopped_on` datetime DEFAULT NULL,
  `recur_parent_id` int(11) DEFAULT NULL,
  `invoice_token` varchar(191) DEFAULT NULL,
  `pay_term_number` int(11) DEFAULT NULL,
  `pay_term_type` enum('days','months') DEFAULT NULL,
  `selling_price_group_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transactions_tax_id_foreign` (`tax_id`),
  KEY `transactions_business_id_index` (`business_id`),
  KEY `transactions_type_index` (`type`),
  KEY `transactions_contact_id_index` (`contact_id`),
  KEY `transactions_transaction_date_index` (`transaction_date`),
  KEY `transactions_created_by_index` (`created_by`),
  KEY `transactions_location_id_index` (`location_id`),
  KEY `transactions_expense_for_foreign` (`expense_for`),
  KEY `transactions_expense_category_id_index` (`expense_category_id`),
  KEY `transactions_sub_type_index` (`sub_type`),
  KEY `transactions_return_parent_id_index` (`return_parent_id`),
  KEY `type` (`type`),
  KEY `transactions_status_index` (`status`),
  KEY `transactions_sub_status_index` (`sub_status`),
  KEY `transactions_res_table_id_index` (`res_table_id`),
  KEY `transactions_res_waiter_id_index` (`res_waiter_id`),
  KEY `transactions_res_order_status_index` (`res_order_status`),
  KEY `transactions_payment_status_index` (`payment_status`),
  KEY `transactions_discount_type_index` (`discount_type`),
  KEY `transactions_commission_agent_index` (`commission_agent`),
  KEY `transactions_transfer_parent_id_index` (`transfer_parent_id`),
  KEY `transactions_types_of_service_id_index` (`types_of_service_id`),
  KEY `transactions_packing_charge_type_index` (`packing_charge_type`),
  KEY `transactions_recur_parent_id_index` (`recur_parent_id`),
  KEY `transactions_selling_price_group_id_index` (`selling_price_group_id`),
  KEY `transactions_delivery_date_index` (`delivery_date`),
  KEY `transactions_delivery_person_index` (`delivery_person`),
  CONSTRAINT `transactions_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_expense_category_id_foreign` FOREIGN KEY (`expense_category_id`) REFERENCES `expense_categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_expense_for_foreign` FOREIGN KEY (`expense_for`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `business_locations` (`id`),
  CONSTRAINT `transactions_tax_id_foreign` FOREIGN KEY (`tax_id`) REFERENCES `tax_rates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES
(1,1,1,0,NULL,NULL,NULL,'purchase',NULL,'received',NULL,0,'paid',NULL,2,NULL,NULL,'PO2025/0001',NULL,NULL,NULL,'2025-01-09 11:59:00',0.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,0.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-09 12:00:40','2025-01-09 12:00:40'),
(2,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0001','',NULL,NULL,NULL,'2025-01-09 12:02:22',800.0000,NULL,0.0000,'percentage',100.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,0.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-09 12:02:22','2025-01-09 12:02:22'),
(3,1,1,0,NULL,NULL,NULL,'sell',NULL,'draft','quotation',1,NULL,NULL,3,NULL,'2025/0001','',NULL,NULL,NULL,'2025-01-09 12:03:19',10000.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,10000.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-09 12:03:19','2025-01-09 12:03:19'),
(4,1,1,0,NULL,NULL,NULL,'sell',NULL,'draft',NULL,0,NULL,NULL,1,NULL,'2025/0002','',NULL,NULL,NULL,'2025-01-11 10:43:35',700.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,700.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-11 10:43:35','2025-01-11 10:43:35'),
(5,1,1,0,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-01 13:50:00',772000.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,772000.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,2,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-15 13:50:25','2025-01-23 13:31:56'),
(6,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0002','',NULL,NULL,NULL,'2025-01-15 13:51:25',350.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,350.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-15 13:51:25','2025-01-15 13:51:25'),
(7,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0003','',NULL,NULL,NULL,'2025-01-15 14:02:14',400.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,400.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-15 14:02:14','2025-01-15 14:02:14'),
(8,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0004','',NULL,NULL,NULL,'2025-01-17 11:11:11',4450.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,4450.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-17 11:11:11','2025-01-17 11:11:11'),
(9,1,1,0,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-01 11:47:00',134750.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,134750.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,3,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-17 11:47:59','2025-01-23 13:30:38'),
(10,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0005','',NULL,NULL,NULL,'2025-01-17 11:57:56',3900.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,3900.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-17 11:57:56','2025-01-17 11:57:56'),
(11,1,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0006','',NULL,NULL,NULL,'2025-01-17 12:10:41',700.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,700.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-17 12:10:41','2025-01-17 12:10:41'),
(12,1,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0007','',NULL,NULL,NULL,'2025-01-17 12:13:55',1750.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1750.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-17 12:13:55','2025-01-17 12:13:55'),
(13,1,1,1,1,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0008','',NULL,NULL,NULL,'2025-01-17 12:19:38',400.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,400.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-17 12:19:38','2025-01-17 12:19:38'),
(14,1,1,1,1,5,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0009','',NULL,NULL,NULL,'2025-01-17 12:28:17',1000.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1000.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-17 12:28:17','2025-01-17 12:28:17'),
(15,2,NULL,0,NULL,NULL,NULL,'payroll',NULL,'final',NULL,0,'due',NULL,NULL,NULL,NULL,'2025/0001',NULL,NULL,NULL,'2025-01-01 00:00:00',11000.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,11000.0000,NULL,NULL,6,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,4,1.00,'Month',11000.0000,'{\"allowance_names\":[],\"allowance_amounts\":[],\"allowance_types\":[\"fixed\",\"fixed\",\"fixed\"],\"allowance_percents\":[]}','{\"deduction_names\":[],\"deduction_amounts\":[],\"deduction_types\":[\"fixed\",\"fixed\",\"fixed\"],\"deduction_percents\":[]}',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-17 15:48:51','2025-01-17 15:48:51'),
(16,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'partial',NULL,3,NULL,'0010','',NULL,NULL,NULL,'2025-01-20 15:43:49',1500.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1500.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-20 15:43:49','2025-01-20 15:43:49'),
(17,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'partial',NULL,3,NULL,'0011','',NULL,NULL,NULL,'2025-01-20 15:44:27',2200.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,2200.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,'000f960767a754260aa8f2e73027ee80',NULL,NULL,0,'2025-01-20 15:44:27','2025-01-20 15:45:11'),
(18,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,5,NULL,'0012','',NULL,NULL,NULL,'2025-01-20 15:47:00',2000.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,2000.0000,NULL,NULL,NULL,NULL,NULL,1,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,'0c01c93fe16cb715b2425379a960fac6',1,'days',NULL,'2025-01-20 15:48:06','2025-01-23 14:55:11'),
(19,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0013','',NULL,NULL,NULL,'2025-01-22 22:28:56',1250.0000,NULL,0.0000,'fixed',20.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1230.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-22 22:28:56','2025-01-22 22:28:56'),
(20,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0014','',NULL,NULL,NULL,'2025-01-23 08:22:09',250.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,250.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0.0000,'fixed',NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 08:22:09','2025-01-23 08:22:09'),
(21,1,1,0,1,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0015','',NULL,NULL,NULL,'2025-01-23 09:06:10',700.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,700.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 09:06:10','2025-01-23 09:06:10'),
(22,1,1,0,NULL,NULL,NULL,'sell',NULL,'draft',NULL,0,NULL,NULL,1,NULL,'2025/0003','',NULL,NULL,NULL,'2025-01-23 09:06:46',700.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,700.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 09:06:46','2025-01-23 09:06:46'),
(23,1,1,0,NULL,NULL,NULL,'sell',NULL,'draft','quotation',1,NULL,NULL,1,NULL,'2025/0004','',NULL,NULL,NULL,'2025-01-23 09:31:04',110.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,110.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 09:31:04','2025-01-23 09:31:04'),
(24,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0016','',NULL,NULL,NULL,'2025-01-23 09:38:57',3260.0000,1,391.2000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,3651.2000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 09:38:57','2025-01-23 09:38:57'),
(25,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0017','',NULL,NULL,NULL,'2025-01-23 09:41:08',3500.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,3500.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 09:41:08','2025-01-23 09:41:08'),
(26,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0018','',NULL,NULL,NULL,'2025-01-23 09:42:47',3850.0000,1,462.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,4312.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 09:42:47','2025-01-23 09:42:47'),
(27,1,1,0,NULL,NULL,NULL,'purchase',NULL,'received',NULL,0,'paid',NULL,2,NULL,NULL,'PO2025/0002',NULL,NULL,NULL,'2025-01-23 09:42:00',250000000.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,250000000.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 09:43:13','2025-01-23 14:46:05'),
(28,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0019','',NULL,NULL,NULL,'2025-01-23 09:43:28',4000.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,4000.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 09:43:28','2025-01-23 09:43:28'),
(29,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0020','',NULL,NULL,NULL,'2025-01-23 09:45:49',6000.0000,2,180.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,6180.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 09:45:49','2025-01-23 09:45:49'),
(30,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0021','',NULL,NULL,NULL,'2025-01-23 09:48:38',610.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,610.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 09:48:38','2025-01-23 09:48:38'),
(31,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0022','',NULL,NULL,NULL,'2025-01-23 09:50:33',6000.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,6000.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 09:50:33','2025-01-23 09:50:33'),
(32,1,1,0,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-01 09:55:40',11.9952,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,11995.2000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,8,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 09:55:40','2025-01-23 09:55:40'),
(33,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0023','',NULL,NULL,NULL,'2025-01-23 09:55:54',650000.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,650000.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,'60ccb5755f86045a3c1845385c6289df',NULL,NULL,0,'2025-01-23 09:55:54','2025-01-23 10:00:29'),
(34,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0024','',NULL,NULL,NULL,'2025-01-23 10:01:17',464.0000,1,55.6800,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,519.6800,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 10:01:17','2025-01-23 10:01:17'),
(35,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0025','',NULL,NULL,NULL,'2025-01-23 10:16:03',51200.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,51200.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 10:16:03','2025-01-23 10:16:03'),
(36,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0026','',NULL,NULL,NULL,'2025-01-23 10:37:23',600.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,600.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,'c0d6db864c066917756882bd0427b0ea',NULL,NULL,0,'2025-01-23 10:37:23','2025-01-23 10:53:25'),
(37,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0027','',NULL,NULL,NULL,'2025-01-23 11:56:05',200.0000,1,24.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,224.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 11:56:05','2025-01-23 11:56:05'),
(38,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0028','',NULL,NULL,NULL,'2025-01-23 11:58:22',250.0000,1,30.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,280.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 11:58:22','2025-01-23 11:58:22'),
(39,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0029','',NULL,NULL,NULL,'2025-01-23 11:59:11',1100.0000,1,132.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1232.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 11:59:11','2025-01-23 11:59:11'),
(40,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0030','',NULL,NULL,NULL,'2025-01-23 12:00:32',600.0000,1,72.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,672.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 12:00:32','2025-01-23 12:00:32'),
(41,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0031','',NULL,NULL,NULL,'2025-01-23 12:03:39',600.0000,1,72.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,672.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 12:03:39','2025-01-23 12:03:39'),
(42,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0032','',NULL,NULL,NULL,'2025-01-23 12:05:53',250.0000,1,30.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,280.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 12:05:53','2025-01-23 12:05:53'),
(43,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0033','',NULL,NULL,NULL,'2025-01-23 12:06:21',250.0000,1,30.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,280.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 12:06:21','2025-01-23 12:06:21'),
(44,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0034','',NULL,NULL,NULL,'2025-01-23 12:09:48',350.0000,1,42.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,392.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 12:09:48','2025-01-23 12:09:48'),
(45,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0035','',NULL,NULL,NULL,'2025-01-23 12:10:41',500.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,500.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 12:10:41','2025-01-23 12:10:41'),
(46,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0036','',NULL,NULL,NULL,'2025-01-23 12:12:12',350.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,350.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 12:12:12','2025-01-23 12:12:12'),
(47,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0037','',NULL,NULL,NULL,'2025-01-23 12:12:21',500.0000,1,60.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,560.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 12:12:21','2025-01-23 12:12:21'),
(48,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0038','',NULL,NULL,NULL,'2025-01-23 12:12:39',500.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,500.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 12:12:39','2025-01-23 12:12:39'),
(49,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0039','',NULL,NULL,NULL,'2025-01-23 12:14:15',446.4300,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,446.4300,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 12:14:15','2025-01-23 12:14:15'),
(50,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0040','',NULL,NULL,NULL,'2025-01-23 12:15:22',446.4300,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,446.4300,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 12:15:22','2025-01-23 12:15:22'),
(51,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0041','',NULL,NULL,NULL,'2025-01-23 12:16:26',500.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,500.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 12:16:26','2025-01-23 12:16:26'),
(52,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0042','',NULL,NULL,NULL,'2025-01-23 12:18:11',500.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,500.0000,NULL,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 12:18:11','2025-01-23 12:18:11'),
(53,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0043','',NULL,NULL,NULL,'2025-01-23 12:18:54',500.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,500.0000,NULL,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 12:18:54','2025-01-23 12:18:54'),
(54,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0044','',NULL,NULL,NULL,'2025-01-23 12:19:01',500.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,500.0000,NULL,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 12:19:01','2025-01-23 12:19:01'),
(55,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0045','',NULL,NULL,NULL,'2025-01-23 12:20:03',1000.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1000.0000,NULL,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 12:20:03','2025-01-23 12:20:03'),
(56,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0046','',NULL,NULL,NULL,'2025-01-23 12:25:35',50000.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,50000.0000,NULL,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 12:25:35','2025-01-23 12:25:35'),
(57,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0047','',NULL,NULL,NULL,'2025-01-23 12:26:30',500.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,500.0000,NULL,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 12:26:30','2025-01-23 12:26:30'),
(58,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0048','',NULL,NULL,NULL,'2025-01-23 12:27:06',50000.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,50000.0000,NULL,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 12:27:06','2025-01-23 12:27:06'),
(59,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0049','',NULL,NULL,NULL,'2025-01-23 12:27:28',50000.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,50000.0000,NULL,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 12:27:28','2025-01-23 12:27:28'),
(60,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0050','',NULL,NULL,NULL,'2025-01-23 12:29:06',50000.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,50000.0000,NULL,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 12:29:06','2025-01-23 12:29:06'),
(61,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'2025-00000051','',NULL,NULL,NULL,'2025-01-23 12:31:19',50000.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,50000.0000,NULL,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 12:31:19','2025-01-23 12:31:19'),
(62,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'2025-00000052','',NULL,NULL,NULL,'2025-01-23 12:32:58',50500.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,50500.0000,NULL,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 12:32:58','2025-01-23 12:32:58'),
(63,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'2025-00000053','',NULL,NULL,NULL,'2025-01-23 12:34:20',51000.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,51000.0000,NULL,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 12:34:20','2025-01-23 12:34:20'),
(64,1,1,0,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-01 13:28:35',500.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,500000.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,9,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 13:28:35','2025-01-23 13:28:35'),
(65,1,1,0,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-01 13:38:40',500.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,250000.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,10,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 13:38:40','2025-01-23 13:38:40'),
(66,1,1,0,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-01 13:45:48',500.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,500000.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,12,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 13:45:48','2025-01-23 13:45:48'),
(67,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,8,NULL,'2025-00000054','',NULL,NULL,NULL,'2025-01-23 14:08:03',500000.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,500000.0000,NULL,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 14:08:03','2025-01-23 14:08:03'),
(68,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,8,NULL,'2025-00000055','',NULL,NULL,NULL,'2025-01-23 14:09:39',250000.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,250000.0000,NULL,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 14:09:39','2025-01-23 14:09:39'),
(69,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,10,NULL,'2025-00000056','',NULL,NULL,NULL,'2025-01-23 14:10:18',150000.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,150000.0000,NULL,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 14:10:18','2025-01-23 14:10:18'),
(70,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,10,NULL,'2025-00000057','',NULL,NULL,NULL,'2025-01-23 14:10:50',100000.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,100000.0000,NULL,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 14:10:50','2025-01-23 14:10:50'),
(71,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,11,NULL,'2025-00000058','',NULL,NULL,NULL,'2025-01-23 14:11:28',140000.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,140000.0000,NULL,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 14:11:28','2025-01-23 14:11:28'),
(72,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,11,NULL,'2025-00000059','',NULL,NULL,NULL,'2025-01-23 14:11:56',110000.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,110000.0000,NULL,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 14:11:56','2025-01-23 14:11:56'),
(73,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,9,NULL,'2025-00000060','',NULL,NULL,NULL,'2025-01-23 14:12:26',350000.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,350000.0000,NULL,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 14:12:26','2025-01-23 14:12:26'),
(74,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,9,NULL,'2025-00000061','',NULL,NULL,NULL,'2025-01-23 14:13:12',150000.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,150000.0000,NULL,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 14:13:13','2025-01-23 14:13:13'),
(75,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,12,NULL,'2025-00000062','',NULL,NULL,NULL,'2025-01-23 14:16:52',200000.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,200000.0000,NULL,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 14:16:52','2025-01-23 14:16:52'),
(76,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,12,NULL,'2025-00000063','',NULL,NULL,NULL,'2025-01-23 14:20:13',300000.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,300000.0000,NULL,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 14:20:13','2025-01-23 14:20:13'),
(77,1,1,0,NULL,NULL,NULL,'purchase_order',NULL,'ordered',NULL,0,NULL,NULL,17,NULL,NULL,'2025/0001',NULL,NULL,NULL,'2025-01-23 14:43:00',280000.0000,NULL,0.0000,NULL,0.0000,0,0.0000,'Received',NULL,'2025-01-23 14:43:00','delivered',NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,280000.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,2,'days',NULL,'2025-01-23 14:44:38','2025-01-23 14:55:42'),
(78,1,1,0,NULL,NULL,NULL,'purchase',NULL,'received',NULL,0,'partial',NULL,17,NULL,NULL,'PO2025/0003',NULL,NULL,NULL,'2025-01-23 14:44:00',2800000.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,2800000.0000,NULL,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,2,'months',NULL,'2025-01-23 14:45:53','2025-01-23 14:45:53'),
(79,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'2025-00000064','',NULL,NULL,NULL,'2025-01-23 14:47:06',560.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,560.0000,NULL,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 14:47:06','2025-01-23 14:47:06'),
(80,1,1,0,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'2025-00000065','',NULL,NULL,NULL,'2025-01-23 14:49:26',560.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,560.0000,NULL,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2025-01-23 14:49:26','2025-01-23 14:49:26'),
(81,1,1,0,NULL,NULL,NULL,'expense',NULL,'final',NULL,0,'paid',NULL,NULL,NULL,NULL,'10005255',NULL,NULL,NULL,'2025-01-23 14:50:00',1339.2857,1,160.7143,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,'Siomai',NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1500.0000,NULL,NULL,1,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 14:50:32','2025-01-23 14:50:32');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `types_of_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `types_of_services` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `business_id` int(11) NOT NULL,
  `location_price_group` text DEFAULT NULL,
  `packing_charge` decimal(22,4) DEFAULT NULL,
  `packing_charge_type` enum('fixed','percent') DEFAULT NULL,
  `enable_custom_fields` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `types_of_services_business_id_index` (`business_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `types_of_services` WRITE;
/*!40000 ALTER TABLE `types_of_services` DISABLE KEYS */;
/*!40000 ALTER TABLE `types_of_services` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `units` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `actual_name` varchar(191) NOT NULL,
  `short_name` varchar(191) NOT NULL,
  `allow_decimal` tinyint(1) NOT NULL,
  `base_unit_id` int(11) DEFAULT NULL,
  `base_unit_multiplier` decimal(20,4) DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `units_business_id_foreign` (`business_id`),
  KEY `units_created_by_foreign` (`created_by`),
  KEY `units_base_unit_id_index` (`base_unit_id`),
  CONSTRAINT `units_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `units_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
INSERT INTO `units` VALUES
(1,1,'Pieces','Pc(s)',0,NULL,NULL,1,NULL,'2024-08-01 04:19:13','2024-08-01 04:19:13'),
(2,2,'Pieces','Pc(s)',0,NULL,NULL,4,NULL,'2025-01-17 12:03:44','2025-01-17 12:03:44'),
(3,3,'Pieces','Pc(s)',0,NULL,NULL,11,NULL,'2025-01-23 10:41:35','2025-01-23 10:41:35');
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_contact_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_contact_access` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_contact_access_user_id_index` (`user_id`),
  KEY `user_contact_access_contact_id_index` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_contact_access` WRITE;
/*!40000 ALTER TABLE `user_contact_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_contact_access` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_type` varchar(191) NOT NULL DEFAULT 'user',
  `surname` char(10) DEFAULT NULL,
  `first_name` varchar(191) NOT NULL,
  `last_name` varchar(191) DEFAULT NULL,
  `username` varchar(191) DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `password` varchar(191) DEFAULT NULL,
  `language` char(7) NOT NULL DEFAULT 'en',
  `contact_no` char(15) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `business_id` int(10) unsigned DEFAULT NULL,
  `essentials_department_id` int(11) DEFAULT NULL,
  `essentials_designation_id` int(11) DEFAULT NULL,
  `essentials_salary` decimal(22,4) DEFAULT NULL,
  `essentials_pay_period` varchar(191) DEFAULT NULL,
  `essentials_pay_cycle` varchar(191) DEFAULT NULL,
  `available_at` datetime DEFAULT NULL COMMENT 'Service staff avilable at. Calculated from product preparation_time_in_minutes',
  `paused_at` datetime DEFAULT NULL COMMENT 'Service staff available time paused at, Will be nulled on resume.',
  `max_sales_discount_percent` decimal(5,2) DEFAULT NULL,
  `allow_login` tinyint(1) NOT NULL DEFAULT 1,
  `status` enum('active','inactive','terminated') NOT NULL DEFAULT 'active',
  `is_enable_service_staff_pin` tinyint(1) NOT NULL DEFAULT 0,
  `service_staff_pin` text DEFAULT NULL,
  `crm_contact_id` int(10) unsigned DEFAULT NULL,
  `is_cmmsn_agnt` tinyint(1) NOT NULL DEFAULT 0,
  `cmmsn_percent` decimal(4,2) NOT NULL DEFAULT 0.00,
  `selected_contacts` tinyint(1) NOT NULL DEFAULT 0,
  `dob` date DEFAULT NULL,
  `gender` varchar(191) DEFAULT NULL,
  `marital_status` enum('married','unmarried','divorced') DEFAULT NULL,
  `blood_group` char(10) DEFAULT NULL,
  `contact_number` char(20) DEFAULT NULL,
  `alt_number` varchar(191) DEFAULT NULL,
  `family_number` varchar(191) DEFAULT NULL,
  `fb_link` varchar(191) DEFAULT NULL,
  `twitter_link` varchar(191) DEFAULT NULL,
  `social_media_1` varchar(191) DEFAULT NULL,
  `social_media_2` varchar(191) DEFAULT NULL,
  `permanent_address` text DEFAULT NULL,
  `current_address` text DEFAULT NULL,
  `guardian_name` varchar(191) DEFAULT NULL,
  `custom_field_1` varchar(191) DEFAULT NULL,
  `custom_field_2` varchar(191) DEFAULT NULL,
  `custom_field_3` varchar(191) DEFAULT NULL,
  `custom_field_4` varchar(191) DEFAULT NULL,
  `bank_details` longtext DEFAULT NULL,
  `id_proof_name` varchar(191) DEFAULT NULL,
  `id_proof_number` varchar(191) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL COMMENT 'user primary work location',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  KEY `users_business_id_foreign` (`business_id`),
  KEY `users_user_type_index` (`user_type`),
  KEY `users_crm_contact_id_foreign` (`crm_contact_id`),
  KEY `users_essentials_department_id_index` (`essentials_department_id`),
  KEY `users_essentials_designation_id_index` (`essentials_designation_id`),
  CONSTRAINT `users_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `users_crm_contact_id_foreign` FOREIGN KEY (`crm_contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'user',NULL,'webwonder',NULL,'webwonder','admin@admin.com','$2y$10$GPsutW3QZNJGioW0.toNaOs4OpSe0qBImHPaHbj/KKEYX404apV/W','en',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'active',0,NULL,NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,NULL,'2024-08-01 04:19:13','2025-01-20 16:13:52'),
(2,'user','Miss','Joseph','Bill',NULL,NULL,NULL,'en',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'active',0,NULL,NULL,1,5.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-11 10:43:26','2025-01-11 10:43:26'),
(3,'user','Mr','Jacob','Mercado','jmercado','jacobmercado@gmail.com','$2y$10$0SgM11Ex7yLEXr0fHbYiZ.ugIrzfNbt6oYySz3/vAO2JOAz5KHWOe','en',NULL,NULL,NULL,1,NULL,NULL,10.0000,'day',NULL,NULL,NULL,NULL,1,'active',0,NULL,NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,1,NULL,'2025-01-15 13:55:03','2025-01-15 13:55:04'),
(4,'user','Miss','Chloe Angeline','Barcelona','chloeb','chloe@deuldigital.com','$2y$10$DCWdC3MQVSAMJuACcSEO8OhOY/..88WmhbP7Tu7Z1.XZm2l/FwvEa','en',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'active',0,NULL,NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-17 12:03:44','2025-01-17 12:03:44'),
(5,'user','Miss','ARCELI','SALVADOR','arcelie','analizaflotildes02@gmail.com','$2y$10$bTPGi3.jEC/nhNnJ9TTb5eobrwd7YhCEvVYJEbR8L51AfE0RgmBpu','en',NULL,NULL,NULL,1,1,2,100000.0000,'week',NULL,NULL,NULL,NULL,1,'active',0,NULL,NULL,0,0.00,0,NULL,NULL,NULL,NULL,'09385050860',NULL,NULL,NULL,NULL,NULL,NULL,'BLISS PUROK 6 ANGOLUAN',NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,1,NULL,'2025-01-17 12:22:10','2025-01-17 12:51:47'),
(6,'user',NULL,'ARCELI','SALVADOR','arcelieb','arcelie@gmail.com','$2y$10$3sLRS0wB4NQ8X1uS0fmdo.DoHljhb/SqVgrKY.9P3D89zxC36YUYS','en',NULL,NULL,NULL,2,NULL,NULL,11000.0000,'month',NULL,NULL,NULL,NULL,1,'active',0,NULL,NULL,0,0.00,0,NULL,NULL,NULL,NULL,'09385050860',NULL,NULL,NULL,NULL,NULL,NULL,'BLISS PUROK 6 ANGOLUAN',NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,2,NULL,'2025-01-17 13:00:11','2025-01-17 13:00:11'),
(9,'user',NULL,'Jeno','Lee','jenolee3124','jenolee3124@gmail.com','$2y$10$3UjyNqCDMEZo33gUuAWFW.MZXaUe1MbrL0MkobIuJH3LCK4PepKhe','en',NULL,NULL,NULL,1,NULL,NULL,NULL,'month',NULL,NULL,NULL,NULL,1,'active',0,NULL,NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2025-01-23 14:02:27','2025-01-22 22:17:34','2025-01-23 14:02:27'),
(10,'user',NULL,'Test',NULL,'Testing','Test@gmail.com','$2y$10$7sULSrc3pSvM6oLC49O/Z.1WcaGYc.cPQs0ZlUYZoSY.MB5CfHGg2','en',NULL,NULL,NULL,1,NULL,NULL,NULL,'month',NULL,NULL,NULL,NULL,1,'active',0,NULL,NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,NULL,'2025-01-23 10:40:13','2025-01-23 10:40:13'),
(11,'user',NULL,'Testing 1',NULL,'Testing1','Testing1@gmail.com','$2y$10$M09M095X8Idmw3AH16c46.RC9WDH7I6ZCXYxWvMMpZ5/MbRCChQAy','en',NULL,NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'active',0,NULL,NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-01-23 10:41:35','2025-01-23 10:41:35'),
(12,'user',NULL,'jenolee',NULL,'jenolee','jenolee@gmail.com','$2y$10$DA5vg0lmyGKLYVV2KVE.nOWYSqkjyE8F9iksoVLAV7DNYj1P9GKum','en',NULL,NULL,NULL,1,NULL,NULL,NULL,'month',NULL,NULL,NULL,NULL,1,'active',0,NULL,NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,NULL,'2025-01-23 14:03:13','2025-01-23 14:04:31'),
(13,'user',NULL,'jaeminna',NULL,'jaeminna','jaeminna@gmail.com','$2y$10$WozMAjKXhvakhuj0sOte/ux.kNdpuqAZAdkS4h9qeq7.BDdvxrqwK','en',NULL,NULL,NULL,1,NULL,NULL,NULL,'month',NULL,NULL,NULL,NULL,1,'active',0,NULL,NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,NULL,'2025-01-23 14:03:58','2025-01-23 14:05:42'),
(14,'user',NULL,'jisungpark',NULL,'jisungpark','jisungpark@gmail.com','$2y$10$uvl8iZqL0UbBfPdLkjE8Z.GGHlSmbXZu8D32f9gNBkl8ANZWnFsMu','en',NULL,NULL,NULL,1,NULL,NULL,NULL,'month',NULL,NULL,NULL,NULL,1,'active',0,NULL,NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,NULL,'2025-01-23 14:05:11','2025-01-23 14:05:11'),
(15,'user',NULL,'haechanlee',NULL,'haechanlee','haechanlee@gmail.com','$2y$10$l.wtLXPMWxH5e75K/Y2sNusbnytSFkv0BDz.ZOX89JQqLkI5oWeUW','en',NULL,NULL,NULL,1,NULL,NULL,NULL,'month',NULL,NULL,NULL,NULL,1,'active',0,NULL,NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,NULL,'2025-01-23 14:06:22','2025-01-23 14:06:22'),
(16,'user',NULL,'marklee',NULL,'marklee','marklee@gmail.com','$2y$10$R6JUAUBo3zaZY7wVRcB6gO.niqxTBZ/HJk/BB4F8VMzWODK5O6s7G','en',NULL,NULL,NULL,1,NULL,NULL,NULL,'month',NULL,NULL,NULL,NULL,1,'active',0,NULL,NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,NULL,'2025-01-23 14:07:01','2025-01-23 14:07:01');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `variation_group_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `variation_group_prices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `variation_id` int(10) unsigned NOT NULL,
  `price_group_id` int(10) unsigned NOT NULL,
  `price_inc_tax` decimal(22,4) NOT NULL,
  `price_type` varchar(191) NOT NULL DEFAULT 'fixed',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `variation_group_prices_variation_id_foreign` (`variation_id`),
  KEY `variation_group_prices_price_group_id_foreign` (`price_group_id`),
  CONSTRAINT `variation_group_prices_price_group_id_foreign` FOREIGN KEY (`price_group_id`) REFERENCES `selling_price_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `variation_group_prices_variation_id_foreign` FOREIGN KEY (`variation_id`) REFERENCES `variations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `variation_group_prices` WRITE;
/*!40000 ALTER TABLE `variation_group_prices` DISABLE KEYS */;
/*!40000 ALTER TABLE `variation_group_prices` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `variation_location_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `variation_location_details` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `product_variation_id` int(10) unsigned NOT NULL COMMENT 'id from product_variations table',
  `variation_id` int(10) unsigned NOT NULL,
  `location_id` int(10) unsigned NOT NULL,
  `qty_available` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `variation_location_details_location_id_foreign` (`location_id`),
  KEY `variation_location_details_product_id_index` (`product_id`),
  KEY `variation_location_details_product_variation_id_index` (`product_variation_id`),
  KEY `variation_location_details_variation_id_index` (`variation_id`),
  CONSTRAINT `variation_location_details_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `business_locations` (`id`),
  CONSTRAINT `variation_location_details_variation_id_foreign` FOREIGN KEY (`variation_id`) REFERENCES `variations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `variation_location_details` WRITE;
/*!40000 ALTER TABLE `variation_location_details` DISABLE KEYS */;
INSERT INTO `variation_location_details` VALUES
(1,1,1,1,1,876.0000,'2025-01-09 12:00:40','2025-01-23 11:56:05'),
(2,2,2,2,1,0.0000,'2025-01-15 13:50:25','2025-01-23 14:09:39'),
(3,3,3,3,1,0.0000,'2025-01-17 11:47:59','2025-01-23 14:10:50'),
(4,7,7,7,1,499950.0000,'2025-01-23 09:43:13','2025-01-23 12:34:20'),
(5,8,8,8,1,979.0000,'2025-01-23 09:55:40','2025-01-23 12:34:20'),
(6,9,9,9,1,4998.0000,'2025-01-23 13:28:35','2025-01-23 14:49:26'),
(7,10,10,10,1,0.0000,'2025-01-23 13:38:40','2025-01-23 14:11:56'),
(8,12,11,11,1,0.0000,'2025-01-23 13:45:48','2025-01-23 14:13:13');
/*!40000 ALTER TABLE `variation_location_details` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `variation_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `variation_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `business_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `variation_templates_business_id_foreign` (`business_id`),
  CONSTRAINT `variation_templates_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `variation_templates` WRITE;
/*!40000 ALTER TABLE `variation_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `variation_templates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `variation_value_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `variation_value_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `variation_template_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `variation_value_templates_name_index` (`name`),
  KEY `variation_value_templates_variation_template_id_index` (`variation_template_id`),
  CONSTRAINT `variation_value_templates_variation_template_id_foreign` FOREIGN KEY (`variation_template_id`) REFERENCES `variation_templates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `variation_value_templates` WRITE;
/*!40000 ALTER TABLE `variation_value_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `variation_value_templates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `variations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `variations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `sub_sku` varchar(191) DEFAULT NULL,
  `product_variation_id` int(10) unsigned NOT NULL,
  `variation_value_id` int(11) DEFAULT NULL,
  `default_purchase_price` decimal(22,4) DEFAULT NULL,
  `dpp_inc_tax` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `profit_percent` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `default_sell_price` decimal(22,4) DEFAULT NULL,
  `sell_price_inc_tax` decimal(22,4) DEFAULT NULL COMMENT 'Sell price including tax',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `combo_variations` text DEFAULT NULL COMMENT 'Contains the combo variation details',
  PRIMARY KEY (`id`),
  KEY `variations_product_id_foreign` (`product_id`),
  KEY `variations_product_variation_id_foreign` (`product_variation_id`),
  KEY `variations_name_index` (`name`),
  KEY `variations_sub_sku_index` (`sub_sku`),
  KEY `variations_variation_value_id_index` (`variation_value_id`),
  CONSTRAINT `variations_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `variations_product_variation_id_foreign` FOREIGN KEY (`product_variation_id`) REFERENCES `product_variations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `variations` WRITE;
/*!40000 ALTER TABLE `variations` DISABLE KEYS */;
INSERT INTO `variations` VALUES
(1,'DUMMY',1,'1001',1,NULL,0.0000,0.0000,0.0000,100.0000,100.0000,'2025-01-09 11:58:05','2025-01-09 11:58:32',NULL,'[]'),
(2,'DUMMY',2,'0002',2,NULL,0.0000,0.0000,0.0000,500.0000,500.0000,'2025-01-15 13:50:04','2025-01-23 13:31:35',NULL,'[]'),
(3,'DUMMY',3,'0003',3,NULL,0.0000,0.0000,0.0000,500.0000,500.0000,'2025-01-17 11:46:59','2025-01-23 13:30:24',NULL,'[]'),
(4,'Large',4,'0004-1',4,NULL,10.0000,10.0000,0.0000,10.0000,10.0000,'2025-01-20 16:22:20','2025-01-20 16:22:20',NULL,NULL),
(5,'Small',5,'0005-1',5,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,'2025-01-20 16:25:32','2025-01-20 16:25:32',NULL,NULL),
(6,'Ice',6,'0006-1',6,NULL,4.0000,4.0000,0.0000,4.0000,4.0000,'2025-01-20 16:25:43','2025-01-20 16:25:43',NULL,NULL),
(7,'DUMMY',7,'0007',7,NULL,446.4300,500.0000,0.0000,446.4300,500.0000,'2025-01-23 09:41:49','2025-01-23 09:42:20',NULL,'[]'),
(8,'DUMMY',8,'0008',8,NULL,10.7100,12.0000,416733.4000,44642.8600,50000.0000,'2025-01-23 09:55:22','2025-01-23 09:55:22',NULL,'[]'),
(9,'DUMMY',9,'0009',9,NULL,500.0000,560.0000,0.0000,500.0000,560.0000,'2025-01-23 13:27:48','2025-01-23 14:33:27',NULL,'[]'),
(10,'DUMMY',10,'0010',10,NULL,500.0000,500.0000,0.0000,500.0000,500.0000,'2025-01-23 13:38:27','2025-01-23 13:40:04',NULL,'[]'),
(11,'DUMMY',12,'0012',11,NULL,500.0000,500.0000,0.0000,500.0000,500.0000,'2025-01-23 13:45:24','2025-01-23 13:45:24',NULL,'[]');
/*!40000 ALTER TABLE `variations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `warranties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warranties` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `business_id` int(11) NOT NULL,
  `description` text DEFAULT NULL,
  `duration` int(11) NOT NULL,
  `duration_type` enum('days','months','years') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `warranties_business_id_index` (`business_id`),
  KEY `warranties_duration_type_index` (`duration_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `warranties` WRITE;
/*!40000 ALTER TABLE `warranties` DISABLE KEYS */;
/*!40000 ALTER TABLE `warranties` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

